package android.support.v4.media;

import android.media.browse.MediaBrowser.MediaItem;
import androidx.annotation.RequiresApi;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.List;

@RequiresApi(21)
class ParceledListSliceAdapterApi21
{
  private static Constructor sConstructor;

  static
  {
    try
    {
      sConstructor = Class.forName("android.content.pm.ParceledListSlice").getConstructor(new Class[] { List.class });
      return;
    }
    catch (NoSuchMethodException localNoSuchMethodException)
    {
    }
    catch (ClassNotFoundException localClassNotFoundException)
    {
    }
    localClassNotFoundException.printStackTrace();
  }

  static Object newInstance(List<MediaBrowser.MediaItem> paramList)
  {
    try
    {
      paramList = sConstructor.newInstance(new Object[] { paramList });
      return paramList;
    }
    catch (InvocationTargetException paramList)
    {
    }
    catch (IllegalAccessException paramList)
    {
    }
    catch (InstantiationException paramList)
    {
    }
    paramList.printStackTrace();
    return null;
  }
}

/* Location:           C:\Users\eunna\dex2jar-2.0\classes-dex2jar.jar
 * Qualified Name:     android.support.v4.media.ParceledListSliceAdapterApi21
 * JD-Core Version:    0.6.2
 */