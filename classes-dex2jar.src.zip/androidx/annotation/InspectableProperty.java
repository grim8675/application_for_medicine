// INTERNAL ERROR //

/* Location:           C:\Users\eunna\dex2jar-2.0\classes-dex2jar.jar
 * Qualified Name:     androidx.annotation.InspectableProperty
 * JD-Core Version:    0.6.2
 */