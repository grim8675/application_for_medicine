package androidx.appcompat.view;

public abstract interface CollapsibleActionView
{
  public abstract void onActionViewCollapsed();

  public abstract void onActionViewExpanded();
}

/* Location:           C:\Users\eunna\dex2jar-2.0\classes-dex2jar.jar
 * Qualified Name:     androidx.appcompat.view.CollapsibleActionView
 * JD-Core Version:    0.6.2
 */