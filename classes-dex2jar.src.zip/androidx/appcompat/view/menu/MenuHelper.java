package androidx.appcompat.view.menu;

abstract interface MenuHelper
{
  public abstract void dismiss();

  public abstract void setPresenterCallback(MenuPresenter.Callback paramCallback);
}

/* Location:           C:\Users\eunna\dex2jar-2.0\classes-dex2jar.jar
 * Qualified Name:     androidx.appcompat.view.menu.MenuHelper
 * JD-Core Version:    0.6.2
 */