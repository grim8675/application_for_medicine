package androidx.appcompat.widget;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.database.DataSetObservable;
import android.os.AsyncTask;
import android.text.TextUtils;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

class ActivityChooserModel extends DataSetObservable
{
  static final String ATTRIBUTE_ACTIVITY = "activity";
  static final String ATTRIBUTE_TIME = "time";
  static final String ATTRIBUTE_WEIGHT = "weight";
  static final boolean DEBUG = false;
  private static final int DEFAULT_ACTIVITY_INFLATION = 5;
  private static final float DEFAULT_HISTORICAL_RECORD_WEIGHT = 1.0F;
  public static final String DEFAULT_HISTORY_FILE_NAME = "activity_choser_model_history.xml";
  public static final int DEFAULT_HISTORY_MAX_LENGTH = 50;
  private static final String HISTORY_FILE_EXTENSION = ".xml";
  private static final int INVALID_INDEX = -1;
  static final String LOG_TAG = ActivityChooserModel.class.getSimpleName();
  static final String TAG_HISTORICAL_RECORD = "historical-record";
  static final String TAG_HISTORICAL_RECORDS = "historical-records";
  private static final Map<String, ActivityChooserModel> sDataModelRegistry = new HashMap();
  private static final Object sRegistryLock = new Object();
  private final List<ActivityResolveInfo> mActivities = new ArrayList();
  private OnChooseActivityListener mActivityChoserModelPolicy;
  private ActivitySorter mActivitySorter = new DefaultSorter();
  boolean mCanReadHistoricalData = true;
  final Context mContext;
  private final List<HistoricalRecord> mHistoricalRecords = new ArrayList();
  private boolean mHistoricalRecordsChanged = true;
  final String mHistoryFileName;
  private int mHistoryMaxSize = 50;
  private final Object mInstanceLock = new Object();
  private Intent mIntent;
  private boolean mReadShareHistoryCalled = false;
  private boolean mReloadActivities = false;

  private ActivityChooserModel(Context paramContext, String paramString)
  {
    this.mContext = paramContext.getApplicationContext();
    if ((!TextUtils.isEmpty(paramString)) && (!paramString.endsWith(".xml")))
    {
      paramContext = new StringBuilder();
      paramContext.append(paramString);
      paramContext.append(".xml");
      this.mHistoryFileName = paramContext.toString();
      return;
    }
    this.mHistoryFileName = paramString;
  }

  private boolean addHistoricalRecord(HistoricalRecord paramHistoricalRecord)
  {
    boolean bool = this.mHistoricalRecords.add(paramHistoricalRecord);
    if (bool)
    {
      this.mHistoricalRecordsChanged = true;
      pruneExcessiveHistoricalRecordsIfNeeded();
      persistHistoricalDataIfNeeded();
      sortActivitiesIfNeeded();
      notifyChanged();
    }
    return bool;
  }

  private void ensureConsistentState()
  {
    boolean bool1 = loadActivitiesIfNeeded();
    boolean bool2 = readHistoricalDataIfNeeded();
    pruneExcessiveHistoricalRecordsIfNeeded();
    if ((bool1 | bool2))
    {
      sortActivitiesIfNeeded();
      notifyChanged();
    }
  }

  public static ActivityChooserModel get(Context paramContext, String paramString)
  {
    synchronized (sRegistryLock)
    {
      ActivityChooserModel localActivityChooserModel2 = (ActivityChooserModel)sDataModelRegistry.get(paramString);
      ActivityChooserModel localActivityChooserModel1 = localActivityChooserModel2;
      if (localActivityChooserModel2 == null)
      {
        localActivityChooserModel1 = new ActivityChooserModel(paramContext, paramString);
        sDataModelRegistry.put(paramString, localActivityChooserModel1);
      }
      return localActivityChooserModel1;
    }
  }

  private boolean loadActivitiesIfNeeded()
  {
    if ((this.mReloadActivities) && (this.mIntent != null))
    {
      this.mReloadActivities = false;
      this.mActivities.clear();
      List localList = this.mContext.getPackageManager().queryIntentActivities(this.mIntent, 0);
      int j = localList.size();
      int i = 0;
      while (i < j)
      {
        ResolveInfo localResolveInfo = (ResolveInfo)localList.get(i);
        this.mActivities.add(new ActivityResolveInfo(localResolveInfo));
        i += 1;
      }
      return true;
    }
    return false;
  }

  private void persistHistoricalDataIfNeeded()
  {
    if (this.mReadShareHistoryCalled)
    {
      if (!this.mHistoricalRecordsChanged)
        return;
      this.mHistoricalRecordsChanged = false;
      if (!TextUtils.isEmpty(this.mHistoryFileName))
        new PersistHistoryAsyncTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new Object[] { new ArrayList(this.mHistoricalRecords), this.mHistoryFileName });
      return;
    }
    throw new IllegalStateException("No preceding call to #readHistoricalData");
  }

  private void pruneExcessiveHistoricalRecordsIfNeeded()
  {
    int j = this.mHistoricalRecords.size() - this.mHistoryMaxSize;
    if (j <= 0)
      return;
    this.mHistoricalRecordsChanged = true;
    int i = 0;
    while (i < j)
    {
      HistoricalRecord localHistoricalRecord = (HistoricalRecord)this.mHistoricalRecords.remove(0);
      i += 1;
    }
  }

  private boolean readHistoricalDataIfNeeded()
  {
    if ((this.mCanReadHistoricalData) && (this.mHistoricalRecordsChanged) && (!TextUtils.isEmpty(this.mHistoryFileName)))
    {
      this.mCanReadHistoricalData = false;
      this.mReadShareHistoryCalled = true;
      readHistoricalDataImpl();
      return true;
    }
    return false;
  }

  // ERROR //
  private void readHistoricalDataImpl()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 141	androidx/appcompat/widget/ActivityChooserModel:mContext	Landroid/content/Context;
    //   4: aload_0
    //   5: getfield 165	androidx/appcompat/widget/ActivityChooserModel:mHistoryFileName	Ljava/lang/String;
    //   8: invokevirtual 272	android/content/Context:openFileInput	(Ljava/lang/String;)Ljava/io/FileInputStream;
    //   11: astore_2
    //   12: invokestatic 278	android/util/Xml:newPullParser	()Lorg/xmlpull/v1/XmlPullParser;
    //   15: astore_3
    //   16: aload_3
    //   17: aload_2
    //   18: ldc_w 280
    //   21: invokeinterface 286 3 0
    //   26: iconst_0
    //   27: istore_1
    //   28: iload_1
    //   29: iconst_1
    //   30: if_icmpeq +18 -> 48
    //   33: iload_1
    //   34: iconst_2
    //   35: if_icmpeq +13 -> 48
    //   38: aload_3
    //   39: invokeinterface 289 1 0
    //   44: istore_1
    //   45: goto -17 -> 28
    //   48: ldc 61
    //   50: aload_3
    //   51: invokeinterface 292 1 0
    //   56: invokevirtual 295	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   59: ifeq +128 -> 187
    //   62: aload_0
    //   63: getfield 120	androidx/appcompat/widget/ActivityChooserModel:mHistoricalRecords	Ljava/util/List;
    //   66: astore 4
    //   68: aload 4
    //   70: invokeinterface 211 1 0
    //   75: aload_3
    //   76: invokeinterface 289 1 0
    //   81: istore_1
    //   82: iload_1
    //   83: iconst_1
    //   84: if_icmpne +14 -> 98
    //   87: aload_2
    //   88: ifnull +228 -> 316
    //   91: aload_2
    //   92: invokevirtual 300	java/io/FileInputStream:close	()V
    //   95: goto +218 -> 313
    //   98: iload_1
    //   99: iconst_3
    //   100: if_icmpeq -25 -> 75
    //   103: iload_1
    //   104: iconst_4
    //   105: if_icmpne +6 -> 111
    //   108: goto -33 -> 75
    //   111: ldc 58
    //   113: aload_3
    //   114: invokeinterface 292 1 0
    //   119: invokevirtual 295	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   122: ifeq +54 -> 176
    //   125: aload 4
    //   127: new 18	androidx/appcompat/widget/ActivityChooserModel$HistoricalRecord
    //   130: dup
    //   131: aload_3
    //   132: aconst_null
    //   133: ldc 29
    //   135: invokeinterface 304 3 0
    //   140: aload_3
    //   141: aconst_null
    //   142: ldc 32
    //   144: invokeinterface 304 3 0
    //   149: invokestatic 310	java/lang/Long:parseLong	(Ljava/lang/String;)J
    //   152: aload_3
    //   153: aconst_null
    //   154: ldc 35
    //   156: invokeinterface 304 3 0
    //   161: invokestatic 316	java/lang/Float:parseFloat	(Ljava/lang/String;)F
    //   164: invokespecial 319	androidx/appcompat/widget/ActivityChooserModel$HistoricalRecord:<init>	(Ljava/lang/String;JF)V
    //   167: invokeinterface 173 2 0
    //   172: pop
    //   173: goto -98 -> 75
    //   176: new 266	org/xmlpull/v1/XmlPullParserException
    //   179: dup
    //   180: ldc_w 321
    //   183: invokespecial 322	org/xmlpull/v1/XmlPullParserException:<init>	(Ljava/lang/String;)V
    //   186: athrow
    //   187: new 266	org/xmlpull/v1/XmlPullParserException
    //   190: dup
    //   191: ldc_w 324
    //   194: invokespecial 322	org/xmlpull/v1/XmlPullParserException:<init>	(Ljava/lang/String;)V
    //   197: athrow
    //   198: astore_3
    //   199: goto +118 -> 317
    //   202: astore_3
    //   203: getstatic 96	androidx/appcompat/widget/ActivityChooserModel:LOG_TAG	Ljava/lang/String;
    //   206: astore 4
    //   208: new 155	java/lang/StringBuilder
    //   211: dup
    //   212: invokespecial 156	java/lang/StringBuilder:<init>	()V
    //   215: astore 5
    //   217: aload 5
    //   219: ldc_w 326
    //   222: invokevirtual 160	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   225: pop
    //   226: aload 5
    //   228: aload_0
    //   229: getfield 165	androidx/appcompat/widget/ActivityChooserModel:mHistoryFileName	Ljava/lang/String;
    //   232: invokevirtual 160	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   235: pop
    //   236: aload 4
    //   238: aload 5
    //   240: invokevirtual 163	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   243: aload_3
    //   244: invokestatic 332	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   247: pop
    //   248: aload_2
    //   249: ifnull +67 -> 316
    //   252: aload_2
    //   253: invokevirtual 300	java/io/FileInputStream:close	()V
    //   256: goto +57 -> 313
    //   259: astore_3
    //   260: getstatic 96	androidx/appcompat/widget/ActivityChooserModel:LOG_TAG	Ljava/lang/String;
    //   263: astore 4
    //   265: new 155	java/lang/StringBuilder
    //   268: dup
    //   269: invokespecial 156	java/lang/StringBuilder:<init>	()V
    //   272: astore 5
    //   274: aload 5
    //   276: ldc_w 326
    //   279: invokevirtual 160	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   282: pop
    //   283: aload 5
    //   285: aload_0
    //   286: getfield 165	androidx/appcompat/widget/ActivityChooserModel:mHistoryFileName	Ljava/lang/String;
    //   289: invokevirtual 160	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   292: pop
    //   293: aload 4
    //   295: aload 5
    //   297: invokevirtual 163	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   300: aload_3
    //   301: invokestatic 332	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   304: pop
    //   305: aload_2
    //   306: ifnull +10 -> 316
    //   309: aload_2
    //   310: invokevirtual 300	java/io/FileInputStream:close	()V
    //   313: return
    //   314: astore_2
    //   315: return
    //   316: return
    //   317: aload_2
    //   318: ifnull +11 -> 329
    //   321: aload_2
    //   322: invokevirtual 300	java/io/FileInputStream:close	()V
    //   325: goto +4 -> 329
    //   328: astore_2
    //   329: aload_3
    //   330: athrow
    //   331: astore_2
    //   332: return
    //
    // Exception table:
    //   from	to	target	type
    //   12	26	198	finally
    //   38	45	198	finally
    //   48	75	198	finally
    //   75	82	198	finally
    //   111	173	198	finally
    //   176	187	198	finally
    //   187	198	198	finally
    //   203	248	198	finally
    //   260	305	198	finally
    //   12	26	202	java/io/IOException
    //   38	45	202	java/io/IOException
    //   48	75	202	java/io/IOException
    //   75	82	202	java/io/IOException
    //   111	173	202	java/io/IOException
    //   176	187	202	java/io/IOException
    //   187	198	202	java/io/IOException
    //   12	26	259	org/xmlpull/v1/XmlPullParserException
    //   38	45	259	org/xmlpull/v1/XmlPullParserException
    //   48	75	259	org/xmlpull/v1/XmlPullParserException
    //   75	82	259	org/xmlpull/v1/XmlPullParserException
    //   111	173	259	org/xmlpull/v1/XmlPullParserException
    //   176	187	259	org/xmlpull/v1/XmlPullParserException
    //   187	198	259	org/xmlpull/v1/XmlPullParserException
    //   91	95	314	java/io/IOException
    //   252	256	314	java/io/IOException
    //   309	313	314	java/io/IOException
    //   321	325	328	java/io/IOException
    //   0	12	331	java/io/FileNotFoundException
  }

  private boolean sortActivitiesIfNeeded()
  {
    if ((this.mActivitySorter != null) && (this.mIntent != null) && (!this.mActivities.isEmpty()) && (!this.mHistoricalRecords.isEmpty()))
    {
      this.mActivitySorter.sort(this.mIntent, this.mActivities, Collections.unmodifiableList(this.mHistoricalRecords));
      return true;
    }
    return false;
  }

  public Intent chooseActivity(int paramInt)
  {
    synchronized (this.mInstanceLock)
    {
      if (this.mIntent == null)
        return null;
      ensureConsistentState();
      Object localObject2 = (ActivityResolveInfo)this.mActivities.get(paramInt);
      localObject2 = new ComponentName(((ActivityResolveInfo)localObject2).resolveInfo.activityInfo.packageName, ((ActivityResolveInfo)localObject2).resolveInfo.activityInfo.name);
      Intent localIntent1 = new Intent(this.mIntent);
      localIntent1.setComponent((ComponentName)localObject2);
      if (this.mActivityChoserModelPolicy != null)
      {
        Intent localIntent2 = new Intent(localIntent1);
        if (this.mActivityChoserModelPolicy.onChooseActivity(this, localIntent2))
          return null;
      }
      addHistoricalRecord(new HistoricalRecord((ComponentName)localObject2, System.currentTimeMillis(), 1.0F));
      return localIntent1;
    }
  }

  public ResolveInfo getActivity(int paramInt)
  {
    synchronized (this.mInstanceLock)
    {
      ensureConsistentState();
      ResolveInfo localResolveInfo = ((ActivityResolveInfo)this.mActivities.get(paramInt)).resolveInfo;
      return localResolveInfo;
    }
  }

  public int getActivityCount()
  {
    synchronized (this.mInstanceLock)
    {
      ensureConsistentState();
      int i = this.mActivities.size();
      return i;
    }
  }

  public int getActivityIndex(ResolveInfo paramResolveInfo)
  {
    int i;
    synchronized (this.mInstanceLock)
    {
      ensureConsistentState();
      List localList = this.mActivities;
      int j = localList.size();
      i = 0;
      if (i < j)
      {
        if (((ActivityResolveInfo)localList.get(i)).resolveInfo == paramResolveInfo)
          return i;
      }
      else
        return -1;
    }
  }

  public ResolveInfo getDefaultActivity()
  {
    synchronized (this.mInstanceLock)
    {
      ensureConsistentState();
      if (!this.mActivities.isEmpty())
      {
        ResolveInfo localResolveInfo = ((ActivityResolveInfo)this.mActivities.get(0)).resolveInfo;
        return localResolveInfo;
      }
      return null;
    }
  }

  public int getHistoryMaxSize()
  {
    synchronized (this.mInstanceLock)
    {
      int i = this.mHistoryMaxSize;
      return i;
    }
  }

  public int getHistorySize()
  {
    synchronized (this.mInstanceLock)
    {
      ensureConsistentState();
      int i = this.mHistoricalRecords.size();
      return i;
    }
  }

  public Intent getIntent()
  {
    synchronized (this.mInstanceLock)
    {
      Intent localIntent = this.mIntent;
      return localIntent;
    }
  }

  public void setActivitySorter(ActivitySorter paramActivitySorter)
  {
    synchronized (this.mInstanceLock)
    {
      if (this.mActivitySorter == paramActivitySorter)
        return;
      this.mActivitySorter = paramActivitySorter;
      if (sortActivitiesIfNeeded())
        notifyChanged();
      return;
    }
  }

  public void setDefaultActivity(int paramInt)
  {
    while (true)
    {
      synchronized (this.mInstanceLock)
      {
        ensureConsistentState();
        ActivityResolveInfo localActivityResolveInfo1 = (ActivityResolveInfo)this.mActivities.get(paramInt);
        ActivityResolveInfo localActivityResolveInfo2 = (ActivityResolveInfo)this.mActivities.get(0);
        if (localActivityResolveInfo2 != null)
        {
          f = localActivityResolveInfo2.weight - localActivityResolveInfo1.weight + 5.0F;
          addHistoricalRecord(new HistoricalRecord(new ComponentName(localActivityResolveInfo1.resolveInfo.activityInfo.packageName, localActivityResolveInfo1.resolveInfo.activityInfo.name), System.currentTimeMillis(), f));
          return;
        }
      }
      float f = 1.0F;
    }
  }

  public void setHistoryMaxSize(int paramInt)
  {
    synchronized (this.mInstanceLock)
    {
      if (this.mHistoryMaxSize == paramInt)
        return;
      this.mHistoryMaxSize = paramInt;
      pruneExcessiveHistoricalRecordsIfNeeded();
      if (sortActivitiesIfNeeded())
        notifyChanged();
      return;
    }
  }

  public void setIntent(Intent paramIntent)
  {
    synchronized (this.mInstanceLock)
    {
      if (this.mIntent == paramIntent)
        return;
      this.mIntent = paramIntent;
      this.mReloadActivities = true;
      ensureConsistentState();
      return;
    }
  }

  public void setOnChooseActivityListener(OnChooseActivityListener paramOnChooseActivityListener)
  {
    synchronized (this.mInstanceLock)
    {
      this.mActivityChoserModelPolicy = paramOnChooseActivityListener;
      return;
    }
  }

  public static abstract interface ActivityChooserModelClient
  {
    public abstract void setActivityChooserModel(ActivityChooserModel paramActivityChooserModel);
  }

  public static final class ActivityResolveInfo
    implements Comparable<ActivityResolveInfo>
  {
    public final ResolveInfo resolveInfo;
    public float weight;

    public ActivityResolveInfo(ResolveInfo paramResolveInfo)
    {
      this.resolveInfo = paramResolveInfo;
    }

    public int compareTo(ActivityResolveInfo paramActivityResolveInfo)
    {
      return Float.floatToIntBits(paramActivityResolveInfo.weight) - Float.floatToIntBits(this.weight);
    }

    public boolean equals(Object paramObject)
    {
      if (this == paramObject)
        return true;
      if (paramObject == null)
        return false;
      if (getClass() != paramObject.getClass())
        return false;
      paramObject = (ActivityResolveInfo)paramObject;
      return Float.floatToIntBits(this.weight) == Float.floatToIntBits(paramObject.weight);
    }

    public int hashCode()
    {
      return Float.floatToIntBits(this.weight) + 31;
    }

    public String toString()
    {
      StringBuilder localStringBuilder = new StringBuilder();
      localStringBuilder.append("[");
      localStringBuilder.append("resolveInfo:");
      localStringBuilder.append(this.resolveInfo.toString());
      localStringBuilder.append("; weight:");
      localStringBuilder.append(new BigDecimal(this.weight));
      localStringBuilder.append("]");
      return localStringBuilder.toString();
    }
  }

  public static abstract interface ActivitySorter
  {
    public abstract void sort(Intent paramIntent, List<ActivityChooserModel.ActivityResolveInfo> paramList, List<ActivityChooserModel.HistoricalRecord> paramList1);
  }

  private static final class DefaultSorter
    implements ActivityChooserModel.ActivitySorter
  {
    private static final float WEIGHT_DECAY_COEFFICIENT = 0.95F;
    private final Map<ComponentName, ActivityChooserModel.ActivityResolveInfo> mPackageNameToActivityMap = new HashMap();

    public void sort(Intent paramIntent, List<ActivityChooserModel.ActivityResolveInfo> paramList, List<ActivityChooserModel.HistoricalRecord> paramList1)
    {
      paramIntent = this.mPackageNameToActivityMap;
      paramIntent.clear();
      int j = paramList.size();
      int i = 0;
      Object localObject;
      while (i < j)
      {
        localObject = (ActivityChooserModel.ActivityResolveInfo)paramList.get(i);
        ((ActivityChooserModel.ActivityResolveInfo)localObject).weight = 0.0F;
        paramIntent.put(new ComponentName(((ActivityChooserModel.ActivityResolveInfo)localObject).resolveInfo.activityInfo.packageName, ((ActivityChooserModel.ActivityResolveInfo)localObject).resolveInfo.activityInfo.name), localObject);
        i += 1;
      }
      i = paramList1.size();
      float f1 = 1.0F;
      i -= 1;
      while (i >= 0)
      {
        localObject = (ActivityChooserModel.HistoricalRecord)paramList1.get(i);
        ActivityChooserModel.ActivityResolveInfo localActivityResolveInfo = (ActivityChooserModel.ActivityResolveInfo)paramIntent.get(((ActivityChooserModel.HistoricalRecord)localObject).activity);
        float f2 = f1;
        if (localActivityResolveInfo != null)
        {
          localActivityResolveInfo.weight += ((ActivityChooserModel.HistoricalRecord)localObject).weight * f1;
          f2 = f1 * 0.95F;
        }
        i -= 1;
        f1 = f2;
      }
      Collections.sort(paramList);
    }
  }

  public static final class HistoricalRecord
  {
    public final ComponentName activity;
    public final long time;
    public final float weight;

    public HistoricalRecord(ComponentName paramComponentName, long paramLong, float paramFloat)
    {
      this.activity = paramComponentName;
      this.time = paramLong;
      this.weight = paramFloat;
    }

    public HistoricalRecord(String paramString, long paramLong, float paramFloat)
    {
      this(ComponentName.unflattenFromString(paramString), paramLong, paramFloat);
    }

    public boolean equals(Object paramObject)
    {
      if (this == paramObject)
        return true;
      if (paramObject == null)
        return false;
      if (getClass() != paramObject.getClass())
        return false;
      paramObject = (HistoricalRecord)paramObject;
      ComponentName localComponentName = this.activity;
      if (localComponentName == null)
      {
        if (paramObject.activity != null)
          return false;
      }
      else if (!localComponentName.equals(paramObject.activity))
        return false;
      if (this.time != paramObject.time)
        return false;
      return Float.floatToIntBits(this.weight) == Float.floatToIntBits(paramObject.weight);
    }

    public int hashCode()
    {
      ComponentName localComponentName = this.activity;
      int i;
      if (localComponentName == null)
        i = 0;
      else
        i = localComponentName.hashCode();
      long l = this.time;
      return ((1 * 31 + i) * 31 + (int)(l ^ l >>> 32)) * 31 + Float.floatToIntBits(this.weight);
    }

    public String toString()
    {
      StringBuilder localStringBuilder = new StringBuilder();
      localStringBuilder.append("[");
      localStringBuilder.append("; activity:");
      localStringBuilder.append(this.activity);
      localStringBuilder.append("; time:");
      localStringBuilder.append(this.time);
      localStringBuilder.append("; weight:");
      localStringBuilder.append(new BigDecimal(this.weight));
      localStringBuilder.append("]");
      return localStringBuilder.toString();
    }
  }

  public static abstract interface OnChooseActivityListener
  {
    public abstract boolean onChooseActivity(ActivityChooserModel paramActivityChooserModel, Intent paramIntent);
  }

  private final class PersistHistoryAsyncTask extends AsyncTask<Object, Void, Void>
  {
    PersistHistoryAsyncTask()
    {
    }

    // ERROR //
    public Void doInBackground(Object[] paramArrayOfObject)
    {
      // Byte code:
      //   0: aload_1
      //   1: iconst_0
      //   2: aaload
      //   3: checkcast 33	java/util/List
      //   6: astore 4
      //   8: aload_1
      //   9: iconst_1
      //   10: aaload
      //   11: checkcast 35	java/lang/String
      //   14: astore_1
      //   15: aload_0
      //   16: getfield 14	androidx/appcompat/widget/ActivityChooserModel$PersistHistoryAsyncTask:this$0	Landroidx/appcompat/widget/ActivityChooserModel;
      //   19: getfield 39	androidx/appcompat/widget/ActivityChooserModel:mContext	Landroid/content/Context;
      //   22: aload_1
      //   23: iconst_0
      //   24: invokevirtual 45	android/content/Context:openFileOutput	(Ljava/lang/String;I)Ljava/io/FileOutputStream;
      //   27: astore 6
      //   29: invokestatic 51	android/util/Xml:newSerializer	()Lorg/xmlpull/v1/XmlSerializer;
      //   32: astore 7
      //   34: aload 4
      //   36: astore 5
      //   38: aload 4
      //   40: astore 5
      //   42: aload 4
      //   44: astore 5
      //   46: aload 4
      //   48: astore 5
      //   50: aload 7
      //   52: aload 6
      //   54: aconst_null
      //   55: invokeinterface 57 3 0
      //   60: aload 4
      //   62: astore 5
      //   64: aload 4
      //   66: astore 5
      //   68: aload 4
      //   70: astore 5
      //   72: aload 4
      //   74: astore 5
      //   76: aload 7
      //   78: ldc 59
      //   80: iconst_1
      //   81: invokestatic 65	java/lang/Boolean:valueOf	(Z)Ljava/lang/Boolean;
      //   84: invokeinterface 69 3 0
      //   89: aload 4
      //   91: astore 5
      //   93: aload 4
      //   95: astore 5
      //   97: aload 4
      //   99: astore 5
      //   101: aload 4
      //   103: astore 5
      //   105: aload 7
      //   107: aconst_null
      //   108: ldc 71
      //   110: invokeinterface 75 3 0
      //   115: pop
      //   116: aload 4
      //   118: astore 5
      //   120: aload 4
      //   122: astore 5
      //   124: aload 4
      //   126: astore 5
      //   128: aload 4
      //   130: astore 5
      //   132: aload 4
      //   134: invokeinterface 79 1 0
      //   139: istore_3
      //   140: iconst_0
      //   141: istore_2
      //   142: aload 4
      //   144: astore_1
      //   145: iload_2
      //   146: iload_3
      //   147: if_icmpge +137 -> 284
      //   150: aload_1
      //   151: astore 5
      //   153: aload_1
      //   154: astore 5
      //   156: aload_1
      //   157: astore 5
      //   159: aload_1
      //   160: astore 5
      //   162: aload_1
      //   163: iconst_0
      //   164: invokeinterface 83 2 0
      //   169: checkcast 85	androidx/appcompat/widget/ActivityChooserModel$HistoricalRecord
      //   172: astore 4
      //   174: aload_1
      //   175: astore 5
      //   177: aload_1
      //   178: astore 5
      //   180: aload_1
      //   181: astore 5
      //   183: aload_1
      //   184: astore 5
      //   186: aload 7
      //   188: aconst_null
      //   189: ldc 87
      //   191: invokeinterface 75 3 0
      //   196: pop
      //   197: aload_1
      //   198: astore 5
      //   200: aload_1
      //   201: astore 5
      //   203: aload_1
      //   204: astore 5
      //   206: aload_1
      //   207: astore 5
      //   209: aload 7
      //   211: aconst_null
      //   212: ldc 89
      //   214: aload 4
      //   216: getfield 92	androidx/appcompat/widget/ActivityChooserModel$HistoricalRecord:activity	Landroid/content/ComponentName;
      //   219: invokevirtual 98	android/content/ComponentName:flattenToString	()Ljava/lang/String;
      //   222: invokeinterface 102 4 0
      //   227: pop
      //   228: aload 7
      //   230: aconst_null
      //   231: ldc 104
      //   233: aload 4
      //   235: getfield 107	androidx/appcompat/widget/ActivityChooserModel$HistoricalRecord:time	J
      //   238: invokestatic 110	java/lang/String:valueOf	(J)Ljava/lang/String;
      //   241: invokeinterface 102 4 0
      //   246: pop
      //   247: aload 7
      //   249: aconst_null
      //   250: ldc 112
      //   252: aload 4
      //   254: getfield 115	androidx/appcompat/widget/ActivityChooserModel$HistoricalRecord:weight	F
      //   257: invokestatic 118	java/lang/String:valueOf	(F)Ljava/lang/String;
      //   260: invokeinterface 102 4 0
      //   265: pop
      //   266: aload 7
      //   268: aconst_null
      //   269: ldc 87
      //   271: invokeinterface 121 3 0
      //   276: pop
      //   277: iload_2
      //   278: iconst_1
      //   279: iadd
      //   280: istore_2
      //   281: goto -136 -> 145
      //   284: aload 7
      //   286: aconst_null
      //   287: ldc 71
      //   289: invokeinterface 121 3 0
      //   294: pop
      //   295: aload 7
      //   297: invokeinterface 124 1 0
      //   302: aload_0
      //   303: getfield 14	androidx/appcompat/widget/ActivityChooserModel$PersistHistoryAsyncTask:this$0	Landroidx/appcompat/widget/ActivityChooserModel;
      //   306: iconst_1
      //   307: putfield 128	androidx/appcompat/widget/ActivityChooserModel:mCanReadHistoricalData	Z
      //   310: aload 6
      //   312: ifnull +236 -> 548
      //   315: aload 6
      //   317: invokevirtual 133	java/io/FileOutputStream:close	()V
      //   320: goto +223 -> 543
      //   323: astore_1
      //   324: goto +16 -> 340
      //   327: astore_1
      //   328: goto +81 -> 409
      //   331: astore_1
      //   332: goto +146 -> 478
      //   335: astore_1
      //   336: goto +215 -> 551
      //   339: astore_1
      //   340: getstatic 137	androidx/appcompat/widget/ActivityChooserModel:LOG_TAG	Ljava/lang/String;
      //   343: astore 4
      //   345: new 139	java/lang/StringBuilder
      //   348: dup
      //   349: invokespecial 140	java/lang/StringBuilder:<init>	()V
      //   352: astore 5
      //   354: aload 5
      //   356: ldc 142
      //   358: invokevirtual 146	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   361: pop
      //   362: aload 5
      //   364: aload_0
      //   365: getfield 14	androidx/appcompat/widget/ActivityChooserModel$PersistHistoryAsyncTask:this$0	Landroidx/appcompat/widget/ActivityChooserModel;
      //   368: getfield 149	androidx/appcompat/widget/ActivityChooserModel:mHistoryFileName	Ljava/lang/String;
      //   371: invokevirtual 146	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   374: pop
      //   375: aload 4
      //   377: aload 5
      //   379: invokevirtual 152	java/lang/StringBuilder:toString	()Ljava/lang/String;
      //   382: aload_1
      //   383: invokestatic 158	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   386: pop
      //   387: aload_0
      //   388: getfield 14	androidx/appcompat/widget/ActivityChooserModel$PersistHistoryAsyncTask:this$0	Landroidx/appcompat/widget/ActivityChooserModel;
      //   391: iconst_1
      //   392: putfield 128	androidx/appcompat/widget/ActivityChooserModel:mCanReadHistoricalData	Z
      //   395: aload 6
      //   397: ifnull +151 -> 548
      //   400: aload 6
      //   402: invokevirtual 133	java/io/FileOutputStream:close	()V
      //   405: goto +138 -> 543
      //   408: astore_1
      //   409: getstatic 137	androidx/appcompat/widget/ActivityChooserModel:LOG_TAG	Ljava/lang/String;
      //   412: astore 4
      //   414: new 139	java/lang/StringBuilder
      //   417: dup
      //   418: invokespecial 140	java/lang/StringBuilder:<init>	()V
      //   421: astore 5
      //   423: aload 5
      //   425: ldc 142
      //   427: invokevirtual 146	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   430: pop
      //   431: aload 5
      //   433: aload_0
      //   434: getfield 14	androidx/appcompat/widget/ActivityChooserModel$PersistHistoryAsyncTask:this$0	Landroidx/appcompat/widget/ActivityChooserModel;
      //   437: getfield 149	androidx/appcompat/widget/ActivityChooserModel:mHistoryFileName	Ljava/lang/String;
      //   440: invokevirtual 146	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   443: pop
      //   444: aload 4
      //   446: aload 5
      //   448: invokevirtual 152	java/lang/StringBuilder:toString	()Ljava/lang/String;
      //   451: aload_1
      //   452: invokestatic 158	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   455: pop
      //   456: aload_0
      //   457: getfield 14	androidx/appcompat/widget/ActivityChooserModel$PersistHistoryAsyncTask:this$0	Landroidx/appcompat/widget/ActivityChooserModel;
      //   460: iconst_1
      //   461: putfield 128	androidx/appcompat/widget/ActivityChooserModel:mCanReadHistoricalData	Z
      //   464: aload 6
      //   466: ifnull +82 -> 548
      //   469: aload 6
      //   471: invokevirtual 133	java/io/FileOutputStream:close	()V
      //   474: goto +69 -> 543
      //   477: astore_1
      //   478: getstatic 137	androidx/appcompat/widget/ActivityChooserModel:LOG_TAG	Ljava/lang/String;
      //   481: astore 4
      //   483: new 139	java/lang/StringBuilder
      //   486: dup
      //   487: invokespecial 140	java/lang/StringBuilder:<init>	()V
      //   490: astore 5
      //   492: aload 5
      //   494: ldc 142
      //   496: invokevirtual 146	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   499: pop
      //   500: aload 5
      //   502: aload_0
      //   503: getfield 14	androidx/appcompat/widget/ActivityChooserModel$PersistHistoryAsyncTask:this$0	Landroidx/appcompat/widget/ActivityChooserModel;
      //   506: getfield 149	androidx/appcompat/widget/ActivityChooserModel:mHistoryFileName	Ljava/lang/String;
      //   509: invokevirtual 146	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   512: pop
      //   513: aload 4
      //   515: aload 5
      //   517: invokevirtual 152	java/lang/StringBuilder:toString	()Ljava/lang/String;
      //   520: aload_1
      //   521: invokestatic 158	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   524: pop
      //   525: aload_0
      //   526: getfield 14	androidx/appcompat/widget/ActivityChooserModel$PersistHistoryAsyncTask:this$0	Landroidx/appcompat/widget/ActivityChooserModel;
      //   529: iconst_1
      //   530: putfield 128	androidx/appcompat/widget/ActivityChooserModel:mCanReadHistoricalData	Z
      //   533: aload 6
      //   535: ifnull +13 -> 548
      //   538: aload 6
      //   540: invokevirtual 133	java/io/FileOutputStream:close	()V
      //   543: aconst_null
      //   544: areturn
      //   545: astore_1
      //   546: aconst_null
      //   547: areturn
      //   548: aconst_null
      //   549: areturn
      //   550: astore_1
      //   551: aload_0
      //   552: getfield 14	androidx/appcompat/widget/ActivityChooserModel$PersistHistoryAsyncTask:this$0	Landroidx/appcompat/widget/ActivityChooserModel;
      //   555: iconst_1
      //   556: putfield 128	androidx/appcompat/widget/ActivityChooserModel:mCanReadHistoricalData	Z
      //   559: aload 6
      //   561: ifnull +13 -> 574
      //   564: aload 6
      //   566: invokevirtual 133	java/io/FileOutputStream:close	()V
      //   569: goto +5 -> 574
      //   572: astore 4
      //   574: aload_1
      //   575: athrow
      //   576: astore 4
      //   578: getstatic 137	androidx/appcompat/widget/ActivityChooserModel:LOG_TAG	Ljava/lang/String;
      //   581: astore 5
      //   583: new 139	java/lang/StringBuilder
      //   586: dup
      //   587: invokespecial 140	java/lang/StringBuilder:<init>	()V
      //   590: astore 6
      //   592: aload 6
      //   594: ldc 142
      //   596: invokevirtual 146	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   599: pop
      //   600: aload 6
      //   602: aload_1
      //   603: invokevirtual 146	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   606: pop
      //   607: aload 5
      //   609: aload 6
      //   611: invokevirtual 152	java/lang/StringBuilder:toString	()Ljava/lang/String;
      //   614: aload 4
      //   616: invokestatic 158	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   619: pop
      //   620: aconst_null
      //   621: areturn
      //
      // Exception table:
      //   from	to	target	type
      //   228	277	323	java/io/IOException
      //   284	302	323	java/io/IOException
      //   228	277	327	java/lang/IllegalStateException
      //   284	302	327	java/lang/IllegalStateException
      //   228	277	331	java/lang/IllegalArgumentException
      //   284	302	331	java/lang/IllegalArgumentException
      //   50	60	335	finally
      //   76	89	335	finally
      //   105	116	335	finally
      //   132	140	335	finally
      //   162	174	335	finally
      //   186	197	335	finally
      //   209	228	335	finally
      //   50	60	339	java/io/IOException
      //   76	89	339	java/io/IOException
      //   105	116	339	java/io/IOException
      //   132	140	339	java/io/IOException
      //   162	174	339	java/io/IOException
      //   186	197	339	java/io/IOException
      //   209	228	339	java/io/IOException
      //   50	60	408	java/lang/IllegalStateException
      //   76	89	408	java/lang/IllegalStateException
      //   105	116	408	java/lang/IllegalStateException
      //   132	140	408	java/lang/IllegalStateException
      //   162	174	408	java/lang/IllegalStateException
      //   186	197	408	java/lang/IllegalStateException
      //   209	228	408	java/lang/IllegalStateException
      //   50	60	477	java/lang/IllegalArgumentException
      //   76	89	477	java/lang/IllegalArgumentException
      //   105	116	477	java/lang/IllegalArgumentException
      //   132	140	477	java/lang/IllegalArgumentException
      //   162	174	477	java/lang/IllegalArgumentException
      //   186	197	477	java/lang/IllegalArgumentException
      //   209	228	477	java/lang/IllegalArgumentException
      //   315	320	545	java/io/IOException
      //   400	405	545	java/io/IOException
      //   469	474	545	java/io/IOException
      //   538	543	545	java/io/IOException
      //   228	277	550	finally
      //   284	302	550	finally
      //   340	387	550	finally
      //   409	456	550	finally
      //   478	525	550	finally
      //   564	569	572	java/io/IOException
      //   15	29	576	java/io/FileNotFoundException
    }
  }
}

/* Location:           C:\Users\eunna\dex2jar-2.0\classes-dex2jar.jar
 * Qualified Name:     androidx.appcompat.widget.ActivityChooserModel
 * JD-Core Version:    0.6.2
 */