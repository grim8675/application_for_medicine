package androidx.appcompat.widget;

import android.content.Context;
import android.view.textclassifier.TextClassificationManager;
import android.view.textclassifier.TextClassifier;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.util.Preconditions;

final class AppCompatTextClassifierHelper
{

  @Nullable
  private TextClassifier mTextClassifier;

  @NonNull
  private TextView mTextView;

  AppCompatTextClassifierHelper(TextView paramTextView)
  {
    this.mTextView = ((TextView)Preconditions.checkNotNull(paramTextView));
  }

  @NonNull
  @RequiresApi(api=26)
  public TextClassifier getTextClassifier()
  {
    Object localObject = this.mTextClassifier;
    if (localObject == null)
    {
      localObject = (TextClassificationManager)this.mTextView.getContext().getSystemService(TextClassificationManager.class);
      if (localObject != null)
        return ((TextClassificationManager)localObject).getTextClassifier();
      return TextClassifier.NO_OP;
    }
    return localObject;
  }

  @RequiresApi(api=26)
  public void setTextClassifier(@Nullable TextClassifier paramTextClassifier)
  {
    this.mTextClassifier = paramTextClassifier;
  }
}

/* Location:           C:\Users\eunna\dex2jar-2.0\classes-dex2jar.jar
 * Qualified Name:     androidx.appcompat.widget.AppCompatTextClassifierHelper
 * JD-Core Version:    0.6.2
 */