package androidx.appcompat.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources.NotFoundException;
import android.graphics.PorterDuff.Mode;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.os.LocaleList;
import android.text.method.PasswordTransformationMethod;
import android.util.AttributeSet;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import androidx.appcompat.R.styleable;
import androidx.core.content.res.ResourcesCompat.FontCallback;
import androidx.core.widget.AutoSizeableTextView;
import androidx.core.widget.TextViewCompat;
import java.lang.ref.WeakReference;
import java.util.Locale;

class AppCompatTextHelper
{
  private static final int MONOSPACE = 3;
  private static final int SANS = 1;
  private static final int SERIF = 2;
  private static final int TEXT_FONT_WEIGHT_UNSPECIFIED = -1;
  private boolean mAsyncFontPending;

  @NonNull
  private final AppCompatTextViewAutoSizeHelper mAutoSizeTextHelper;
  private TintInfo mDrawableBottomTint;
  private TintInfo mDrawableEndTint;
  private TintInfo mDrawableLeftTint;
  private TintInfo mDrawableRightTint;
  private TintInfo mDrawableStartTint;
  private TintInfo mDrawableTint;
  private TintInfo mDrawableTopTint;
  private Typeface mFontTypeface;
  private int mFontWeight = -1;
  private int mStyle = 0;
  private final TextView mView;

  AppCompatTextHelper(TextView paramTextView)
  {
    this.mView = paramTextView;
    this.mAutoSizeTextHelper = new AppCompatTextViewAutoSizeHelper(this.mView);
  }

  private void applyCompoundDrawableTint(Drawable paramDrawable, TintInfo paramTintInfo)
  {
    if ((paramDrawable != null) && (paramTintInfo != null))
      AppCompatDrawableManager.tintDrawable(paramDrawable, paramTintInfo, this.mView.getDrawableState());
  }

  private static TintInfo createTintInfo(Context paramContext, AppCompatDrawableManager paramAppCompatDrawableManager, int paramInt)
  {
    paramContext = paramAppCompatDrawableManager.getTintList(paramContext, paramInt);
    if (paramContext != null)
    {
      paramAppCompatDrawableManager = new TintInfo();
      paramAppCompatDrawableManager.mHasTintList = true;
      paramAppCompatDrawableManager.mTintList = paramContext;
      return paramAppCompatDrawableManager;
    }
    return null;
  }

  private void setCompoundDrawables(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4, Drawable paramDrawable5, Drawable paramDrawable6)
  {
    if ((Build.VERSION.SDK_INT >= 17) && ((paramDrawable5 != null) || (paramDrawable6 != null)))
    {
      Drawable[] arrayOfDrawable = this.mView.getCompoundDrawablesRelative();
      TextView localTextView = this.mView;
      if (paramDrawable5 != null)
        paramDrawable1 = paramDrawable5;
      else
        paramDrawable1 = arrayOfDrawable[0];
      if (paramDrawable2 == null)
        paramDrawable2 = arrayOfDrawable[1];
      if (paramDrawable6 != null)
        paramDrawable3 = paramDrawable6;
      else
        paramDrawable3 = arrayOfDrawable[2];
      if (paramDrawable4 == null)
        paramDrawable4 = arrayOfDrawable[3];
      localTextView.setCompoundDrawablesRelativeWithIntrinsicBounds(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    }
    else
    {
      if ((paramDrawable1 != null) || (paramDrawable2 != null) || (paramDrawable3 != null) || (paramDrawable4 != null))
        break label125;
    }
    return;
    label125: if (Build.VERSION.SDK_INT >= 17)
    {
      paramDrawable6 = this.mView.getCompoundDrawablesRelative();
      if ((paramDrawable6[0] != null) || (paramDrawable6[2] != null))
      {
        paramDrawable3 = this.mView;
        paramDrawable5 = paramDrawable6[0];
        if (paramDrawable2 != null)
          paramDrawable1 = paramDrawable2;
        else
          paramDrawable1 = paramDrawable6[1];
        paramDrawable2 = paramDrawable6[2];
        if (paramDrawable4 == null)
          paramDrawable4 = paramDrawable6[3];
        paramDrawable3.setCompoundDrawablesRelativeWithIntrinsicBounds(paramDrawable5, paramDrawable1, paramDrawable2, paramDrawable4);
        return;
      }
    }
    paramDrawable6 = this.mView.getCompoundDrawables();
    paramDrawable5 = this.mView;
    if (paramDrawable1 == null)
      paramDrawable1 = paramDrawable6[0];
    if (paramDrawable2 == null)
      paramDrawable2 = paramDrawable6[1];
    if (paramDrawable3 == null)
      paramDrawable3 = paramDrawable6[2];
    if (paramDrawable4 == null)
      paramDrawable4 = paramDrawable6[3];
    paramDrawable5.setCompoundDrawablesWithIntrinsicBounds(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
  }

  private void setCompoundTints()
  {
    TintInfo localTintInfo = this.mDrawableTint;
    this.mDrawableLeftTint = localTintInfo;
    this.mDrawableTopTint = localTintInfo;
    this.mDrawableRightTint = localTintInfo;
    this.mDrawableBottomTint = localTintInfo;
    this.mDrawableStartTint = localTintInfo;
    this.mDrawableEndTint = localTintInfo;
  }

  private void setTextSizeInternal(int paramInt, float paramFloat)
  {
    this.mAutoSizeTextHelper.setTextSizeInternal(paramInt, paramFloat);
  }

  private void updateTypefaceAndStyle(Context paramContext, TintTypedArray paramTintTypedArray)
  {
    this.mStyle = paramTintTypedArray.getInt(R.styleable.TextAppearance_android_textStyle, this.mStyle);
    int i = Build.VERSION.SDK_INT;
    boolean bool2 = false;
    if (i >= 28)
    {
      this.mFontWeight = paramTintTypedArray.getInt(R.styleable.TextAppearance_android_textFontWeight, -1);
      if (this.mFontWeight != -1)
        this.mStyle = (this.mStyle & 0x2 | 0x0);
    }
    if ((!paramTintTypedArray.hasValue(R.styleable.TextAppearance_android_fontFamily)) && (!paramTintTypedArray.hasValue(R.styleable.TextAppearance_fontFamily)))
    {
      if (paramTintTypedArray.hasValue(R.styleable.TextAppearance_android_typeface))
      {
        this.mAsyncFontPending = false;
        i = paramTintTypedArray.getInt(R.styleable.TextAppearance_android_typeface, 1);
        if (i != 1)
        {
          if (i != 2)
          {
            if (i != 3)
              return;
            this.mFontTypeface = Typeface.MONOSPACE;
            return;
          }
          this.mFontTypeface = Typeface.SERIF;
          return;
        }
        this.mFontTypeface = Typeface.SANS_SERIF;
      }
      return;
    }
    this.mFontTypeface = null;
    if (paramTintTypedArray.hasValue(R.styleable.TextAppearance_fontFamily))
      i = R.styleable.TextAppearance_fontFamily;
    else
      i = R.styleable.TextAppearance_android_fontFamily;
    int j = this.mFontWeight;
    int k = this.mStyle;
    if (!paramContext.isRestricted())
      paramContext = new ApplyTextViewCallback(this, j, k);
    while (true)
    {
      try
      {
        paramContext = paramTintTypedArray.getFont(i, this.mStyle, paramContext);
        if (paramContext != null)
          if ((Build.VERSION.SDK_INT >= 28) && (this.mFontWeight != -1))
          {
            paramContext = Typeface.create(paramContext, 0);
            j = this.mFontWeight;
            if ((this.mStyle & 0x2) == 0)
              break label395;
            bool1 = true;
            this.mFontTypeface = Typeface.create(paramContext, j, bool1);
          }
          else
          {
            this.mFontTypeface = paramContext;
          }
        if (this.mFontTypeface != null)
          break label401;
        bool1 = true;
        this.mAsyncFontPending = bool1;
      }
      catch (Resources.NotFoundException paramContext)
      {
      }
      catch (UnsupportedOperationException paramContext)
      {
      }
      if (this.mFontTypeface == null)
      {
        paramContext = paramTintTypedArray.getString(i);
        if (paramContext != null)
        {
          if ((Build.VERSION.SDK_INT >= 28) && (this.mFontWeight != -1))
          {
            paramContext = Typeface.create(paramContext, 0);
            i = this.mFontWeight;
            bool1 = bool2;
            if ((0x2 & this.mStyle) != 0)
              bool1 = true;
            this.mFontTypeface = Typeface.create(paramContext, i, bool1);
            return;
          }
          this.mFontTypeface = Typeface.create(paramContext, this.mStyle);
        }
      }
      return;
      label395: boolean bool1 = false;
      continue;
      label401: bool1 = false;
    }
  }

  void applyCompoundDrawablesTints()
  {
    Drawable[] arrayOfDrawable;
    if ((this.mDrawableLeftTint != null) || (this.mDrawableTopTint != null) || (this.mDrawableRightTint != null) || (this.mDrawableBottomTint != null))
    {
      arrayOfDrawable = this.mView.getCompoundDrawables();
      applyCompoundDrawableTint(arrayOfDrawable[0], this.mDrawableLeftTint);
      applyCompoundDrawableTint(arrayOfDrawable[1], this.mDrawableTopTint);
      applyCompoundDrawableTint(arrayOfDrawable[2], this.mDrawableRightTint);
      applyCompoundDrawableTint(arrayOfDrawable[3], this.mDrawableBottomTint);
    }
    if ((Build.VERSION.SDK_INT >= 17) && ((this.mDrawableStartTint != null) || (this.mDrawableEndTint != null)))
    {
      arrayOfDrawable = this.mView.getCompoundDrawablesRelative();
      applyCompoundDrawableTint(arrayOfDrawable[0], this.mDrawableStartTint);
      applyCompoundDrawableTint(arrayOfDrawable[2], this.mDrawableEndTint);
    }
  }

  @RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP_PREFIX})
  void autoSizeText()
  {
    this.mAutoSizeTextHelper.autoSizeText();
  }

  int getAutoSizeMaxTextSize()
  {
    return this.mAutoSizeTextHelper.getAutoSizeMaxTextSize();
  }

  int getAutoSizeMinTextSize()
  {
    return this.mAutoSizeTextHelper.getAutoSizeMinTextSize();
  }

  int getAutoSizeStepGranularity()
  {
    return this.mAutoSizeTextHelper.getAutoSizeStepGranularity();
  }

  int[] getAutoSizeTextAvailableSizes()
  {
    return this.mAutoSizeTextHelper.getAutoSizeTextAvailableSizes();
  }

  int getAutoSizeTextType()
  {
    return this.mAutoSizeTextHelper.getAutoSizeTextType();
  }

  @Nullable
  ColorStateList getCompoundDrawableTintList()
  {
    TintInfo localTintInfo = this.mDrawableTint;
    if (localTintInfo != null)
      return localTintInfo.mTintList;
    return null;
  }

  @Nullable
  PorterDuff.Mode getCompoundDrawableTintMode()
  {
    TintInfo localTintInfo = this.mDrawableTint;
    if (localTintInfo != null)
      return localTintInfo.mTintMode;
    return null;
  }

  @RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP_PREFIX})
  boolean isAutoSizeEnabled()
  {
    return this.mAutoSizeTextHelper.isAutoSizeEnabled();
  }

  @SuppressLint({"NewApi"})
  void loadFromAttributes(AttributeSet paramAttributeSet, int paramInt)
  {
    Context localContext = this.mView.getContext();
    AppCompatDrawableManager localAppCompatDrawableManager = AppCompatDrawableManager.get();
    Object localObject1 = TintTypedArray.obtainStyledAttributes(localContext, paramAttributeSet, R.styleable.AppCompatTextHelper, paramInt, 0);
    int k = ((TintTypedArray)localObject1).getResourceId(R.styleable.AppCompatTextHelper_android_textAppearance, -1);
    if (((TintTypedArray)localObject1).hasValue(R.styleable.AppCompatTextHelper_android_drawableLeft))
      this.mDrawableLeftTint = createTintInfo(localContext, localAppCompatDrawableManager, ((TintTypedArray)localObject1).getResourceId(R.styleable.AppCompatTextHelper_android_drawableLeft, 0));
    if (((TintTypedArray)localObject1).hasValue(R.styleable.AppCompatTextHelper_android_drawableTop))
      this.mDrawableTopTint = createTintInfo(localContext, localAppCompatDrawableManager, ((TintTypedArray)localObject1).getResourceId(R.styleable.AppCompatTextHelper_android_drawableTop, 0));
    if (((TintTypedArray)localObject1).hasValue(R.styleable.AppCompatTextHelper_android_drawableRight))
      this.mDrawableRightTint = createTintInfo(localContext, localAppCompatDrawableManager, ((TintTypedArray)localObject1).getResourceId(R.styleable.AppCompatTextHelper_android_drawableRight, 0));
    if (((TintTypedArray)localObject1).hasValue(R.styleable.AppCompatTextHelper_android_drawableBottom))
      this.mDrawableBottomTint = createTintInfo(localContext, localAppCompatDrawableManager, ((TintTypedArray)localObject1).getResourceId(R.styleable.AppCompatTextHelper_android_drawableBottom, 0));
    if (Build.VERSION.SDK_INT >= 17)
    {
      if (((TintTypedArray)localObject1).hasValue(R.styleable.AppCompatTextHelper_android_drawableStart))
        this.mDrawableStartTint = createTintInfo(localContext, localAppCompatDrawableManager, ((TintTypedArray)localObject1).getResourceId(R.styleable.AppCompatTextHelper_android_drawableStart, 0));
      if (((TintTypedArray)localObject1).hasValue(R.styleable.AppCompatTextHelper_android_drawableEnd))
        this.mDrawableEndTint = createTintInfo(localContext, localAppCompatDrawableManager, ((TintTypedArray)localObject1).getResourceId(R.styleable.AppCompatTextHelper_android_drawableEnd, 0));
    }
    ((TintTypedArray)localObject1).recycle();
    boolean bool3 = this.mView.getTransformationMethod() instanceof PasswordTransformationMethod;
    boolean bool1 = false;
    boolean bool2 = false;
    int i = 0;
    int j = 0;
    Object localObject11 = null;
    Object localObject3 = null;
    Object localObject9 = null;
    Object localObject10 = null;
    Object localObject2 = null;
    Object localObject8 = null;
    localObject1 = null;
    TintTypedArray localTintTypedArray1 = null;
    Object localObject4 = null;
    Object localObject6 = null;
    Object localObject5 = null;
    Object localObject7 = null;
    if (k != -1)
    {
      TintTypedArray localTintTypedArray2 = TintTypedArray.obtainStyledAttributes(localContext, k, R.styleable.TextAppearance);
      bool1 = bool2;
      i = j;
      if (!bool3)
      {
        bool1 = bool2;
        i = j;
        if (localTintTypedArray2.hasValue(R.styleable.TextAppearance_textAllCaps))
        {
          i = 1;
          bool1 = localTintTypedArray2.getBoolean(R.styleable.TextAppearance_textAllCaps, false);
        }
      }
      updateTypefaceAndStyle(localContext, localTintTypedArray2);
      localObject3 = localObject11;
      localObject2 = localObject10;
      localObject1 = localTintTypedArray1;
      if (Build.VERSION.SDK_INT < 23)
      {
        localObject4 = localObject9;
        if (localTintTypedArray2.hasValue(R.styleable.TextAppearance_android_textColor))
          localObject4 = localTintTypedArray2.getColorStateList(R.styleable.TextAppearance_android_textColor);
        localObject5 = localObject8;
        if (localTintTypedArray2.hasValue(R.styleable.TextAppearance_android_textColorHint))
          localObject5 = localTintTypedArray2.getColorStateList(R.styleable.TextAppearance_android_textColorHint);
        localObject3 = localObject4;
        localObject2 = localObject5;
        localObject1 = localTintTypedArray1;
        if (localTintTypedArray2.hasValue(R.styleable.TextAppearance_android_textColorLink))
        {
          localObject1 = localTintTypedArray2.getColorStateList(R.styleable.TextAppearance_android_textColorLink);
          localObject2 = localObject5;
          localObject3 = localObject4;
        }
      }
      localObject5 = localObject7;
      if (localTintTypedArray2.hasValue(R.styleable.TextAppearance_textLocale))
        localObject5 = localTintTypedArray2.getString(R.styleable.TextAppearance_textLocale);
      localObject4 = localObject6;
      if (Build.VERSION.SDK_INT >= 26)
      {
        localObject4 = localObject6;
        if (localTintTypedArray2.hasValue(R.styleable.TextAppearance_fontVariationSettings))
          localObject4 = localTintTypedArray2.getString(R.styleable.TextAppearance_fontVariationSettings);
      }
      localTintTypedArray2.recycle();
    }
    localTintTypedArray1 = TintTypedArray.obtainStyledAttributes(localContext, paramAttributeSet, R.styleable.TextAppearance, paramInt, 0);
    if ((!bool3) && (localTintTypedArray1.hasValue(R.styleable.TextAppearance_textAllCaps)))
    {
      bool1 = localTintTypedArray1.getBoolean(R.styleable.TextAppearance_textAllCaps, false);
      i = 1;
    }
    if (Build.VERSION.SDK_INT < 23)
    {
      if (localTintTypedArray1.hasValue(R.styleable.TextAppearance_android_textColor))
        localObject3 = localTintTypedArray1.getColorStateList(R.styleable.TextAppearance_android_textColor);
      if (localTintTypedArray1.hasValue(R.styleable.TextAppearance_android_textColorHint))
        localObject2 = localTintTypedArray1.getColorStateList(R.styleable.TextAppearance_android_textColorHint);
      if (localTintTypedArray1.hasValue(R.styleable.TextAppearance_android_textColorLink))
      {
        localObject1 = localTintTypedArray1.getColorStateList(R.styleable.TextAppearance_android_textColorLink);
        localObject6 = localObject2;
      }
      else
      {
        localObject6 = localObject2;
      }
    }
    else
    {
      localObject6 = localObject2;
    }
    if (localTintTypedArray1.hasValue(R.styleable.TextAppearance_textLocale))
      localObject5 = localTintTypedArray1.getString(R.styleable.TextAppearance_textLocale);
    localObject7 = localObject4;
    if (Build.VERSION.SDK_INT >= 26)
    {
      localObject7 = localObject4;
      if (localTintTypedArray1.hasValue(R.styleable.TextAppearance_fontVariationSettings))
        localObject7 = localTintTypedArray1.getString(R.styleable.TextAppearance_fontVariationSettings);
    }
    if (Build.VERSION.SDK_INT >= 28)
      if (localTintTypedArray1.hasValue(R.styleable.TextAppearance_android_textSize))
      {
        if (localTintTypedArray1.getDimensionPixelSize(R.styleable.TextAppearance_android_textSize, -1) == 0)
          this.mView.setTextSize(0, 0.0F);
      }
      else;
    localObject2 = localAppCompatDrawableManager;
    updateTypefaceAndStyle(localContext, localTintTypedArray1);
    localTintTypedArray1.recycle();
    if (localObject3 != null)
      this.mView.setTextColor((ColorStateList)localObject3);
    if (localObject6 != null)
      this.mView.setHintTextColor(localObject6);
    if (localObject1 != null)
      this.mView.setLinkTextColor((ColorStateList)localObject1);
    if ((!bool3) && (i != 0))
      setAllCaps(bool1);
    localObject1 = this.mFontTypeface;
    if (localObject1 != null)
      if (this.mFontWeight == -1)
        this.mView.setTypeface((Typeface)localObject1, this.mStyle);
      else
        this.mView.setTypeface((Typeface)localObject1);
    if (localObject7 != null)
      this.mView.setFontVariationSettings((String)localObject7);
    if (localObject5 != null)
      if (Build.VERSION.SDK_INT >= 24)
      {
        this.mView.setTextLocales(LocaleList.forLanguageTags((String)localObject5));
      }
      else if (Build.VERSION.SDK_INT >= 21)
      {
        localObject1 = ((String)localObject5).substring(0, ((String)localObject5).indexOf(','));
        this.mView.setTextLocale(Locale.forLanguageTag((String)localObject1));
      }
    this.mAutoSizeTextHelper.loadFromAttributes(paramAttributeSet, paramInt);
    if (AutoSizeableTextView.PLATFORM_SUPPORTS_AUTOSIZE)
      if (this.mAutoSizeTextHelper.getAutoSizeTextType() != 0)
      {
        localObject1 = this.mAutoSizeTextHelper.getAutoSizeTextAvailableSizes();
        if (localObject1.length > 0)
          if (this.mView.getAutoSizeStepGranularity() != -1.0F)
            this.mView.setAutoSizeTextTypeUniformWithConfiguration(this.mAutoSizeTextHelper.getAutoSizeMinTextSize(), this.mAutoSizeTextHelper.getAutoSizeMaxTextSize(), this.mAutoSizeTextHelper.getAutoSizeStepGranularity(), 0);
          else
            this.mView.setAutoSizeTextTypeUniformWithPresetSizes((int[])localObject1, 0);
      }
      else;
    localObject7 = TintTypedArray.obtainStyledAttributes(localContext, paramAttributeSet, R.styleable.AppCompatTextView);
    localObject4 = null;
    localObject5 = null;
    paramInt = R.styleable.AppCompatTextView_drawableLeftCompat;
    localObject1 = null;
    paramInt = ((TintTypedArray)localObject7).getResourceId(paramInt, -1);
    if (paramInt != -1)
      paramAttributeSet = ((AppCompatDrawableManager)localObject2).getDrawable(localContext, paramInt);
    else
      paramAttributeSet = null;
    localObject6 = localObject2;
    paramInt = R.styleable.AppCompatTextView_drawableTopCompat;
    localObject2 = null;
    paramInt = ((TintTypedArray)localObject7).getResourceId(paramInt, -1);
    if (paramInt != -1)
      localObject1 = localObject6.getDrawable(localContext, paramInt);
    paramInt = ((TintTypedArray)localObject7).getResourceId(R.styleable.AppCompatTextView_drawableRightCompat, -1);
    if (paramInt != -1)
      localObject2 = localObject6.getDrawable(localContext, paramInt);
    paramInt = ((TintTypedArray)localObject7).getResourceId(R.styleable.AppCompatTextView_drawableBottomCompat, -1);
    if (paramInt != -1)
      localObject3 = localObject6.getDrawable(localContext, paramInt);
    else
      localObject3 = null;
    paramInt = ((TintTypedArray)localObject7).getResourceId(R.styleable.AppCompatTextView_drawableStartCompat, -1);
    if (paramInt != -1)
      localObject4 = localObject6.getDrawable(localContext, paramInt);
    paramInt = ((TintTypedArray)localObject7).getResourceId(R.styleable.AppCompatTextView_drawableEndCompat, -1);
    if (paramInt != -1)
      localObject5 = localObject6.getDrawable(localContext, paramInt);
    setCompoundDrawables(paramAttributeSet, (Drawable)localObject1, (Drawable)localObject2, (Drawable)localObject3, (Drawable)localObject4, (Drawable)localObject5);
    if (((TintTypedArray)localObject7).hasValue(R.styleable.AppCompatTextView_drawableTint))
    {
      paramAttributeSet = ((TintTypedArray)localObject7).getColorStateList(R.styleable.AppCompatTextView_drawableTint);
      TextViewCompat.setCompoundDrawableTintList(this.mView, paramAttributeSet);
    }
    if (((TintTypedArray)localObject7).hasValue(R.styleable.AppCompatTextView_drawableTintMode))
    {
      paramAttributeSet = DrawableUtils.parseTintMode(((TintTypedArray)localObject7).getInt(R.styleable.AppCompatTextView_drawableTintMode, -1), null);
      TextViewCompat.setCompoundDrawableTintMode(this.mView, paramAttributeSet);
    }
    paramInt = ((TintTypedArray)localObject7).getDimensionPixelSize(R.styleable.AppCompatTextView_firstBaselineToTopHeight, -1);
    i = ((TintTypedArray)localObject7).getDimensionPixelSize(R.styleable.AppCompatTextView_lastBaselineToBottomHeight, -1);
    j = ((TintTypedArray)localObject7).getDimensionPixelSize(R.styleable.AppCompatTextView_lineHeight, -1);
    ((TintTypedArray)localObject7).recycle();
    if (paramInt != -1)
      TextViewCompat.setFirstBaselineToTopHeight(this.mView, paramInt);
    if (i != -1)
      TextViewCompat.setLastBaselineToBottomHeight(this.mView, i);
    if (j != -1)
      TextViewCompat.setLineHeight(this.mView, j);
  }

  @RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP_PREFIX})
  void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if (!AutoSizeableTextView.PLATFORM_SUPPORTS_AUTOSIZE)
      autoSizeText();
  }

  void onSetCompoundDrawables()
  {
    applyCompoundDrawablesTints();
  }

  void onSetTextAppearance(Context paramContext, int paramInt)
  {
    TintTypedArray localTintTypedArray = TintTypedArray.obtainStyledAttributes(paramContext, paramInt, R.styleable.TextAppearance);
    if (localTintTypedArray.hasValue(R.styleable.TextAppearance_textAllCaps))
      setAllCaps(localTintTypedArray.getBoolean(R.styleable.TextAppearance_textAllCaps, false));
    if ((Build.VERSION.SDK_INT < 23) && (localTintTypedArray.hasValue(R.styleable.TextAppearance_android_textColor)))
    {
      ColorStateList localColorStateList = localTintTypedArray.getColorStateList(R.styleable.TextAppearance_android_textColor);
      if (localColorStateList != null)
        this.mView.setTextColor(localColorStateList);
    }
    if ((localTintTypedArray.hasValue(R.styleable.TextAppearance_android_textSize)) && (localTintTypedArray.getDimensionPixelSize(R.styleable.TextAppearance_android_textSize, -1) == 0))
      this.mView.setTextSize(0, 0.0F);
    updateTypefaceAndStyle(paramContext, localTintTypedArray);
    if ((Build.VERSION.SDK_INT >= 26) && (localTintTypedArray.hasValue(R.styleable.TextAppearance_fontVariationSettings)))
    {
      paramContext = localTintTypedArray.getString(R.styleable.TextAppearance_fontVariationSettings);
      if (paramContext != null)
        this.mView.setFontVariationSettings(paramContext);
    }
    localTintTypedArray.recycle();
    paramContext = this.mFontTypeface;
    if (paramContext != null)
      this.mView.setTypeface(paramContext, this.mStyle);
  }

  @RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY})
  public void runOnUiThread(@NonNull Runnable paramRunnable)
  {
    this.mView.post(paramRunnable);
  }

  void setAllCaps(boolean paramBoolean)
  {
    this.mView.setAllCaps(paramBoolean);
  }

  void setAutoSizeTextTypeUniformWithConfiguration(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
    throws IllegalArgumentException
  {
    this.mAutoSizeTextHelper.setAutoSizeTextTypeUniformWithConfiguration(paramInt1, paramInt2, paramInt3, paramInt4);
  }

  void setAutoSizeTextTypeUniformWithPresetSizes(@NonNull int[] paramArrayOfInt, int paramInt)
    throws IllegalArgumentException
  {
    this.mAutoSizeTextHelper.setAutoSizeTextTypeUniformWithPresetSizes(paramArrayOfInt, paramInt);
  }

  void setAutoSizeTextTypeWithDefaults(int paramInt)
  {
    this.mAutoSizeTextHelper.setAutoSizeTextTypeWithDefaults(paramInt);
  }

  void setCompoundDrawableTintList(@Nullable ColorStateList paramColorStateList)
  {
    if (this.mDrawableTint == null)
      this.mDrawableTint = new TintInfo();
    TintInfo localTintInfo = this.mDrawableTint;
    localTintInfo.mTintList = paramColorStateList;
    boolean bool;
    if (paramColorStateList != null)
      bool = true;
    else
      bool = false;
    localTintInfo.mHasTintList = bool;
    setCompoundTints();
  }

  void setCompoundDrawableTintMode(@Nullable PorterDuff.Mode paramMode)
  {
    if (this.mDrawableTint == null)
      this.mDrawableTint = new TintInfo();
    TintInfo localTintInfo = this.mDrawableTint;
    localTintInfo.mTintMode = paramMode;
    boolean bool;
    if (paramMode != null)
      bool = true;
    else
      bool = false;
    localTintInfo.mHasTintMode = bool;
    setCompoundTints();
  }

  @RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP_PREFIX})
  void setTextSize(int paramInt, float paramFloat)
  {
    if ((!AutoSizeableTextView.PLATFORM_SUPPORTS_AUTOSIZE) && (!isAutoSizeEnabled()))
      setTextSizeInternal(paramInt, paramFloat);
  }

  @RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY})
  public void setTypefaceByCallback(@NonNull Typeface paramTypeface)
  {
    if (this.mAsyncFontPending)
    {
      this.mView.setTypeface(paramTypeface);
      this.mFontTypeface = paramTypeface;
    }
  }

  private static class ApplyTextViewCallback extends ResourcesCompat.FontCallback
  {
    private final int mFontWeight;
    private final WeakReference<AppCompatTextHelper> mParent;
    private final int mStyle;

    ApplyTextViewCallback(@NonNull AppCompatTextHelper paramAppCompatTextHelper, int paramInt1, int paramInt2)
    {
      this.mParent = new WeakReference(paramAppCompatTextHelper);
      this.mFontWeight = paramInt1;
      this.mStyle = paramInt2;
    }

    public void onFontRetrievalFailed(int paramInt)
    {
    }

    public void onFontRetrieved(@NonNull Typeface paramTypeface)
    {
      AppCompatTextHelper localAppCompatTextHelper = (AppCompatTextHelper)this.mParent.get();
      if (localAppCompatTextHelper == null)
        return;
      Typeface localTypeface = paramTypeface;
      if (Build.VERSION.SDK_INT >= 28)
      {
        int i = this.mFontWeight;
        localTypeface = paramTypeface;
        if (i != -1)
        {
          boolean bool;
          if ((this.mStyle & 0x2) != 0)
            bool = true;
          else
            bool = false;
          localTypeface = Typeface.create(paramTypeface, i, bool);
        }
      }
      localAppCompatTextHelper.runOnUiThread(new TypefaceApplyCallback(this.mParent, localTypeface));
    }

    private class TypefaceApplyCallback
      implements Runnable
    {
      private final WeakReference<AppCompatTextHelper> mParent;
      private final Typeface mTypeface;

      TypefaceApplyCallback(@NonNull Typeface arg2)
      {
        Object localObject1;
        this.mParent = localObject1;
        Object localObject2;
        this.mTypeface = localObject2;
      }

      public void run()
      {
        AppCompatTextHelper localAppCompatTextHelper = (AppCompatTextHelper)this.mParent.get();
        if (localAppCompatTextHelper == null)
          return;
        localAppCompatTextHelper.setTypefaceByCallback(this.mTypeface);
      }
    }
  }
}

/* Location:           C:\Users\eunna\dex2jar-2.0\classes-dex2jar.jar
 * Qualified Name:     androidx.appcompat.widget.AppCompatTextHelper
 * JD-Core Version:    0.6.2
 */