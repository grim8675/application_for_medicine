package androidx.arch.core.util;

public abstract interface Function<I, O>
{
  public abstract O apply(I paramI);
}

/* Location:           C:\Users\eunna\dex2jar-2.0\classes-dex2jar.jar
 * Qualified Name:     androidx.arch.core.util.Function
 * JD-Core Version:    0.6.2
 */