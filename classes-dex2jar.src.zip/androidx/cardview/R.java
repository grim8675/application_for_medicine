package androidx.cardview;

public final class R
{
  public static final class attr
  {
    public static final int cardBackgroundColor = 2130968667;
    public static final int cardCornerRadius = 2130968668;
    public static final int cardElevation = 2130968669;
    public static final int cardMaxElevation = 2130968670;
    public static final int cardPreventCornerOverlap = 2130968671;
    public static final int cardUseCompatPadding = 2130968672;
    public static final int cardViewStyle = 2130968673;
    public static final int contentPadding = 2130968743;
    public static final int contentPaddingBottom = 2130968744;
    public static final int contentPaddingLeft = 2130968745;
    public static final int contentPaddingRight = 2130968746;
    public static final int contentPaddingTop = 2130968747;
  }

  public static final class color
  {
    public static final int cardview_dark_background = 2131099686;
    public static final int cardview_light_background = 2131099687;
    public static final int cardview_shadow_end_color = 2131099688;
    public static final int cardview_shadow_start_color = 2131099689;
  }

  public static final class dimen
  {
    public static final int cardview_compat_inset_shadow = 2131165264;
    public static final int cardview_default_elevation = 2131165265;
    public static final int cardview_default_radius = 2131165266;
  }

  public static final class style
  {
    public static final int Base_CardView = 2131755020;
    public static final int CardView = 2131755204;
    public static final int CardView_Dark = 2131755205;
    public static final int CardView_Light = 2131755206;
  }

  public static final class styleable
  {
    public static final int[] CardView = { 16843071, 16843072, 2130968667, 2130968668, 2130968669, 2130968670, 2130968671, 2130968672, 2130968743, 2130968744, 2130968745, 2130968746, 2130968747 };
    public static final int CardView_android_minHeight = 1;
    public static final int CardView_android_minWidth = 0;
    public static final int CardView_cardBackgroundColor = 2;
    public static final int CardView_cardCornerRadius = 3;
    public static final int CardView_cardElevation = 4;
    public static final int CardView_cardMaxElevation = 5;
    public static final int CardView_cardPreventCornerOverlap = 6;
    public static final int CardView_cardUseCompatPadding = 7;
    public static final int CardView_contentPadding = 8;
    public static final int CardView_contentPaddingBottom = 9;
    public static final int CardView_contentPaddingLeft = 10;
    public static final int CardView_contentPaddingRight = 11;
    public static final int CardView_contentPaddingTop = 12;
  }
}

/* Location:           C:\Users\eunna\dex2jar-2.0\classes-dex2jar.jar
 * Qualified Name:     androidx.cardview.R
 * JD-Core Version:    0.6.2
 */