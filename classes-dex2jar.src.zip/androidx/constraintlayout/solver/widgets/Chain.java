package androidx.constraintlayout.solver.widgets;

import androidx.constraintlayout.solver.ArrayRow;
import androidx.constraintlayout.solver.LinearSystem;
import androidx.constraintlayout.solver.SolverVariable;
import java.util.ArrayList;

class Chain
{
  private static final boolean DEBUG = false;

  static void applyChainConstraints(ConstraintWidgetContainer paramConstraintWidgetContainer, LinearSystem paramLinearSystem, int paramInt)
  {
    int i;
    int j;
    ChainHead[] arrayOfChainHead;
    if (paramInt == 0)
    {
      i = 0;
      j = paramConstraintWidgetContainer.mHorizontalChainsSize;
      arrayOfChainHead = paramConstraintWidgetContainer.mHorizontalChainsArray;
    }
    else
    {
      i = 2;
      j = paramConstraintWidgetContainer.mVerticalChainsSize;
      arrayOfChainHead = paramConstraintWidgetContainer.mVerticalChainsArray;
    }
    int k = 0;
    while (k < j)
    {
      ChainHead localChainHead = arrayOfChainHead[k];
      localChainHead.define();
      if (paramConstraintWidgetContainer.optimizeFor(4))
      {
        if (!Optimizer.applyChainOptimized(paramConstraintWidgetContainer, paramLinearSystem, paramInt, i, localChainHead))
          applyChainConstraints(paramConstraintWidgetContainer, paramLinearSystem, paramInt, i, localChainHead);
      }
      else
        applyChainConstraints(paramConstraintWidgetContainer, paramLinearSystem, paramInt, i, localChainHead);
      k += 1;
    }
  }

  static void applyChainConstraints(ConstraintWidgetContainer paramConstraintWidgetContainer, LinearSystem paramLinearSystem, int paramInt1, int paramInt2, ChainHead paramChainHead)
  {
    ConstraintWidget localConstraintWidget1 = paramChainHead.mFirst;
    ConstraintWidget localConstraintWidget2 = paramChainHead.mLast;
    Object localObject2 = paramChainHead.mFirstVisibleWidget;
    ConstraintWidget localConstraintWidget3 = paramChainHead.mLastVisibleWidget;
    Object localObject7 = paramChainHead.mHead;
    float f1 = paramChainHead.mTotalWeight;
    Object localObject5 = paramChainHead.mFirstMatchConstraintWidget;
    Object localObject4 = paramChainHead.mLastMatchConstraintWidget;
    int n;
    if (paramConstraintWidgetContainer.mListDimensionBehaviors[paramInt1] == ConstraintWidget.DimensionBehaviour.WRAP_CONTENT)
      n = 1;
    else
      n = 0;
    int i;
    int j;
    int m;
    int k;
    Object localObject1;
    int i1;
    int i2;
    if (paramInt1 == 0)
    {
      if (((ConstraintWidget)localObject7).mHorizontalChainStyle == 0)
        i = 1;
      else
        i = 0;
      j = ((ConstraintWidget)localObject7).mHorizontalChainStyle;
      m = i;
      if (j == 1)
        i = 1;
      else
        i = 0;
      if (((ConstraintWidget)localObject7).mHorizontalChainStyle == 2)
        j = 1;
      else
        j = 0;
      k = i;
      localObject1 = localConstraintWidget1;
      i = 0;
      i1 = j;
    }
    else
    {
      if (((ConstraintWidget)localObject7).mVerticalChainStyle == 0)
        i = 1;
      else
        i = 0;
      j = ((ConstraintWidget)localObject7).mVerticalChainStyle;
      m = i;
      if (j == 1)
        i = 1;
      else
        i = 0;
      if (((ConstraintWidget)localObject7).mVerticalChainStyle == 2)
        j = 1;
      else
        j = 0;
      localObject1 = localConstraintWidget1;
      i2 = 0;
      k = i;
      i1 = j;
      i = i2;
    }
    Object localObject3;
    while (i == 0)
    {
      localObject3 = localObject1.mListAnchors[paramInt2];
      j = 4;
      if ((n != 0) || (i1 != 0))
        j = 1;
      i2 = ((ConstraintAnchor)localObject3).getMargin();
      if ((((ConstraintAnchor)localObject3).mTarget != null) && (localObject1 != localConstraintWidget1))
        i2 += ((ConstraintAnchor)localObject3).mTarget.getMargin();
      if ((i1 != 0) && (localObject1 != localConstraintWidget1) && (localObject1 != localObject2))
        j = 6;
      else if ((m != 0) && (n != 0))
        j = 4;
      if (((ConstraintAnchor)localObject3).mTarget != null)
      {
        if (localObject1 == localObject2)
          paramLinearSystem.addGreaterThan(((ConstraintAnchor)localObject3).mSolverVariable, ((ConstraintAnchor)localObject3).mTarget.mSolverVariable, i2, 5);
        else
          paramLinearSystem.addGreaterThan(((ConstraintAnchor)localObject3).mSolverVariable, ((ConstraintAnchor)localObject3).mTarget.mSolverVariable, i2, 6);
        paramLinearSystem.addEquality(((ConstraintAnchor)localObject3).mSolverVariable, ((ConstraintAnchor)localObject3).mTarget.mSolverVariable, i2, j);
      }
      if (n != 0)
      {
        if ((((ConstraintWidget)localObject1).getVisibility() != 8) && (localObject1.mListDimensionBehaviors[paramInt1] == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT))
          paramLinearSystem.addGreaterThan(localObject1.mListAnchors[(paramInt2 + 1)].mSolverVariable, localObject1.mListAnchors[paramInt2].mSolverVariable, 0, 5);
        paramLinearSystem.addGreaterThan(localObject1.mListAnchors[paramInt2].mSolverVariable, paramConstraintWidgetContainer.mListAnchors[paramInt2].mSolverVariable, 0, 6);
      }
      localObject3 = localObject1.mListAnchors[(paramInt2 + 1)].mTarget;
      if (localObject3 != null)
      {
        localObject3 = ((ConstraintAnchor)localObject3).mOwner;
        if ((localObject3.mListAnchors[paramInt2].mTarget != null) && (localObject3.mListAnchors[paramInt2].mTarget.mOwner == localObject1))
          break label594;
        localObject3 = null;
      }
      else
      {
        localObject3 = null;
      }
      label594: if (localObject3 != null)
        localObject1 = localObject3;
      else
        i = 1;
    }
    if ((localConstraintWidget3 != null) && (localConstraintWidget2.mListAnchors[(paramInt2 + 1)].mTarget != null))
    {
      localObject3 = localConstraintWidget3.mListAnchors[(paramInt2 + 1)];
      paramLinearSystem.addLowerThan(((ConstraintAnchor)localObject3).mSolverVariable, localConstraintWidget2.mListAnchors[(paramInt2 + 1)].mTarget.mSolverVariable, -((ConstraintAnchor)localObject3).getMargin(), 5);
    }
    if (n != 0)
      paramLinearSystem.addGreaterThan(paramConstraintWidgetContainer.mListAnchors[(paramInt2 + 1)].mSolverVariable, localConstraintWidget2.mListAnchors[(paramInt2 + 1)].mSolverVariable, localConstraintWidget2.mListAnchors[(paramInt2 + 1)].getMargin(), 6);
    paramConstraintWidgetContainer = paramChainHead.mWeightedMatchConstraintsWidgets;
    Object localObject6;
    SolverVariable localSolverVariable1;
    if (paramConstraintWidgetContainer != null)
    {
      i = paramConstraintWidgetContainer.size();
      if (i > 1)
      {
        float f2;
        if ((paramChainHead.mHasUndefinedWeights) && (!paramChainHead.mHasComplexMatchWeights))
          f2 = paramChainHead.mWidgetsMatchCount;
        else
          f2 = f1;
        localObject6 = null;
        j = 0;
        float f3 = 0.0F;
        localObject3 = localObject5;
        localObject5 = localObject6;
        while (j < i)
        {
          localObject6 = (ConstraintWidget)paramConstraintWidgetContainer.get(j);
          f1 = localObject6.mWeight[paramInt1];
          if (f1 < 0.0F)
          {
            if (paramChainHead.mHasComplexMatchWeights)
            {
              paramLinearSystem.addEquality(localObject6.mListAnchors[(paramInt2 + 1)].mSolverVariable, localObject6.mListAnchors[paramInt2].mSolverVariable, 0, 4);
              f1 = f3;
              break label1017;
            }
            f1 = 1.0F;
          }
          if (f1 == 0.0F)
          {
            paramLinearSystem.addEquality(localObject6.mListAnchors[(paramInt2 + 1)].mSolverVariable, localObject6.mListAnchors[paramInt2].mSolverVariable, 0, 6);
            f1 = f3;
          }
          else
          {
            if (localObject5 != null)
            {
              localSolverVariable1 = localObject5.mListAnchors[paramInt2].mSolverVariable;
              localObject5 = localObject5.mListAnchors[(paramInt2 + 1)].mSolverVariable;
              SolverVariable localSolverVariable2 = localObject6.mListAnchors[paramInt2].mSolverVariable;
              SolverVariable localSolverVariable3 = localObject6.mListAnchors[(paramInt2 + 1)].mSolverVariable;
              ArrayRow localArrayRow = paramLinearSystem.createRow();
              localArrayRow.createRowEqualMatchDimensions(f3, f2, f1, localSolverVariable1, (SolverVariable)localObject5, localSolverVariable2, localSolverVariable3);
              paramLinearSystem.addConstraint(localArrayRow);
            }
            localObject5 = localObject6;
          }
          label1017: j += 1;
          f3 = f1;
        }
        paramConstraintWidgetContainer = (ConstraintWidgetContainer)localObject1;
        paramConstraintWidgetContainer = (ConstraintWidgetContainer)localObject4;
      }
      else
      {
        paramConstraintWidgetContainer = (ConstraintWidgetContainer)localObject1;
        paramConstraintWidgetContainer = (ConstraintWidgetContainer)localObject4;
      }
    }
    else
    {
      localObject3 = paramConstraintWidgetContainer;
      paramConstraintWidgetContainer = (ConstraintWidgetContainer)localObject4;
      paramConstraintWidgetContainer = (ConstraintWidgetContainer)localObject1;
      paramConstraintWidgetContainer = (ConstraintWidgetContainer)localObject3;
    }
    if (localObject2 != null)
    {
      if ((localObject2 != localConstraintWidget3) && (i1 == 0))
        break label1275;
      localObject1 = localConstraintWidget1.mListAnchors[paramInt2];
      localObject3 = localConstraintWidget2.mListAnchors[(paramInt2 + 1)];
      if (localConstraintWidget1.mListAnchors[paramInt2].mTarget != null)
        paramConstraintWidgetContainer = localConstraintWidget1.mListAnchors[paramInt2].mTarget.mSolverVariable;
      else
        paramConstraintWidgetContainer = null;
      if (localConstraintWidget2.mListAnchors[(paramInt2 + 1)].mTarget != null)
        paramChainHead = localConstraintWidget2.mListAnchors[(paramInt2 + 1)].mTarget.mSolverVariable;
      else
        paramChainHead = null;
      if (localObject2 == localConstraintWidget3)
      {
        localObject1 = localObject2.mListAnchors[paramInt2];
        localObject3 = localObject2.mListAnchors[(paramInt2 + 1)];
      }
      if ((paramConstraintWidgetContainer != null) && (paramChainHead != null))
      {
        if (paramInt1 == 0)
          f1 = ((ConstraintWidget)localObject7).mHorizontalBiasPercent;
        else
          f1 = ((ConstraintWidget)localObject7).mVerticalBiasPercent;
        paramInt1 = ((ConstraintAnchor)localObject1).getMargin();
        i = ((ConstraintAnchor)localObject3).getMargin();
        paramLinearSystem.addCentering(((ConstraintAnchor)localObject1).mSolverVariable, paramConstraintWidgetContainer, paramInt1, f1, paramChainHead, ((ConstraintAnchor)localObject3).mSolverVariable, i, 5);
      }
      break label2361;
    }
    label1275: if ((m != 0) && (localObject2 != null))
    {
      if ((paramChainHead.mWidgetsMatchCount > 0) && (paramChainHead.mWidgetsCount == paramChainHead.mWidgetsMatchCount))
        n = 1;
      else
        n = 0;
      localObject1 = localObject2;
      paramConstraintWidgetContainer = (ConstraintWidgetContainer)localObject2;
      while (localObject1 != null)
      {
        for (paramChainHead = localObject1.mNextChainWidget[paramInt1]; (paramChainHead != null) && (paramChainHead.getVisibility() == 8); paramChainHead = paramChainHead.mNextChainWidget[paramInt1]);
        if ((paramChainHead == null) && (localObject1 != localConstraintWidget3))
          break label1754;
        localObject5 = localObject1.mListAnchors[paramInt2];
        localSolverVariable1 = ((ConstraintAnchor)localObject5).mSolverVariable;
        if (((ConstraintAnchor)localObject5).mTarget != null)
          localObject3 = ((ConstraintAnchor)localObject5).mTarget.mSolverVariable;
        else
          localObject3 = null;
        if (paramConstraintWidgetContainer != localObject1)
          localObject3 = paramConstraintWidgetContainer.mListAnchors[(paramInt2 + 1)].mSolverVariable;
        else if ((localObject1 == localObject2) && (paramConstraintWidgetContainer == localObject1))
          if (localConstraintWidget1.mListAnchors[paramInt2].mTarget != null)
            localObject3 = localConstraintWidget1.mListAnchors[paramInt2].mTarget.mSolverVariable;
          else
            localObject3 = null;
        localObject4 = null;
        i1 = ((ConstraintAnchor)localObject5).getMargin();
        j = localObject1.mListAnchors[(paramInt2 + 1)].getMargin();
        if (paramChainHead != null)
        {
          localObject4 = paramChainHead.mListAnchors[paramInt2];
          localObject5 = ((ConstraintAnchor)localObject4).mSolverVariable;
          localObject6 = localObject1.mListAnchors[(paramInt2 + 1)].mSolverVariable;
          localObject7 = localObject5;
        }
        else
        {
          localObject5 = localConstraintWidget2.mListAnchors[(paramInt2 + 1)].mTarget;
          if (localObject5 != null)
            localObject4 = ((ConstraintAnchor)localObject5).mSolverVariable;
          localObject6 = localObject1.mListAnchors[(paramInt2 + 1)].mSolverVariable;
          localObject7 = localObject4;
          localObject4 = localObject5;
        }
        i = j;
        if (localObject4 != null)
          i = j + ((ConstraintAnchor)localObject4).getMargin();
        j = i1;
        if (paramConstraintWidgetContainer != null)
          j = i1 + paramConstraintWidgetContainer.mListAnchors[(paramInt2 + 1)].getMargin();
        if ((localSolverVariable1 != null) && (localObject3 != null) && (localObject7 != null) && (localObject6 != null))
        {
          if (localObject1 == localObject2)
            j = localObject2.mListAnchors[paramInt2].getMargin();
          if (localObject1 == localConstraintWidget3)
            i = localConstraintWidget3.mListAnchors[(paramInt2 + 1)].getMargin();
          if (n != 0)
            i1 = 6;
          else
            i1 = 4;
          paramLinearSystem.addCentering(localSolverVariable1, (SolverVariable)localObject3, j, 0.5F, (SolverVariable)localObject7, (SolverVariable)localObject6, i, i1);
        }
        if (((ConstraintWidget)localObject1).getVisibility() != 8)
          paramConstraintWidgetContainer = (ConstraintWidgetContainer)localObject1;
        localObject1 = paramChainHead;
      }
    }
    else if ((k != 0) && (localObject2 != null))
    {
      if ((paramChainHead.mWidgetsMatchCount > 0) && (paramChainHead.mWidgetsCount == paramChainHead.mWidgetsMatchCount))
        i = 1;
      else
        i = 0;
      localObject1 = localObject2;
      paramChainHead = (ChainHead)localObject2;
      while (localObject1 != null)
      {
        for (paramConstraintWidgetContainer = localObject1.mNextChainWidget[paramInt1]; (paramConstraintWidgetContainer != null) && (paramConstraintWidgetContainer.getVisibility() == 8); paramConstraintWidgetContainer = paramConstraintWidgetContainer.mNextChainWidget[paramInt1]);
        if ((localObject1 != localObject2) && (localObject1 != localConstraintWidget3) && (paramConstraintWidgetContainer != null))
        {
          if (paramConstraintWidgetContainer == localConstraintWidget3)
            paramConstraintWidgetContainer = null;
          localObject4 = localObject1.mListAnchors[paramInt2];
          localObject7 = ((ConstraintAnchor)localObject4).mSolverVariable;
          if (((ConstraintAnchor)localObject4).mTarget != null)
            localObject3 = ((ConstraintAnchor)localObject4).mTarget.mSolverVariable;
          localSolverVariable1 = paramChainHead.mListAnchors[(paramInt2 + 1)].mSolverVariable;
          localObject3 = null;
          i1 = ((ConstraintAnchor)localObject4).getMargin();
          n = localObject1.mListAnchors[(paramInt2 + 1)].getMargin();
          if (paramConstraintWidgetContainer != null)
          {
            localObject5 = paramConstraintWidgetContainer.mListAnchors[paramInt2];
            localObject4 = ((ConstraintAnchor)localObject5).mSolverVariable;
            if (((ConstraintAnchor)localObject5).mTarget != null)
              localObject3 = ((ConstraintAnchor)localObject5).mTarget.mSolverVariable;
            else
              localObject3 = null;
            localObject6 = localObject4;
          }
          else
          {
            localObject4 = localObject1.mListAnchors[(paramInt2 + 1)].mTarget;
            if (localObject4 != null)
              localObject3 = ((ConstraintAnchor)localObject4).mSolverVariable;
            localObject5 = localObject1.mListAnchors[(paramInt2 + 1)].mSolverVariable;
            localObject6 = localObject3;
            localObject3 = localObject5;
            localObject5 = localObject4;
          }
          j = n;
          if (localObject5 != null)
            j = n + ((ConstraintAnchor)localObject5).getMargin();
          n = i1;
          if (paramChainHead != null)
            n = i1 + paramChainHead.mListAnchors[(paramInt2 + 1)].getMargin();
          if (i != 0)
            i1 = 6;
          else
            i1 = 4;
          if ((localObject7 != null) && (localSolverVariable1 != null) && (localObject6 != null) && (localObject3 != null))
            paramLinearSystem.addCentering((SolverVariable)localObject7, localSolverVariable1, n, 0.5F, (SolverVariable)localObject6, (SolverVariable)localObject3, j, i1);
        }
        if (((ConstraintWidget)localObject1).getVisibility() != 8)
          paramChainHead = (ChainHead)localObject1;
        localObject1 = paramConstraintWidgetContainer;
      }
      localObject1 = localObject2.mListAnchors[paramInt2];
      localObject3 = localConstraintWidget1.mListAnchors[paramInt2].mTarget;
      paramChainHead = localConstraintWidget3.mListAnchors[(paramInt2 + 1)];
      paramConstraintWidgetContainer = localConstraintWidget2.mListAnchors[(paramInt2 + 1)].mTarget;
      if (localObject3 != null)
        if (localObject2 != localConstraintWidget3)
          paramLinearSystem.addEquality(((ConstraintAnchor)localObject1).mSolverVariable, ((ConstraintAnchor)localObject3).mSolverVariable, ((ConstraintAnchor)localObject1).getMargin(), 5);
        else if (paramConstraintWidgetContainer != null)
          paramLinearSystem.addCentering(((ConstraintAnchor)localObject1).mSolverVariable, ((ConstraintAnchor)localObject3).mSolverVariable, ((ConstraintAnchor)localObject1).getMargin(), 0.5F, paramChainHead.mSolverVariable, paramConstraintWidgetContainer.mSolverVariable, paramChainHead.getMargin(), 5);
        else;
      if ((paramConstraintWidgetContainer != null) && (localObject2 != localConstraintWidget3))
        paramLinearSystem.addEquality(paramChainHead.mSolverVariable, paramConstraintWidgetContainer.mSolverVariable, -paramChainHead.getMargin(), 5);
    }
    label1754: if (((m != 0) || (k != 0)) && (localObject2 != null))
    {
      localObject1 = localObject2.mListAnchors[paramInt2];
      localObject3 = localConstraintWidget3.mListAnchors[(paramInt2 + 1)];
      if (((ConstraintAnchor)localObject1).mTarget != null)
        paramChainHead = ((ConstraintAnchor)localObject1).mTarget.mSolverVariable;
      else
        paramChainHead = null;
      if (((ConstraintAnchor)localObject3).mTarget != null)
        paramConstraintWidgetContainer = ((ConstraintAnchor)localObject3).mTarget.mSolverVariable;
      else
        paramConstraintWidgetContainer = null;
      if (localConstraintWidget2 != localConstraintWidget3)
      {
        paramConstraintWidgetContainer = localConstraintWidget2.mListAnchors[(paramInt2 + 1)];
        if (paramConstraintWidgetContainer.mTarget != null)
          paramConstraintWidgetContainer = paramConstraintWidgetContainer.mTarget.mSolverVariable;
        else
          paramConstraintWidgetContainer = null;
      }
      if (localObject2 == localConstraintWidget3)
      {
        localObject1 = localObject2.mListAnchors[paramInt2];
        localObject2 = localObject2.mListAnchors[(paramInt2 + 1)];
      }
      else
      {
        localObject2 = localObject3;
      }
      if ((paramChainHead != null) && (paramConstraintWidgetContainer != null))
      {
        paramInt1 = ((ConstraintAnchor)localObject1).getMargin();
        localObject3 = localConstraintWidget3;
        if (localConstraintWidget3 == null)
          localObject3 = localConstraintWidget2;
        paramInt2 = localObject3.mListAnchors[(paramInt2 + 1)].getMargin();
        paramLinearSystem.addCentering(((ConstraintAnchor)localObject1).mSolverVariable, paramChainHead, paramInt1, 0.5F, paramConstraintWidgetContainer, ((ConstraintAnchor)localObject2).mSolverVariable, paramInt2, 5);
        return;
      }
    }
    label2361:
  }
}

/* Location:           C:\Users\eunna\dex2jar-2.0\classes-dex2jar.jar
 * Qualified Name:     androidx.constraintlayout.solver.widgets.Chain
 * JD-Core Version:    0.6.2
 */