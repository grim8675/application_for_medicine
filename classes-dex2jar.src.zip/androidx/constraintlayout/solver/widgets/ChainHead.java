package androidx.constraintlayout.solver.widgets;

import java.util.ArrayList;

public class ChainHead
{
  private boolean mDefined;
  protected ConstraintWidget mFirst;
  protected ConstraintWidget mFirstMatchConstraintWidget;
  protected ConstraintWidget mFirstVisibleWidget;
  protected boolean mHasComplexMatchWeights;
  protected boolean mHasDefinedWeights;
  protected boolean mHasUndefinedWeights;
  protected ConstraintWidget mHead;
  private boolean mIsRtl = false;
  protected ConstraintWidget mLast;
  protected ConstraintWidget mLastMatchConstraintWidget;
  protected ConstraintWidget mLastVisibleWidget;
  private int mOrientation;
  protected float mTotalWeight = 0.0F;
  protected ArrayList<ConstraintWidget> mWeightedMatchConstraintsWidgets;
  protected int mWidgetsCount;
  protected int mWidgetsMatchCount;

  public ChainHead(ConstraintWidget paramConstraintWidget, int paramInt, boolean paramBoolean)
  {
    this.mFirst = paramConstraintWidget;
    this.mOrientation = paramInt;
    this.mIsRtl = paramBoolean;
  }

  private void defineChainProperties()
  {
    int j = this.mOrientation * 2;
    Object localObject3 = this.mFirst;
    Object localObject2 = this.mFirst;
    Object localObject1 = this.mFirst;
    int i = 0;
    boolean bool;
    while (true)
    {
      bool = true;
      if (i != 0)
        break;
      this.mWidgetsCount += 1;
      ((ConstraintWidget)localObject2).mNextChainWidget[this.mOrientation] = null;
      ((ConstraintWidget)localObject2).mListNextMatchConstraintsWidget[this.mOrientation] = null;
      if (((ConstraintWidget)localObject2).getVisibility() != 8)
      {
        if (this.mFirstVisibleWidget == null)
          this.mFirstVisibleWidget = ((ConstraintWidget)localObject2);
        this.mLastVisibleWidget = ((ConstraintWidget)localObject2);
        if ((localObject2.mListDimensionBehaviors[this.mOrientation] == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT) && ((localObject2.mResolvedMatchConstraintDefault[this.mOrientation] == 0) || (localObject2.mResolvedMatchConstraintDefault[this.mOrientation] == 3) || (localObject2.mResolvedMatchConstraintDefault[this.mOrientation] == 2)))
        {
          this.mWidgetsMatchCount += 1;
          float f = localObject2.mWeight[this.mOrientation];
          if (f > 0.0F)
            this.mTotalWeight += localObject2.mWeight[this.mOrientation];
          if (isMatchConstraintEqualityCandidate((ConstraintWidget)localObject2, this.mOrientation))
          {
            if (f < 0.0F)
              this.mHasUndefinedWeights = true;
            else
              this.mHasDefinedWeights = true;
            if (this.mWeightedMatchConstraintsWidgets == null)
              this.mWeightedMatchConstraintsWidgets = new ArrayList();
            this.mWeightedMatchConstraintsWidgets.add(localObject2);
          }
          if (this.mFirstMatchConstraintWidget == null)
            this.mFirstMatchConstraintWidget = ((ConstraintWidget)localObject2);
          localObject1 = this.mLastMatchConstraintWidget;
          if (localObject1 != null)
            ((ConstraintWidget)localObject1).mListNextMatchConstraintsWidget[this.mOrientation] = localObject2;
          this.mLastMatchConstraintWidget = ((ConstraintWidget)localObject2);
        }
      }
      if (localObject3 != localObject2)
        ((ConstraintWidget)localObject3).mNextChainWidget[this.mOrientation] = localObject2;
      localObject3 = localObject2;
      localObject1 = localObject2.mListAnchors[(j + 1)].mTarget;
      if (localObject1 != null)
      {
        ConstraintWidget localConstraintWidget = ((ConstraintAnchor)localObject1).mOwner;
        if (localConstraintWidget.mListAnchors[j].mTarget != null)
        {
          localObject1 = localConstraintWidget;
          if (localConstraintWidget.mListAnchors[j].mTarget.mOwner == localObject2);
        }
        else
        {
          localObject1 = null;
        }
      }
      else
      {
        localObject1 = null;
      }
      if (localObject1 != null)
        localObject2 = localObject1;
      else
        i = 1;
    }
    this.mLast = ((ConstraintWidget)localObject2);
    if ((this.mOrientation == 0) && (this.mIsRtl))
      this.mHead = this.mLast;
    else
      this.mHead = this.mFirst;
    if ((!this.mHasDefinedWeights) || (!this.mHasUndefinedWeights))
      bool = false;
    this.mHasComplexMatchWeights = bool;
  }

  private static boolean isMatchConstraintEqualityCandidate(ConstraintWidget paramConstraintWidget, int paramInt)
  {
    return (paramConstraintWidget.getVisibility() != 8) && (paramConstraintWidget.mListDimensionBehaviors[paramInt] == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT) && ((paramConstraintWidget.mResolvedMatchConstraintDefault[paramInt] == 0) || (paramConstraintWidget.mResolvedMatchConstraintDefault[paramInt] == 3));
  }

  public void define()
  {
    if (!this.mDefined)
      defineChainProperties();
    this.mDefined = true;
  }

  public ConstraintWidget getFirst()
  {
    return this.mFirst;
  }

  public ConstraintWidget getFirstMatchConstraintWidget()
  {
    return this.mFirstMatchConstraintWidget;
  }

  public ConstraintWidget getFirstVisibleWidget()
  {
    return this.mFirstVisibleWidget;
  }

  public ConstraintWidget getHead()
  {
    return this.mHead;
  }

  public ConstraintWidget getLast()
  {
    return this.mLast;
  }

  public ConstraintWidget getLastMatchConstraintWidget()
  {
    return this.mLastMatchConstraintWidget;
  }

  public ConstraintWidget getLastVisibleWidget()
  {
    return this.mLastVisibleWidget;
  }

  public float getTotalWeight()
  {
    return this.mTotalWeight;
  }
}

/* Location:           C:\Users\eunna\dex2jar-2.0\classes-dex2jar.jar
 * Qualified Name:     androidx.constraintlayout.solver.widgets.ChainHead
 * JD-Core Version:    0.6.2
 */