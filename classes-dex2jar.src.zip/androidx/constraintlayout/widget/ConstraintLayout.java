package androidx.constraintlayout.widget;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.Resources.NotFoundException;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.Build.VERSION;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.util.SparseIntArray;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;
import androidx.constraintlayout.solver.Metrics;
import androidx.constraintlayout.solver.widgets.Analyzer;
import androidx.constraintlayout.solver.widgets.ConstraintAnchor;
import androidx.constraintlayout.solver.widgets.ConstraintAnchor.Strength;
import androidx.constraintlayout.solver.widgets.ConstraintAnchor.Type;
import androidx.constraintlayout.solver.widgets.ConstraintWidget;
import androidx.constraintlayout.solver.widgets.ConstraintWidget.DimensionBehaviour;
import androidx.constraintlayout.solver.widgets.ConstraintWidgetContainer;
import androidx.constraintlayout.solver.widgets.ResolutionAnchor;
import androidx.constraintlayout.solver.widgets.ResolutionDimension;
import java.util.ArrayList;
import java.util.HashMap;

public class ConstraintLayout extends ViewGroup
{
  static final boolean ALLOWS_EMBEDDED = false;
  private static final boolean CACHE_MEASURED_DIMENSION = false;
  private static final boolean DEBUG = false;
  public static final int DESIGN_INFO_ID = 0;
  private static final String TAG = "ConstraintLayout";
  private static final boolean USE_CONSTRAINTS_HELPER = true;
  public static final String VERSION = "ConstraintLayout-1.1.3";
  SparseArray<View> mChildrenByIds = new SparseArray();
  private ArrayList<ConstraintHelper> mConstraintHelpers = new ArrayList(4);
  private ConstraintSet mConstraintSet = null;
  private int mConstraintSetId = -1;
  private HashMap<String, Integer> mDesignIds = new HashMap();
  private boolean mDirtyHierarchy = true;
  private int mLastMeasureHeight = -1;
  int mLastMeasureHeightMode = 0;
  int mLastMeasureHeightSize = -1;
  private int mLastMeasureWidth = -1;
  int mLastMeasureWidthMode = 0;
  int mLastMeasureWidthSize = -1;
  ConstraintWidgetContainer mLayoutWidget = new ConstraintWidgetContainer();
  private int mMaxHeight = 2147483647;
  private int mMaxWidth = 2147483647;
  private Metrics mMetrics;
  private int mMinHeight = 0;
  private int mMinWidth = 0;
  private int mOptimizationLevel = 7;
  private final ArrayList<ConstraintWidget> mVariableDimensionsWidgets = new ArrayList(100);

  public ConstraintLayout(Context paramContext)
  {
    super(paramContext);
    init(null);
  }

  public ConstraintLayout(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    init(paramAttributeSet);
  }

  public ConstraintLayout(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    init(paramAttributeSet);
  }

  private final ConstraintWidget getTargetWidget(int paramInt)
  {
    if (paramInt == 0)
      return this.mLayoutWidget;
    View localView2 = (View)this.mChildrenByIds.get(paramInt);
    View localView1 = localView2;
    if (localView2 == null)
    {
      localView2 = findViewById(paramInt);
      localView1 = localView2;
      if (localView2 != null)
      {
        localView1 = localView2;
        if (localView2 != this)
        {
          localView1 = localView2;
          if (localView2.getParent() == this)
          {
            onViewAdded(localView2);
            localView1 = localView2;
          }
        }
      }
    }
    if (localView1 == this)
      return this.mLayoutWidget;
    if (localView1 == null)
      return null;
    return ((LayoutParams)localView1.getLayoutParams()).widget;
  }

  private void init(AttributeSet paramAttributeSet)
  {
    this.mLayoutWidget.setCompanionWidget(this);
    this.mChildrenByIds.put(getId(), this);
    this.mConstraintSet = null;
    if (paramAttributeSet != null)
    {
      paramAttributeSet = getContext().obtainStyledAttributes(paramAttributeSet, R.styleable.ConstraintLayout_Layout);
      int j = paramAttributeSet.getIndexCount();
      int i = 0;
      while (i < j)
      {
        int k = paramAttributeSet.getIndex(i);
        if (k == R.styleable.ConstraintLayout_Layout_android_minWidth)
        {
          this.mMinWidth = paramAttributeSet.getDimensionPixelOffset(k, this.mMinWidth);
        }
        else if (k == R.styleable.ConstraintLayout_Layout_android_minHeight)
        {
          this.mMinHeight = paramAttributeSet.getDimensionPixelOffset(k, this.mMinHeight);
        }
        else if (k == R.styleable.ConstraintLayout_Layout_android_maxWidth)
        {
          this.mMaxWidth = paramAttributeSet.getDimensionPixelOffset(k, this.mMaxWidth);
        }
        else if (k == R.styleable.ConstraintLayout_Layout_android_maxHeight)
        {
          this.mMaxHeight = paramAttributeSet.getDimensionPixelOffset(k, this.mMaxHeight);
        }
        else if (k == R.styleable.ConstraintLayout_Layout_layout_optimizationLevel)
        {
          this.mOptimizationLevel = paramAttributeSet.getInt(k, this.mOptimizationLevel);
        }
        else if (k == R.styleable.ConstraintLayout_Layout_constraintSet)
        {
          k = paramAttributeSet.getResourceId(k, 0);
          try
          {
            this.mConstraintSet = new ConstraintSet();
            this.mConstraintSet.load(getContext(), k);
          }
          catch (Resources.NotFoundException localNotFoundException)
          {
            this.mConstraintSet = null;
          }
          this.mConstraintSetId = k;
        }
        i += 1;
      }
      paramAttributeSet.recycle();
    }
    this.mLayoutWidget.setOptimizationLevel(this.mOptimizationLevel);
  }

  private void internalMeasureChildren(int paramInt1, int paramInt2)
  {
    int i9 = getPaddingTop() + getPaddingBottom();
    int i10 = getPaddingLeft() + getPaddingRight();
    int i11 = getChildCount();
    int n = 0;
    while (true)
    {
      int i6 = paramInt1;
      Object localObject = this;
      if (n >= i11)
        break;
      View localView = ((ConstraintLayout)localObject).getChildAt(n);
      if (localView.getVisibility() != 8)
      {
        LayoutParams localLayoutParams = (LayoutParams)localView.getLayoutParams();
        ConstraintWidget localConstraintWidget = localLayoutParams.widget;
        if ((!localLayoutParams.isGuideline) && (!localLayoutParams.isHelper))
        {
          localConstraintWidget.setVisibility(localView.getVisibility());
          int i2 = localLayoutParams.width;
          int i3 = localLayoutParams.height;
          int m;
          if ((!localLayoutParams.horizontalDimensionFixed) && (!localLayoutParams.verticalDimensionFixed) && ((localLayoutParams.horizontalDimensionFixed) || (localLayoutParams.matchConstraintDefaultWidth != 1)) && (localLayoutParams.width != -1) && ((localLayoutParams.verticalDimensionFixed) || ((localLayoutParams.matchConstraintDefaultHeight != 1) && (localLayoutParams.height != -1))))
            m = 0;
          else
            m = 1;
          int i7 = 0;
          int j = 0;
          int i8 = 0;
          int i4 = 0;
          int k = 0;
          int i5 = 0;
          int i1 = i2;
          int i = i3;
          if (m != 0)
          {
            if (i2 == 0)
            {
              k = getChildMeasureSpec(i6, i10, -2);
              i = 1;
            }
            else if (i2 == -1)
            {
              k = getChildMeasureSpec(i6, i10, -1);
              i = i7;
            }
            else
            {
              i = i8;
              if (i2 == -2)
                i = 1;
              k = getChildMeasureSpec(i6, i10, i2);
            }
            if (i3 == 0)
            {
              m = getChildMeasureSpec(paramInt2, i9, -2);
              j = 1;
            }
            else if (i3 == -1)
            {
              m = getChildMeasureSpec(paramInt2, i9, -1);
              j = i4;
            }
            else
            {
              j = i5;
              if (i3 == -2)
                j = 1;
              m = getChildMeasureSpec(paramInt2, i9, i3);
            }
            localView.measure(k, m);
            localObject = ((ConstraintLayout)localObject).mMetrics;
            if (localObject != null)
              ((Metrics)localObject).measures += 1L;
            boolean bool;
            if (i2 == -2)
              bool = true;
            else
              bool = false;
            localConstraintWidget.setWidthWrapContent(bool);
            if (i3 == -2)
              bool = true;
            else
              bool = false;
            localConstraintWidget.setHeightWrapContent(bool);
            i1 = localView.getMeasuredWidth();
            m = localView.getMeasuredHeight();
            k = j;
            j = i;
            i = m;
          }
          localConstraintWidget.setWidth(i1);
          localConstraintWidget.setHeight(i);
          if (j != 0)
            localConstraintWidget.setWrapWidth(i1);
          if (k != 0)
            localConstraintWidget.setWrapHeight(i);
          if (localLayoutParams.needsBaseline)
          {
            i = localView.getBaseline();
            if (i != -1)
              localConstraintWidget.setBaselineDistance(i);
          }
        }
      }
      n += 1;
    }
  }

  private void internalMeasureDimensions(int paramInt1, int paramInt2)
  {
    Object localObject1 = this;
    int i1 = getPaddingTop() + getPaddingBottom();
    int i2 = getPaddingLeft() + getPaddingRight();
    int i3 = getChildCount();
    int i = 0;
    Object localObject2;
    Object localObject3;
    Object localObject4;
    int m;
    int n;
    int j;
    int k;
    Object localObject5;
    boolean bool;
    while (i < i3)
    {
      localObject2 = ((ConstraintLayout)localObject1).getChildAt(i);
      if (((View)localObject2).getVisibility() != 8)
      {
        localObject3 = (LayoutParams)((View)localObject2).getLayoutParams();
        localObject4 = ((LayoutParams)localObject3).widget;
        if ((!((LayoutParams)localObject3).isGuideline) && (!((LayoutParams)localObject3).isHelper))
        {
          ((ConstraintWidget)localObject4).setVisibility(((View)localObject2).getVisibility());
          m = ((LayoutParams)localObject3).width;
          n = ((LayoutParams)localObject3).height;
          if ((m != 0) && (n != 0))
          {
            j = 0;
            k = 0;
            if (m == -2)
              j = 1;
            i4 = getChildMeasureSpec(paramInt1, i2, m);
            if (n == -2)
              k = 1;
            ((View)localObject2).measure(i4, getChildMeasureSpec(paramInt2, i1, n));
            localObject5 = ((ConstraintLayout)localObject1).mMetrics;
            if (localObject5 != null)
              ((Metrics)localObject5).measures += 1L;
            if (m == -2)
              bool = true;
            else
              bool = false;
            ((ConstraintWidget)localObject4).setWidthWrapContent(bool);
            if (n == -2)
              bool = true;
            else
              bool = false;
            ((ConstraintWidget)localObject4).setHeightWrapContent(bool);
            m = ((View)localObject2).getMeasuredWidth();
            n = ((View)localObject2).getMeasuredHeight();
            ((ConstraintWidget)localObject4).setWidth(m);
            ((ConstraintWidget)localObject4).setHeight(n);
            if (j != 0)
              ((ConstraintWidget)localObject4).setWrapWidth(m);
            if (k != 0)
              ((ConstraintWidget)localObject4).setWrapHeight(n);
            if (((LayoutParams)localObject3).needsBaseline)
            {
              j = ((View)localObject2).getBaseline();
              if (j != -1)
                ((ConstraintWidget)localObject4).setBaselineDistance(j);
            }
            if ((((LayoutParams)localObject3).horizontalDimensionFixed) && (((LayoutParams)localObject3).verticalDimensionFixed))
            {
              ((ConstraintWidget)localObject4).getResolutionWidth().resolve(m);
              ((ConstraintWidget)localObject4).getResolutionHeight().resolve(n);
            }
          }
          else
          {
            ((ConstraintWidget)localObject4).getResolutionWidth().invalidate();
            ((ConstraintWidget)localObject4).getResolutionHeight().invalidate();
          }
        }
      }
      i += 1;
    }
    ((ConstraintLayout)localObject1).mLayoutWidget.solveGraph();
    int i4 = 0;
    while (true)
    {
      int i5 = paramInt1;
      if (i4 >= i3)
        break;
      localObject2 = ((ConstraintLayout)localObject1).getChildAt(i4);
      if (((View)localObject2).getVisibility() == 8)
      {
        localObject2 = localObject1;
      }
      else
      {
        localObject4 = (LayoutParams)((View)localObject2).getLayoutParams();
        localObject3 = ((LayoutParams)localObject4).widget;
        if (!((LayoutParams)localObject4).isGuideline)
        {
          if (((LayoutParams)localObject4).isHelper)
          {
            localObject2 = localObject1;
          }
          else
          {
            ((ConstraintWidget)localObject3).setVisibility(((View)localObject2).getVisibility());
            int i6 = ((LayoutParams)localObject4).width;
            int i7 = ((LayoutParams)localObject4).height;
            if ((i6 != 0) && (i7 != 0))
            {
              localObject2 = localObject1;
            }
            else
            {
              localObject5 = ((ConstraintWidget)localObject3).getAnchor(ConstraintAnchor.Type.LEFT).getResolutionNode();
              ResolutionAnchor localResolutionAnchor1 = ((ConstraintWidget)localObject3).getAnchor(ConstraintAnchor.Type.RIGHT).getResolutionNode();
              if ((((ConstraintWidget)localObject3).getAnchor(ConstraintAnchor.Type.LEFT).getTarget() != null) && (((ConstraintWidget)localObject3).getAnchor(ConstraintAnchor.Type.RIGHT).getTarget() != null))
                i = 1;
              else
                i = 0;
              ResolutionAnchor localResolutionAnchor2 = ((ConstraintWidget)localObject3).getAnchor(ConstraintAnchor.Type.TOP).getResolutionNode();
              ResolutionAnchor localResolutionAnchor3 = ((ConstraintWidget)localObject3).getAnchor(ConstraintAnchor.Type.BOTTOM).getResolutionNode();
              if ((((ConstraintWidget)localObject3).getAnchor(ConstraintAnchor.Type.TOP).getTarget() != null) && (((ConstraintWidget)localObject3).getAnchor(ConstraintAnchor.Type.BOTTOM).getTarget() != null))
                n = 1;
              else
                n = 0;
              if ((i6 == 0) && (i7 == 0) && (i != 0) && (n != 0))
              {
                localObject2 = localObject1;
              }
              else
              {
                k = 0;
                int i10 = 0;
                int i8 = 0;
                int i9 = 0;
                if (((ConstraintLayout)localObject1).mLayoutWidget.getHorizontalDimensionBehaviour() != ConstraintWidget.DimensionBehaviour.WRAP_CONTENT)
                  m = 1;
                else
                  m = 0;
                if (((ConstraintLayout)localObject1).mLayoutWidget.getVerticalDimensionBehaviour() != ConstraintWidget.DimensionBehaviour.WRAP_CONTENT)
                  j = 1;
                else
                  j = 0;
                if (m == 0)
                  ((ConstraintWidget)localObject3).getResolutionWidth().invalidate();
                if (j == 0)
                  ((ConstraintWidget)localObject3).getResolutionHeight().invalidate();
                if (i6 == 0)
                {
                  if ((m != 0) && (((ConstraintWidget)localObject3).isSpreadWidth()) && (i != 0) && (((ResolutionAnchor)localObject5).isResolved()) && (localResolutionAnchor1.isResolved()))
                  {
                    i6 = (int)(localResolutionAnchor1.getResolvedValue() - ((ResolutionAnchor)localObject5).getResolvedValue());
                    ((ConstraintWidget)localObject3).getResolutionWidth().resolve(i6);
                    i = getChildMeasureSpec(i5, i2, i6);
                    i5 = m;
                  }
                  else
                  {
                    i = getChildMeasureSpec(i5, i2, -2);
                    k = 1;
                    i5 = 0;
                  }
                }
                else if (i6 == -1)
                {
                  i = getChildMeasureSpec(i5, i2, -1);
                  i5 = m;
                }
                else
                {
                  k = i10;
                  if (i6 == -2)
                    k = 1;
                  i = getChildMeasureSpec(i5, i2, i6);
                  i5 = m;
                }
                if (i7 == 0)
                {
                  if ((j != 0) && (((ConstraintWidget)localObject3).isSpreadHeight()) && (n != 0) && (localResolutionAnchor2.isResolved()) && (localResolutionAnchor3.isResolved()))
                  {
                    float f1 = localResolutionAnchor3.getResolvedValue();
                    float f2 = localResolutionAnchor2.getResolvedValue();
                    n = j;
                    i7 = (int)(f1 - f2);
                    ((ConstraintWidget)localObject3).getResolutionHeight().resolve(i7);
                    j = getChildMeasureSpec(paramInt2, i1, i7);
                    m = i8;
                  }
                  else
                  {
                    j = getChildMeasureSpec(paramInt2, i1, -2);
                    m = 1;
                    n = 0;
                  }
                }
                else
                {
                  n = j;
                  if (i7 == -1)
                  {
                    j = getChildMeasureSpec(paramInt2, i1, -1);
                    m = i8;
                  }
                  else
                  {
                    m = i9;
                    if (i7 == -2)
                      m = 1;
                    j = getChildMeasureSpec(paramInt2, i1, i7);
                  }
                }
                ((View)localObject2).measure(i, j);
                localObject1 = this;
                localObject5 = ((ConstraintLayout)localObject1).mMetrics;
                if (localObject5 != null)
                  ((Metrics)localObject5).measures += 1L;
                if (i6 == -2)
                  bool = true;
                else
                  bool = false;
                ((ConstraintWidget)localObject3).setWidthWrapContent(bool);
                if (i7 == -2)
                  bool = true;
                else
                  bool = false;
                ((ConstraintWidget)localObject3).setHeightWrapContent(bool);
                i = ((View)localObject2).getMeasuredWidth();
                j = ((View)localObject2).getMeasuredHeight();
                ((ConstraintWidget)localObject3).setWidth(i);
                ((ConstraintWidget)localObject3).setHeight(j);
                if (k != 0)
                  ((ConstraintWidget)localObject3).setWrapWidth(i);
                if (m != 0)
                  ((ConstraintWidget)localObject3).setWrapHeight(j);
                if (i5 != 0)
                  ((ConstraintWidget)localObject3).getResolutionWidth().resolve(i);
                else
                  ((ConstraintWidget)localObject3).getResolutionWidth().remove();
                if (n != 0)
                  ((ConstraintWidget)localObject3).getResolutionHeight().resolve(j);
                else
                  ((ConstraintWidget)localObject3).getResolutionHeight().remove();
                if (((LayoutParams)localObject4).needsBaseline)
                {
                  i = ((View)localObject2).getBaseline();
                  localObject2 = localObject1;
                  if (i != -1)
                  {
                    ((ConstraintWidget)localObject3).setBaselineDistance(i);
                    localObject2 = localObject1;
                  }
                }
                else
                {
                  localObject2 = localObject1;
                }
              }
            }
          }
        }
        else
          localObject2 = localObject1;
      }
      i4 += 1;
      localObject1 = localObject2;
    }
  }

  private void setChildrenConstraints()
  {
    boolean bool = isInEditMode();
    int i3 = getChildCount();
    Object localObject4;
    Object localObject3;
    int j;
    if (bool)
    {
      i = 0;
      while (i < i3)
      {
        localObject4 = getChildAt(i);
        try
        {
          localObject3 = getResources().getResourceName(((View)localObject4).getId());
          setDesignInformation(0, localObject3, Integer.valueOf(((View)localObject4).getId()));
          j = ((String)localObject3).indexOf('/');
          Object localObject1 = localObject3;
          if (j != -1)
            localObject1 = ((String)localObject3).substring(j + 1);
          getTargetWidget(((View)localObject4).getId()).setDebugName((String)localObject1);
        }
        catch (Resources.NotFoundException localNotFoundException1)
        {
        }
        i += 1;
      }
    }
    int i = 0;
    while (i < i3)
    {
      localObject2 = getViewWidget(getChildAt(i));
      if (localObject2 != null)
        ((ConstraintWidget)localObject2).reset();
      i += 1;
    }
    if (this.mConstraintSetId != -1)
    {
      i = 0;
      while (i < i3)
      {
        localObject2 = getChildAt(i);
        if ((((View)localObject2).getId() == this.mConstraintSetId) && ((localObject2 instanceof Constraints)))
          this.mConstraintSet = ((Constraints)localObject2).getConstraintSet();
        i += 1;
      }
    }
    Object localObject2 = this.mConstraintSet;
    if (localObject2 != null)
      ((ConstraintSet)localObject2).applyToInternal(this);
    this.mLayoutWidget.removeAllChildren();
    int i2 = this.mConstraintHelpers.size();
    if (i2 > 0)
    {
      i = 0;
      while (i < i2)
      {
        ((ConstraintHelper)this.mConstraintHelpers.get(i)).updatePreLayout(this);
        i += 1;
      }
    }
    i = 0;
    while (i < i3)
    {
      localObject2 = getChildAt(i);
      if ((localObject2 instanceof Placeholder))
        ((Placeholder)localObject2).updatePreLayout(this);
      i += 1;
    }
    int i4 = 0;
    while (i4 < i3)
    {
      localObject3 = getChildAt(i4);
      localObject4 = getViewWidget((View)localObject3);
      if (localObject4 != null)
      {
        localObject2 = (LayoutParams)((View)localObject3).getLayoutParams();
        ((LayoutParams)localObject2).validate();
        if (((LayoutParams)localObject2).helped)
          ((LayoutParams)localObject2).helped = false;
        else if (bool)
          try
          {
            String str = getResources().getResourceName(((View)localObject3).getId());
            setDesignInformation(0, str, Integer.valueOf(((View)localObject3).getId()));
            str = str.substring(str.indexOf("id/") + 3);
            getTargetWidget(((View)localObject3).getId()).setDebugName(str);
          }
          catch (Resources.NotFoundException localNotFoundException2)
          {
          }
        ((ConstraintWidget)localObject4).setVisibility(((View)localObject3).getVisibility());
        if (((LayoutParams)localObject2).isInPlaceholder)
          ((ConstraintWidget)localObject4).setVisibility(8);
        ((ConstraintWidget)localObject4).setCompanionWidget(localObject3);
        this.mLayoutWidget.add((ConstraintWidget)localObject4);
        if ((!((LayoutParams)localObject2).verticalDimensionFixed) || (!((LayoutParams)localObject2).horizontalDimensionFixed))
          this.mVariableDimensionsWidgets.add(localObject4);
        float f;
        if (((LayoutParams)localObject2).isGuideline)
        {
          localObject3 = (androidx.constraintlayout.solver.widgets.Guideline)localObject4;
          i = ((LayoutParams)localObject2).resolvedGuideBegin;
          j = ((LayoutParams)localObject2).resolvedGuideEnd;
          f = ((LayoutParams)localObject2).resolvedGuidePercent;
          if (Build.VERSION.SDK_INT < 17)
          {
            i = ((LayoutParams)localObject2).guideBegin;
            j = ((LayoutParams)localObject2).guideEnd;
            f = ((LayoutParams)localObject2).guidePercent;
          }
          if (f != -1.0F)
            ((androidx.constraintlayout.solver.widgets.Guideline)localObject3).setGuidePercent(f);
          else if (i != -1)
            ((androidx.constraintlayout.solver.widgets.Guideline)localObject3).setGuideBegin(i);
          else if (j != -1)
            ((androidx.constraintlayout.solver.widgets.Guideline)localObject3).setGuideEnd(j);
        }
        while (true)
        {
          break;
          if ((((LayoutParams)localObject2).leftToLeft != -1) || (((LayoutParams)localObject2).leftToRight != -1) || (((LayoutParams)localObject2).rightToLeft != -1) || (((LayoutParams)localObject2).rightToRight != -1) || (((LayoutParams)localObject2).startToStart != -1) || (((LayoutParams)localObject2).startToEnd != -1) || (((LayoutParams)localObject2).endToStart != -1) || (((LayoutParams)localObject2).endToEnd != -1) || (((LayoutParams)localObject2).topToTop != -1) || (((LayoutParams)localObject2).topToBottom != -1) || (((LayoutParams)localObject2).bottomToTop != -1) || (((LayoutParams)localObject2).bottomToBottom != -1) || (((LayoutParams)localObject2).baselineToBaseline != -1) || (((LayoutParams)localObject2).editorAbsoluteX != -1) || (((LayoutParams)localObject2).editorAbsoluteY != -1) || (((LayoutParams)localObject2).circleConstraint != -1) || (((LayoutParams)localObject2).width == -1) || (((LayoutParams)localObject2).height == -1))
          {
            j = ((LayoutParams)localObject2).resolvedLeftToLeft;
            int k = ((LayoutParams)localObject2).resolvedLeftToRight;
            i = ((LayoutParams)localObject2).resolvedRightToLeft;
            int n = ((LayoutParams)localObject2).resolvedRightToRight;
            int m = ((LayoutParams)localObject2).resolveGoneLeftMargin;
            int i1 = ((LayoutParams)localObject2).resolveGoneRightMargin;
            f = ((LayoutParams)localObject2).resolvedHorizontalBias;
            if (Build.VERSION.SDK_INT < 17)
            {
              i = ((LayoutParams)localObject2).leftToLeft;
              n = ((LayoutParams)localObject2).leftToRight;
              i1 = ((LayoutParams)localObject2).rightToLeft;
              int i6 = ((LayoutParams)localObject2).rightToRight;
              k = ((LayoutParams)localObject2).goneLeftMargin;
              m = ((LayoutParams)localObject2).goneRightMargin;
              f = ((LayoutParams)localObject2).horizontalBias;
              if ((i == -1) && (n == -1))
              {
                if (((LayoutParams)localObject2).startToStart != -1)
                {
                  j = ((LayoutParams)localObject2).startToStart;
                  i = n;
                  break label953;
                }
                if (((LayoutParams)localObject2).startToEnd != -1)
                {
                  n = ((LayoutParams)localObject2).startToEnd;
                  j = i;
                  i = n;
                  break label953;
                }
              }
              j = i;
              i = n;
              label953: if ((i1 == -1) && (i6 == -1))
              {
                n = j;
                if (((LayoutParams)localObject2).endToStart != -1)
                {
                  i5 = ((LayoutParams)localObject2).endToStart;
                  j = n;
                  i1 = m;
                  m = k;
                  k = i;
                  n = i6;
                  i = i5;
                  break label1077;
                }
                if (((LayoutParams)localObject2).endToEnd != -1)
                {
                  i6 = ((LayoutParams)localObject2).endToEnd;
                  j = n;
                  i5 = m;
                  m = k;
                  k = i;
                  n = i6;
                  i = i1;
                  i1 = i5;
                  break label1077;
                }
              }
              int i5 = m;
              m = k;
              k = i;
              n = i6;
              i = i1;
              i1 = i5;
            }
            label1077: if (((LayoutParams)localObject2).circleConstraint != -1)
            {
              localObject3 = getTargetWidget(((LayoutParams)localObject2).circleConstraint);
              if (localObject3 != null)
                ((ConstraintWidget)localObject4).connectCircularConstraint((ConstraintWidget)localObject3, ((LayoutParams)localObject2).circleAngle, ((LayoutParams)localObject2).circleRadius);
            }
            else
            {
              if (j != -1)
              {
                localObject3 = getTargetWidget(j);
                if (localObject3 != null)
                  ((ConstraintWidget)localObject4).immediateConnect(ConstraintAnchor.Type.LEFT, (ConstraintWidget)localObject3, ConstraintAnchor.Type.LEFT, ((LayoutParams)localObject2).leftMargin, m);
              }
              else if (k != -1)
              {
                localObject3 = getTargetWidget(k);
                if (localObject3 != null)
                  ((ConstraintWidget)localObject4).immediateConnect(ConstraintAnchor.Type.LEFT, (ConstraintWidget)localObject3, ConstraintAnchor.Type.RIGHT, ((LayoutParams)localObject2).leftMargin, m);
              }
              localObject3 = localObject2;
              ConstraintWidget localConstraintWidget;
              if (i != -1)
              {
                localConstraintWidget = getTargetWidget(i);
                if (localConstraintWidget != null)
                  ((ConstraintWidget)localObject4).immediateConnect(ConstraintAnchor.Type.RIGHT, localConstraintWidget, ConstraintAnchor.Type.LEFT, ((LayoutParams)localObject3).rightMargin, i1);
              }
              else if (n != -1)
              {
                localConstraintWidget = getTargetWidget(n);
                if (localConstraintWidget != null)
                  ((ConstraintWidget)localObject4).immediateConnect(ConstraintAnchor.Type.RIGHT, localConstraintWidget, ConstraintAnchor.Type.RIGHT, ((LayoutParams)localObject3).rightMargin, i1);
              }
              if (((LayoutParams)localObject3).topToTop != -1)
              {
                localConstraintWidget = getTargetWidget(((LayoutParams)localObject3).topToTop);
                if (localConstraintWidget != null)
                  ((ConstraintWidget)localObject4).immediateConnect(ConstraintAnchor.Type.TOP, localConstraintWidget, ConstraintAnchor.Type.TOP, ((LayoutParams)localObject3).topMargin, ((LayoutParams)localObject3).goneTopMargin);
              }
              else if (((LayoutParams)localObject3).topToBottom != -1)
              {
                localConstraintWidget = getTargetWidget(((LayoutParams)localObject3).topToBottom);
                if (localConstraintWidget != null)
                  ((ConstraintWidget)localObject4).immediateConnect(ConstraintAnchor.Type.TOP, localConstraintWidget, ConstraintAnchor.Type.BOTTOM, ((LayoutParams)localObject3).topMargin, ((LayoutParams)localObject3).goneTopMargin);
              }
              if (((LayoutParams)localObject3).bottomToTop != -1)
              {
                localConstraintWidget = getTargetWidget(((LayoutParams)localObject3).bottomToTop);
                if (localConstraintWidget != null)
                  ((ConstraintWidget)localObject4).immediateConnect(ConstraintAnchor.Type.BOTTOM, localConstraintWidget, ConstraintAnchor.Type.TOP, ((LayoutParams)localObject3).bottomMargin, ((LayoutParams)localObject3).goneBottomMargin);
              }
              else if (((LayoutParams)localObject3).bottomToBottom != -1)
              {
                localConstraintWidget = getTargetWidget(((LayoutParams)localObject3).bottomToBottom);
                if (localConstraintWidget != null)
                  ((ConstraintWidget)localObject4).immediateConnect(ConstraintAnchor.Type.BOTTOM, localConstraintWidget, ConstraintAnchor.Type.BOTTOM, ((LayoutParams)localObject3).bottomMargin, ((LayoutParams)localObject3).goneBottomMargin);
              }
              if (((LayoutParams)localObject3).baselineToBaseline != -1)
              {
                Object localObject5 = (View)this.mChildrenByIds.get(((LayoutParams)localObject3).baselineToBaseline);
                localConstraintWidget = getTargetWidget(((LayoutParams)localObject3).baselineToBaseline);
                if ((localConstraintWidget != null) && (localObject5 != null) && ((((View)localObject5).getLayoutParams() instanceof LayoutParams)))
                {
                  localObject5 = (LayoutParams)((View)localObject5).getLayoutParams();
                  ((LayoutParams)localObject3).needsBaseline = true;
                  ((LayoutParams)localObject5).needsBaseline = true;
                  ((ConstraintWidget)localObject4).getAnchor(ConstraintAnchor.Type.BASELINE).connect(localConstraintWidget.getAnchor(ConstraintAnchor.Type.BASELINE), 0, -1, ConstraintAnchor.Strength.STRONG, 0, true);
                  ((ConstraintWidget)localObject4).getAnchor(ConstraintAnchor.Type.TOP).reset();
                  ((ConstraintWidget)localObject4).getAnchor(ConstraintAnchor.Type.BOTTOM).reset();
                }
              }
              if ((f >= 0.0F) && (f != 0.5F))
                ((ConstraintWidget)localObject4).setHorizontalBiasPercent(f);
              if ((((LayoutParams)localObject3).verticalBias >= 0.0F) && (((LayoutParams)localObject3).verticalBias != 0.5F))
                ((ConstraintWidget)localObject4).setVerticalBiasPercent(((LayoutParams)localObject3).verticalBias);
            }
            if ((bool) && ((((LayoutParams)localObject2).editorAbsoluteX != -1) || (((LayoutParams)localObject2).editorAbsoluteY != -1)))
              ((ConstraintWidget)localObject4).setOrigin(((LayoutParams)localObject2).editorAbsoluteX, ((LayoutParams)localObject2).editorAbsoluteY);
            if (!((LayoutParams)localObject2).horizontalDimensionFixed)
            {
              if (((LayoutParams)localObject2).width == -1)
              {
                ((ConstraintWidget)localObject4).setHorizontalDimensionBehaviour(ConstraintWidget.DimensionBehaviour.MATCH_PARENT);
                ((ConstraintWidget)localObject4).getAnchor(ConstraintAnchor.Type.LEFT).mMargin = ((LayoutParams)localObject2).leftMargin;
                ((ConstraintWidget)localObject4).getAnchor(ConstraintAnchor.Type.RIGHT).mMargin = ((LayoutParams)localObject2).rightMargin;
              }
              else
              {
                ((ConstraintWidget)localObject4).setHorizontalDimensionBehaviour(ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT);
                ((ConstraintWidget)localObject4).setWidth(0);
              }
            }
            else
            {
              ((ConstraintWidget)localObject4).setHorizontalDimensionBehaviour(ConstraintWidget.DimensionBehaviour.FIXED);
              ((ConstraintWidget)localObject4).setWidth(((LayoutParams)localObject2).width);
            }
            if (!((LayoutParams)localObject2).verticalDimensionFixed)
            {
              if (((LayoutParams)localObject2).height == -1)
              {
                ((ConstraintWidget)localObject4).setVerticalDimensionBehaviour(ConstraintWidget.DimensionBehaviour.MATCH_PARENT);
                ((ConstraintWidget)localObject4).getAnchor(ConstraintAnchor.Type.TOP).mMargin = ((LayoutParams)localObject2).topMargin;
                ((ConstraintWidget)localObject4).getAnchor(ConstraintAnchor.Type.BOTTOM).mMargin = ((LayoutParams)localObject2).bottomMargin;
              }
              else
              {
                ((ConstraintWidget)localObject4).setVerticalDimensionBehaviour(ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT);
                ((ConstraintWidget)localObject4).setHeight(0);
              }
            }
            else
            {
              ((ConstraintWidget)localObject4).setVerticalDimensionBehaviour(ConstraintWidget.DimensionBehaviour.FIXED);
              ((ConstraintWidget)localObject4).setHeight(((LayoutParams)localObject2).height);
            }
            if (((LayoutParams)localObject2).dimensionRatio != null)
              ((ConstraintWidget)localObject4).setDimensionRatio(((LayoutParams)localObject2).dimensionRatio);
            ((ConstraintWidget)localObject4).setHorizontalWeight(((LayoutParams)localObject2).horizontalWeight);
            ((ConstraintWidget)localObject4).setVerticalWeight(((LayoutParams)localObject2).verticalWeight);
            ((ConstraintWidget)localObject4).setHorizontalChainStyle(((LayoutParams)localObject2).horizontalChainStyle);
            ((ConstraintWidget)localObject4).setVerticalChainStyle(((LayoutParams)localObject2).verticalChainStyle);
            ((ConstraintWidget)localObject4).setHorizontalMatchStyle(((LayoutParams)localObject2).matchConstraintDefaultWidth, ((LayoutParams)localObject2).matchConstraintMinWidth, ((LayoutParams)localObject2).matchConstraintMaxWidth, ((LayoutParams)localObject2).matchConstraintPercentWidth);
            ((ConstraintWidget)localObject4).setVerticalMatchStyle(((LayoutParams)localObject2).matchConstraintDefaultHeight, ((LayoutParams)localObject2).matchConstraintMinHeight, ((LayoutParams)localObject2).matchConstraintMaxHeight, ((LayoutParams)localObject2).matchConstraintPercentHeight);
          }
        }
      }
      i4 += 1;
    }
  }

  private void setSelfDimensionBehaviour(int paramInt1, int paramInt2)
  {
    int i1 = View.MeasureSpec.getMode(paramInt1);
    paramInt1 = View.MeasureSpec.getSize(paramInt1);
    int k = View.MeasureSpec.getMode(paramInt2);
    paramInt2 = View.MeasureSpec.getSize(paramInt2);
    int m = getPaddingTop();
    int n = getPaddingBottom();
    int i2 = getPaddingLeft();
    int i3 = getPaddingRight();
    ConstraintWidget.DimensionBehaviour localDimensionBehaviour1 = ConstraintWidget.DimensionBehaviour.FIXED;
    ConstraintWidget.DimensionBehaviour localDimensionBehaviour2 = ConstraintWidget.DimensionBehaviour.FIXED;
    int j = 0;
    int i = 0;
    getLayoutParams();
    if (i1 != -2147483648)
    {
      if (i1 != 0)
      {
        if (i1 != 1073741824)
          paramInt1 = j;
        else
          paramInt1 = Math.min(this.mMaxWidth, paramInt1) - (i2 + i3);
      }
      else
      {
        localDimensionBehaviour1 = ConstraintWidget.DimensionBehaviour.WRAP_CONTENT;
        paramInt1 = j;
      }
    }
    else
      localDimensionBehaviour1 = ConstraintWidget.DimensionBehaviour.WRAP_CONTENT;
    if (k != -2147483648)
    {
      if (k != 0)
      {
        if (k != 1073741824)
          paramInt2 = i;
        else
          paramInt2 = Math.min(this.mMaxHeight, paramInt2) - (m + n);
      }
      else
      {
        localDimensionBehaviour2 = ConstraintWidget.DimensionBehaviour.WRAP_CONTENT;
        paramInt2 = i;
      }
    }
    else
      localDimensionBehaviour2 = ConstraintWidget.DimensionBehaviour.WRAP_CONTENT;
    this.mLayoutWidget.setMinWidth(0);
    this.mLayoutWidget.setMinHeight(0);
    this.mLayoutWidget.setHorizontalDimensionBehaviour(localDimensionBehaviour1);
    this.mLayoutWidget.setWidth(paramInt1);
    this.mLayoutWidget.setVerticalDimensionBehaviour(localDimensionBehaviour2);
    this.mLayoutWidget.setHeight(paramInt2);
    this.mLayoutWidget.setMinWidth(this.mMinWidth - getPaddingLeft() - getPaddingRight());
    this.mLayoutWidget.setMinHeight(this.mMinHeight - getPaddingTop() - getPaddingBottom());
  }

  private void updateHierarchy()
  {
    int m = getChildCount();
    int k = 0;
    int i = 0;
    int j;
    while (true)
    {
      j = k;
      if (i >= m)
        break;
      if (getChildAt(i).isLayoutRequested())
      {
        j = 1;
        break;
      }
      i += 1;
    }
    if (j != 0)
    {
      this.mVariableDimensionsWidgets.clear();
      setChildrenConstraints();
    }
  }

  private void updatePostMeasures()
  {
    int j = getChildCount();
    int i = 0;
    while (i < j)
    {
      View localView = getChildAt(i);
      if ((localView instanceof Placeholder))
        ((Placeholder)localView).updatePostMeasure(this);
      i += 1;
    }
    j = this.mConstraintHelpers.size();
    if (j > 0)
    {
      i = 0;
      while (i < j)
      {
        ((ConstraintHelper)this.mConstraintHelpers.get(i)).updatePostMeasure(this);
        i += 1;
      }
    }
  }

  public void addView(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams)
  {
    super.addView(paramView, paramInt, paramLayoutParams);
    if (Build.VERSION.SDK_INT < 14)
      onViewAdded(paramView);
  }

  protected boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams)
  {
    return paramLayoutParams instanceof LayoutParams;
  }

  public void dispatchDraw(Canvas paramCanvas)
  {
    super.dispatchDraw(paramCanvas);
    if (isInEditMode())
    {
      int i = getChildCount();
      float f3 = getWidth();
      float f2 = getHeight();
      float f1 = 1080.0F;
      int j = 0;
      while (j < i)
      {
        Object localObject = getChildAt(j);
        if (((View)localObject).getVisibility() != 8)
        {
          localObject = ((View)localObject).getTag();
          if ((localObject != null) && ((localObject instanceof String)))
          {
            localObject = ((String)localObject).split(",");
            if (localObject.length == 4)
            {
              int m = Integer.parseInt(localObject[0]);
              int i1 = Integer.parseInt(localObject[1]);
              int n = Integer.parseInt(localObject[2]);
              int k = Integer.parseInt(localObject[3]);
              m = (int)(m / f1 * f3);
              i1 = (int)(i1 / 1920.0F * f2);
              n = (int)(n / f1 * f3);
              k = (int)(k / 1920.0F * f2);
              localObject = new Paint();
              ((Paint)localObject).setColor(-65536);
              paramCanvas.drawLine(m, i1, m + n, i1, (Paint)localObject);
              paramCanvas.drawLine(m + n, i1, m + n, i1 + k, (Paint)localObject);
              paramCanvas.drawLine(m + n, i1 + k, m, i1 + k, (Paint)localObject);
              paramCanvas.drawLine(m, i1 + k, m, i1, (Paint)localObject);
              ((Paint)localObject).setColor(-16711936);
              paramCanvas.drawLine(m, i1, m + n, i1 + k, (Paint)localObject);
              paramCanvas.drawLine(m, i1 + k, m + n, i1, (Paint)localObject);
            }
            else;
          }
        }
        j += 1;
      }
      return;
    }
  }

  public void fillMetrics(Metrics paramMetrics)
  {
    this.mMetrics = paramMetrics;
    this.mLayoutWidget.fillMetrics(paramMetrics);
  }

  protected LayoutParams generateDefaultLayoutParams()
  {
    return new LayoutParams(-2, -2);
  }

  protected ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams)
  {
    return new LayoutParams(paramLayoutParams);
  }

  public LayoutParams generateLayoutParams(AttributeSet paramAttributeSet)
  {
    return new LayoutParams(getContext(), paramAttributeSet);
  }

  public Object getDesignInformation(int paramInt, Object paramObject)
  {
    if ((paramInt == 0) && ((paramObject instanceof String)))
    {
      paramObject = (String)paramObject;
      HashMap localHashMap = this.mDesignIds;
      if ((localHashMap != null) && (localHashMap.containsKey(paramObject)))
        return this.mDesignIds.get(paramObject);
    }
    return null;
  }

  public int getMaxHeight()
  {
    return this.mMaxHeight;
  }

  public int getMaxWidth()
  {
    return this.mMaxWidth;
  }

  public int getMinHeight()
  {
    return this.mMinHeight;
  }

  public int getMinWidth()
  {
    return this.mMinWidth;
  }

  public int getOptimizationLevel()
  {
    return this.mLayoutWidget.getOptimizationLevel();
  }

  public View getViewById(int paramInt)
  {
    return (View)this.mChildrenByIds.get(paramInt);
  }

  public final ConstraintWidget getViewWidget(View paramView)
  {
    if (paramView == this)
      return this.mLayoutWidget;
    if (paramView == null)
      return null;
    return ((LayoutParams)paramView.getLayoutParams()).widget;
  }

  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    paramInt2 = getChildCount();
    paramBoolean = isInEditMode();
    paramInt1 = 0;
    while (paramInt1 < paramInt2)
    {
      View localView = getChildAt(paramInt1);
      LayoutParams localLayoutParams = (LayoutParams)localView.getLayoutParams();
      ConstraintWidget localConstraintWidget = localLayoutParams.widget;
      if (((localView.getVisibility() != 8) || (localLayoutParams.isGuideline) || (localLayoutParams.isHelper) || (paramBoolean)) && (!localLayoutParams.isInPlaceholder))
      {
        paramInt3 = localConstraintWidget.getDrawX();
        paramInt4 = localConstraintWidget.getDrawY();
        int i = localConstraintWidget.getWidth() + paramInt3;
        int j = localConstraintWidget.getHeight() + paramInt4;
        localView.layout(paramInt3, paramInt4, i, j);
        if ((localView instanceof Placeholder))
        {
          localView = ((Placeholder)localView).getContent();
          if (localView != null)
          {
            localView.setVisibility(0);
            localView.layout(paramInt3, paramInt4, i, j);
          }
        }
      }
      paramInt1 += 1;
    }
    paramInt2 = this.mConstraintHelpers.size();
    if (paramInt2 > 0)
    {
      paramInt1 = 0;
      while (paramInt1 < paramInt2)
      {
        ((ConstraintHelper)this.mConstraintHelpers.get(paramInt1)).updatePostLayout(this);
        paramInt1 += 1;
      }
    }
  }

  protected void onMeasure(int paramInt1, int paramInt2)
  {
    System.currentTimeMillis();
    int k = View.MeasureSpec.getMode(paramInt1);
    int m = View.MeasureSpec.getSize(paramInt1);
    int i1 = View.MeasureSpec.getMode(paramInt2);
    int i2 = View.MeasureSpec.getSize(paramInt2);
    int j = getPaddingLeft();
    int i7 = getPaddingTop();
    this.mLayoutWidget.setX(j);
    this.mLayoutWidget.setY(i7);
    this.mLayoutWidget.setMaxWidth(this.mMaxWidth);
    this.mLayoutWidget.setMaxHeight(this.mMaxHeight);
    Object localObject;
    if (Build.VERSION.SDK_INT >= 17)
    {
      localObject = this.mLayoutWidget;
      boolean bool;
      if (getLayoutDirection() == 1)
        bool = true;
      else
        bool = false;
      ((ConstraintWidgetContainer)localObject).setRtl(bool);
    }
    setSelfDimensionBehaviour(paramInt1, paramInt2);
    int n = this.mLayoutWidget.getWidth();
    int i6 = this.mLayoutWidget.getHeight();
    int i = 0;
    if (this.mDirtyHierarchy)
    {
      this.mDirtyHierarchy = false;
      updateHierarchy();
      i = 1;
    }
    int i4;
    if ((this.mOptimizationLevel & 0x8) == 8)
      i4 = 1;
    else
      i4 = 0;
    if (i4 != 0)
    {
      this.mLayoutWidget.preOptimize();
      this.mLayoutWidget.optimizeForDimensions(n, i6);
      internalMeasureDimensions(paramInt1, paramInt2);
    }
    else
    {
      internalMeasureChildren(paramInt1, paramInt2);
    }
    updatePostMeasures();
    if ((getChildCount() > 0) && (i != 0))
      Analyzer.determineGroups(this.mLayoutWidget);
    if (this.mLayoutWidget.mGroupsWrapOptimized)
    {
      if ((this.mLayoutWidget.mHorizontalWrapOptimized) && (k == -2147483648))
      {
        if (this.mLayoutWidget.mWrapFixedWidth < m)
        {
          localObject = this.mLayoutWidget;
          ((ConstraintWidgetContainer)localObject).setWidth(((ConstraintWidgetContainer)localObject).mWrapFixedWidth);
        }
        this.mLayoutWidget.setHorizontalDimensionBehaviour(ConstraintWidget.DimensionBehaviour.FIXED);
      }
      if ((this.mLayoutWidget.mVerticalWrapOptimized) && (i1 == -2147483648))
      {
        if (this.mLayoutWidget.mWrapFixedHeight < i2)
        {
          localObject = this.mLayoutWidget;
          ((ConstraintWidgetContainer)localObject).setHeight(((ConstraintWidgetContainer)localObject).mWrapFixedHeight);
        }
        this.mLayoutWidget.setVerticalDimensionBehaviour(ConstraintWidget.DimensionBehaviour.FIXED);
      }
    }
    i = this.mOptimizationLevel;
    int i3 = 0;
    int i5;
    if ((i & 0x20) == 32)
    {
      i = this.mLayoutWidget.getWidth();
      i5 = this.mLayoutWidget.getHeight();
      if ((this.mLastMeasureWidth != i) && (k == 1073741824))
        Analyzer.setPosition(this.mLayoutWidget.mWidgetGroups, 0, i);
      if ((this.mLastMeasureHeight != i5) && (i1 == 1073741824))
        Analyzer.setPosition(this.mLayoutWidget.mWidgetGroups, 1, i5);
      if ((this.mLayoutWidget.mHorizontalWrapOptimized) && (this.mLayoutWidget.mWrapFixedWidth > m))
        Analyzer.setPosition(this.mLayoutWidget.mWidgetGroups, 0, m);
      if ((this.mLayoutWidget.mVerticalWrapOptimized) && (this.mLayoutWidget.mWrapFixedHeight > i2))
        Analyzer.setPosition(this.mLayoutWidget.mWidgetGroups, 1, i2);
      else;
    }
    int i13 = 0;
    if (getChildCount() > 0)
      solveLinearSystem("First pass");
    i1 = this.mVariableDimensionsWidgets.size();
    int i15 = getPaddingBottom() + i7;
    int i16 = j + getPaddingRight();
    if (i1 > 0)
    {
      i2 = 0;
      if (this.mLayoutWidget.getHorizontalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.WRAP_CONTENT)
        k = 1;
      else
        k = 0;
      if (this.mLayoutWidget.getVerticalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.WRAP_CONTENT)
        i5 = 1;
      else
        i5 = 0;
      j = Math.max(this.mLayoutWidget.getWidth(), this.mMinWidth);
      i = Math.max(this.mLayoutWidget.getHeight(), this.mMinHeight);
      int i8 = 0;
      m = 0;
      View localView;
      while (i8 < i1)
      {
        localObject = (ConstraintWidget)this.mVariableDimensionsWidgets.get(i8);
        localView = (View)((ConstraintWidget)localObject).getCompanionWidget();
        int i9;
        int i10;
        int i11;
        int i12;
        if (localView == null)
        {
          i9 = j;
          i10 = i;
          i11 = m;
          i12 = i2;
        }
        else
        {
          LayoutParams localLayoutParams = (LayoutParams)localView.getLayoutParams();
          if (!localLayoutParams.isHelper)
          {
            if (localLayoutParams.isGuideline)
            {
              i9 = j;
              i10 = i;
              i11 = m;
              i12 = i2;
            }
            else if (localView.getVisibility() == 8)
            {
              i9 = j;
              i10 = i;
              i11 = m;
              i12 = i2;
            }
            else if ((i4 != 0) && (((ConstraintWidget)localObject).getResolutionWidth().isResolved()) && (((ConstraintWidget)localObject).getResolutionHeight().isResolved()))
            {
              i9 = j;
              i10 = i;
              i11 = m;
              i12 = i2;
            }
            else
            {
              if ((localLayoutParams.width == -2) && (localLayoutParams.horizontalDimensionFixed))
                i9 = getChildMeasureSpec(paramInt1, i16, localLayoutParams.width);
              else
                i9 = View.MeasureSpec.makeMeasureSpec(((ConstraintWidget)localObject).getWidth(), 1073741824);
              if ((localLayoutParams.height == -2) && (localLayoutParams.verticalDimensionFixed))
                i10 = getChildMeasureSpec(paramInt2, i15, localLayoutParams.height);
              else
                i10 = View.MeasureSpec.makeMeasureSpec(((ConstraintWidget)localObject).getHeight(), 1073741824);
              localView.measure(i9, i10);
              Metrics localMetrics = this.mMetrics;
              if (localMetrics != null)
                localMetrics.additionalMeasures += 1L;
              int i14 = i3 + 1;
              i3 = localView.getMeasuredWidth();
              i9 = localView.getMeasuredHeight();
              if (i3 != ((ConstraintWidget)localObject).getWidth())
              {
                ((ConstraintWidget)localObject).setWidth(i3);
                if (i4 != 0)
                  ((ConstraintWidget)localObject).getResolutionWidth().resolve(i3);
                if ((k != 0) && (((ConstraintWidget)localObject).getRight() > j))
                  j = Math.max(j, ((ConstraintWidget)localObject).getRight() + ((ConstraintWidget)localObject).getAnchor(ConstraintAnchor.Type.RIGHT).getMargin());
                i3 = 1;
              }
              else
              {
                i3 = i2;
              }
              i2 = i;
              if (i9 != ((ConstraintWidget)localObject).getHeight())
              {
                ((ConstraintWidget)localObject).setHeight(i9);
                if (i4 != 0)
                  ((ConstraintWidget)localObject).getResolutionHeight().resolve(i9);
                i2 = i;
                if (i5 != 0)
                {
                  i2 = i;
                  if (((ConstraintWidget)localObject).getBottom() > i)
                    i2 = Math.max(i, ((ConstraintWidget)localObject).getBottom() + ((ConstraintWidget)localObject).getAnchor(ConstraintAnchor.Type.BOTTOM).getMargin());
                }
                i3 = 1;
              }
              i = i3;
              if (localLayoutParams.needsBaseline)
              {
                i9 = localView.getBaseline();
                i = i3;
                if (i9 != -1)
                {
                  i = i3;
                  if (i9 != ((ConstraintWidget)localObject).getBaselineDistance())
                  {
                    ((ConstraintWidget)localObject).setBaselineDistance(i9);
                    i = 1;
                  }
                }
              }
              i9 = j;
              i10 = i2;
              i11 = m;
              i3 = i14;
              i12 = i;
              if (Build.VERSION.SDK_INT >= 11)
              {
                i11 = combineMeasuredStates(m, localView.getMeasuredState());
                i9 = j;
                i10 = i2;
                i3 = i14;
                i12 = i;
              }
            }
          }
          else
          {
            i12 = i2;
            i11 = m;
            i10 = i;
            i9 = j;
          }
        }
        i8 += 1;
        j = i9;
        i = i10;
        m = i11;
        i2 = i12;
      }
      i3 = i1;
      if (i2 != 0)
      {
        this.mLayoutWidget.setWidth(n);
        this.mLayoutWidget.setHeight(i6);
        if (i4 != 0)
          this.mLayoutWidget.solveGraph();
        solveLinearSystem("2nd pass");
        i1 = 0;
        if (this.mLayoutWidget.getWidth() < j)
        {
          this.mLayoutWidget.setWidth(j);
          i1 = 1;
        }
        if (this.mLayoutWidget.getHeight() < i)
        {
          this.mLayoutWidget.setHeight(i);
          i1 = 1;
        }
        if (i1 != 0)
          solveLinearSystem("3rd pass");
      }
      i = n;
      j = 0;
      n = i13;
      while (j < i3)
      {
        localObject = (ConstraintWidget)this.mVariableDimensionsWidgets.get(j);
        localView = (View)((ConstraintWidget)localObject).getCompanionWidget();
        if (localView != null)
        {
          if ((localView.getMeasuredWidth() == ((ConstraintWidget)localObject).getWidth()) && (localView.getMeasuredHeight() == ((ConstraintWidget)localObject).getHeight()))
            break label1568;
          if (((ConstraintWidget)localObject).getVisibility() != 8)
          {
            localView.measure(View.MeasureSpec.makeMeasureSpec(((ConstraintWidget)localObject).getWidth(), 1073741824), View.MeasureSpec.makeMeasureSpec(((ConstraintWidget)localObject).getHeight(), 1073741824));
            localObject = this.mMetrics;
            if (localObject != null)
              ((Metrics)localObject).additionalMeasures += 1L;
            n += 1;
          }
        }
        label1568: j += 1;
      }
    }
    else
    {
      m = 0;
    }
    i = this.mLayoutWidget.getWidth() + i16;
    j = this.mLayoutWidget.getHeight() + i15;
    if (Build.VERSION.SDK_INT >= 11)
    {
      paramInt1 = resolveSizeAndState(i, paramInt1, m);
      i = resolveSizeAndState(j, paramInt2, m << 16);
      paramInt2 = Math.min(this.mMaxWidth, paramInt1 & 0xFFFFFF);
      i = Math.min(this.mMaxHeight, i & 0xFFFFFF);
      paramInt1 = paramInt2;
      if (this.mLayoutWidget.isWidthMeasuredTooSmall())
        paramInt1 = paramInt2 | 0x1000000;
      paramInt2 = i;
      if (this.mLayoutWidget.isHeightMeasuredTooSmall())
        paramInt2 = i | 0x1000000;
      setMeasuredDimension(paramInt1, paramInt2);
      this.mLastMeasureWidth = paramInt1;
      this.mLastMeasureHeight = paramInt2;
      return;
    }
    setMeasuredDimension(i, j);
    this.mLastMeasureWidth = i;
    this.mLastMeasureHeight = j;
  }

  public void onViewAdded(View paramView)
  {
    if (Build.VERSION.SDK_INT >= 14)
      super.onViewAdded(paramView);
    Object localObject = getViewWidget(paramView);
    if (((paramView instanceof Guideline)) && (!(localObject instanceof androidx.constraintlayout.solver.widgets.Guideline)))
    {
      localObject = (LayoutParams)paramView.getLayoutParams();
      ((LayoutParams)localObject).widget = new androidx.constraintlayout.solver.widgets.Guideline();
      ((LayoutParams)localObject).isGuideline = true;
      ((androidx.constraintlayout.solver.widgets.Guideline)((LayoutParams)localObject).widget).setOrientation(((LayoutParams)localObject).orientation);
    }
    if ((paramView instanceof ConstraintHelper))
    {
      localObject = (ConstraintHelper)paramView;
      ((ConstraintHelper)localObject).validateParams();
      ((LayoutParams)paramView.getLayoutParams()).isHelper = true;
      if (!this.mConstraintHelpers.contains(localObject))
        this.mConstraintHelpers.add(localObject);
    }
    this.mChildrenByIds.put(paramView.getId(), paramView);
    this.mDirtyHierarchy = true;
  }

  public void onViewRemoved(View paramView)
  {
    if (Build.VERSION.SDK_INT >= 14)
      super.onViewRemoved(paramView);
    this.mChildrenByIds.remove(paramView.getId());
    ConstraintWidget localConstraintWidget = getViewWidget(paramView);
    this.mLayoutWidget.remove(localConstraintWidget);
    this.mConstraintHelpers.remove(paramView);
    this.mVariableDimensionsWidgets.remove(localConstraintWidget);
    this.mDirtyHierarchy = true;
  }

  public void removeView(View paramView)
  {
    super.removeView(paramView);
    if (Build.VERSION.SDK_INT < 14)
      onViewRemoved(paramView);
  }

  public void requestLayout()
  {
    super.requestLayout();
    this.mDirtyHierarchy = true;
    this.mLastMeasureWidth = -1;
    this.mLastMeasureHeight = -1;
    this.mLastMeasureWidthSize = -1;
    this.mLastMeasureHeightSize = -1;
    this.mLastMeasureWidthMode = 0;
    this.mLastMeasureHeightMode = 0;
  }

  public void setConstraintSet(ConstraintSet paramConstraintSet)
  {
    this.mConstraintSet = paramConstraintSet;
  }

  public void setDesignInformation(int paramInt, Object paramObject1, Object paramObject2)
  {
    if ((paramInt == 0) && ((paramObject1 instanceof String)) && ((paramObject2 instanceof Integer)))
    {
      if (this.mDesignIds == null)
        this.mDesignIds = new HashMap();
      String str = (String)paramObject1;
      paramInt = str.indexOf("/");
      paramObject1 = str;
      if (paramInt != -1)
        paramObject1 = str.substring(paramInt + 1);
      paramInt = ((Integer)paramObject2).intValue();
      this.mDesignIds.put(paramObject1, Integer.valueOf(paramInt));
    }
  }

  public void setId(int paramInt)
  {
    this.mChildrenByIds.remove(getId());
    super.setId(paramInt);
    this.mChildrenByIds.put(getId(), this);
  }

  public void setMaxHeight(int paramInt)
  {
    if (paramInt == this.mMaxHeight)
      return;
    this.mMaxHeight = paramInt;
    requestLayout();
  }

  public void setMaxWidth(int paramInt)
  {
    if (paramInt == this.mMaxWidth)
      return;
    this.mMaxWidth = paramInt;
    requestLayout();
  }

  public void setMinHeight(int paramInt)
  {
    if (paramInt == this.mMinHeight)
      return;
    this.mMinHeight = paramInt;
    requestLayout();
  }

  public void setMinWidth(int paramInt)
  {
    if (paramInt == this.mMinWidth)
      return;
    this.mMinWidth = paramInt;
    requestLayout();
  }

  public void setOptimizationLevel(int paramInt)
  {
    this.mLayoutWidget.setOptimizationLevel(paramInt);
  }

  public boolean shouldDelayChildPressedState()
  {
    return false;
  }

  protected void solveLinearSystem(String paramString)
  {
    this.mLayoutWidget.layout();
    paramString = this.mMetrics;
    if (paramString != null)
      paramString.resolutions += 1L;
  }

  public static class LayoutParams extends ViewGroup.MarginLayoutParams
  {
    public static final int BASELINE = 5;
    public static final int BOTTOM = 4;
    public static final int CHAIN_PACKED = 2;
    public static final int CHAIN_SPREAD = 0;
    public static final int CHAIN_SPREAD_INSIDE = 1;
    public static final int END = 7;
    public static final int HORIZONTAL = 0;
    public static final int LEFT = 1;
    public static final int MATCH_CONSTRAINT = 0;
    public static final int MATCH_CONSTRAINT_PERCENT = 2;
    public static final int MATCH_CONSTRAINT_SPREAD = 0;
    public static final int MATCH_CONSTRAINT_WRAP = 1;
    public static final int PARENT_ID = 0;
    public static final int RIGHT = 2;
    public static final int START = 6;
    public static final int TOP = 3;
    public static final int UNSET = -1;
    public static final int VERTICAL = 1;
    public int baselineToBaseline = -1;
    public int bottomToBottom = -1;
    public int bottomToTop = -1;
    public float circleAngle = 0.0F;
    public int circleConstraint = -1;
    public int circleRadius = 0;
    public boolean constrainedHeight = false;
    public boolean constrainedWidth = false;
    public String dimensionRatio = null;
    int dimensionRatioSide = 1;
    float dimensionRatioValue = 0.0F;
    public int editorAbsoluteX = -1;
    public int editorAbsoluteY = -1;
    public int endToEnd = -1;
    public int endToStart = -1;
    public int goneBottomMargin = -1;
    public int goneEndMargin = -1;
    public int goneLeftMargin = -1;
    public int goneRightMargin = -1;
    public int goneStartMargin = -1;
    public int goneTopMargin = -1;
    public int guideBegin = -1;
    public int guideEnd = -1;
    public float guidePercent = -1.0F;
    public boolean helped = false;
    public float horizontalBias = 0.5F;
    public int horizontalChainStyle = 0;
    boolean horizontalDimensionFixed = true;
    public float horizontalWeight = -1.0F;
    boolean isGuideline = false;
    boolean isHelper = false;
    boolean isInPlaceholder = false;
    public int leftToLeft = -1;
    public int leftToRight = -1;
    public int matchConstraintDefaultHeight = 0;
    public int matchConstraintDefaultWidth = 0;
    public int matchConstraintMaxHeight = 0;
    public int matchConstraintMaxWidth = 0;
    public int matchConstraintMinHeight = 0;
    public int matchConstraintMinWidth = 0;
    public float matchConstraintPercentHeight = 1.0F;
    public float matchConstraintPercentWidth = 1.0F;
    boolean needsBaseline = false;
    public int orientation = -1;
    int resolveGoneLeftMargin = -1;
    int resolveGoneRightMargin = -1;
    int resolvedGuideBegin;
    int resolvedGuideEnd;
    float resolvedGuidePercent;
    float resolvedHorizontalBias = 0.5F;
    int resolvedLeftToLeft = -1;
    int resolvedLeftToRight = -1;
    int resolvedRightToLeft = -1;
    int resolvedRightToRight = -1;
    public int rightToLeft = -1;
    public int rightToRight = -1;
    public int startToEnd = -1;
    public int startToStart = -1;
    public int topToBottom = -1;
    public int topToTop = -1;
    public float verticalBias = 0.5F;
    public int verticalChainStyle = 0;
    boolean verticalDimensionFixed = true;
    public float verticalWeight = -1.0F;
    ConstraintWidget widget = new ConstraintWidget();

    public LayoutParams(int paramInt1, int paramInt2)
    {
      super(paramInt2);
    }

    public LayoutParams(Context paramContext, AttributeSet paramAttributeSet)
    {
      super(paramAttributeSet);
      paramContext = paramContext.obtainStyledAttributes(paramAttributeSet, R.styleable.ConstraintLayout_Layout);
      int k = paramContext.getIndexCount();
      int i = 0;
      while (i < k)
      {
        int j = paramContext.getIndex(i);
        float f1;
        switch (Table.map.get(j))
        {
        case 43:
        default:
          break;
        case 50:
          this.editorAbsoluteY = paramContext.getDimensionPixelOffset(j, this.editorAbsoluteY);
          break;
        case 49:
          this.editorAbsoluteX = paramContext.getDimensionPixelOffset(j, this.editorAbsoluteX);
          break;
        case 48:
          this.verticalChainStyle = paramContext.getInt(j, 0);
          break;
        case 47:
          this.horizontalChainStyle = paramContext.getInt(j, 0);
          break;
        case 46:
          this.verticalWeight = paramContext.getFloat(j, this.verticalWeight);
          break;
        case 45:
          this.horizontalWeight = paramContext.getFloat(j, this.horizontalWeight);
          break;
        case 44:
          this.dimensionRatio = paramContext.getString(j);
          this.dimensionRatioValue = (0.0F / 0.0F);
          this.dimensionRatioSide = -1;
          paramAttributeSet = this.dimensionRatio;
          if (paramAttributeSet != null)
          {
            int m = paramAttributeSet.length();
            j = this.dimensionRatio.indexOf(',');
            if ((j > 0) && (j < m - 1))
            {
              paramAttributeSet = this.dimensionRatio.substring(0, j);
              if (paramAttributeSet.equalsIgnoreCase("W"))
                this.dimensionRatioSide = 0;
              else if (paramAttributeSet.equalsIgnoreCase("H"))
                this.dimensionRatioSide = 1;
              j += 1;
            }
            else
            {
              j = 0;
            }
            int n = this.dimensionRatio.indexOf(':');
            if ((n >= 0) && (n < m - 1))
            {
              paramAttributeSet = this.dimensionRatio.substring(j, n);
              String str = this.dimensionRatio.substring(n + 1);
              if ((paramAttributeSet.length() > 0) && (str.length() > 0))
                try
                {
                  f1 = Float.parseFloat(paramAttributeSet);
                  float f2 = Float.parseFloat(str);
                  if ((f1 > 0.0F) && (f2 > 0.0F))
                    if (this.dimensionRatioSide == 1)
                      this.dimensionRatioValue = Math.abs(f2 / f1);
                    else
                      this.dimensionRatioValue = Math.abs(f1 / f2);
                }
                catch (NumberFormatException paramAttributeSet)
                {
                }
            }
            else
            {
              paramAttributeSet = this.dimensionRatio.substring(j);
              if (paramAttributeSet.length() > 0)
                try
                {
                  this.dimensionRatioValue = Float.parseFloat(paramAttributeSet);
                }
                catch (NumberFormatException paramAttributeSet)
                {
                }
            }
          }
          break;
        case 42:
          break;
        case 41:
          break;
        case 40:
          break;
        case 39:
          break;
        case 38:
          this.matchConstraintPercentHeight = Math.max(0.0F, paramContext.getFloat(j, this.matchConstraintPercentHeight));
          break;
        case 37:
          try
          {
            this.matchConstraintMaxHeight = paramContext.getDimensionPixelSize(j, this.matchConstraintMaxHeight);
          }
          catch (Exception paramAttributeSet)
          {
            if (paramContext.getInt(j, this.matchConstraintMaxHeight) == -2)
              this.matchConstraintMaxHeight = -2;
          }
        case 36:
          try
          {
            this.matchConstraintMinHeight = paramContext.getDimensionPixelSize(j, this.matchConstraintMinHeight);
          }
          catch (Exception paramAttributeSet)
          {
            if (paramContext.getInt(j, this.matchConstraintMinHeight) == -2)
              this.matchConstraintMinHeight = -2;
          }
        case 35:
          this.matchConstraintPercentWidth = Math.max(0.0F, paramContext.getFloat(j, this.matchConstraintPercentWidth));
          break;
        case 34:
          try
          {
            this.matchConstraintMaxWidth = paramContext.getDimensionPixelSize(j, this.matchConstraintMaxWidth);
          }
          catch (Exception paramAttributeSet)
          {
            if (paramContext.getInt(j, this.matchConstraintMaxWidth) == -2)
              this.matchConstraintMaxWidth = -2;
          }
        case 33:
          try
          {
            this.matchConstraintMinWidth = paramContext.getDimensionPixelSize(j, this.matchConstraintMinWidth);
          }
          catch (Exception paramAttributeSet)
          {
            if (paramContext.getInt(j, this.matchConstraintMinWidth) == -2)
              this.matchConstraintMinWidth = -2;
          }
        case 32:
          this.matchConstraintDefaultHeight = paramContext.getInt(j, 0);
          if (this.matchConstraintDefaultHeight == 1)
            Log.e("ConstraintLayout", "layout_constraintHeight_default=\"wrap\" is deprecated.\nUse layout_height=\"WRAP_CONTENT\" and layout_constrainedHeight=\"true\" instead.");
          break;
        case 31:
          this.matchConstraintDefaultWidth = paramContext.getInt(j, 0);
          if (this.matchConstraintDefaultWidth == 1)
            Log.e("ConstraintLayout", "layout_constraintWidth_default=\"wrap\" is deprecated.\nUse layout_width=\"WRAP_CONTENT\" and layout_constrainedWidth=\"true\" instead.");
          break;
        case 30:
          this.verticalBias = paramContext.getFloat(j, this.verticalBias);
          break;
        case 29:
          this.horizontalBias = paramContext.getFloat(j, this.horizontalBias);
          break;
        case 28:
          this.constrainedHeight = paramContext.getBoolean(j, this.constrainedHeight);
          break;
        case 27:
          this.constrainedWidth = paramContext.getBoolean(j, this.constrainedWidth);
          break;
        case 26:
          this.goneEndMargin = paramContext.getDimensionPixelSize(j, this.goneEndMargin);
          break;
        case 25:
          this.goneStartMargin = paramContext.getDimensionPixelSize(j, this.goneStartMargin);
          break;
        case 24:
          this.goneBottomMargin = paramContext.getDimensionPixelSize(j, this.goneBottomMargin);
          break;
        case 23:
          this.goneRightMargin = paramContext.getDimensionPixelSize(j, this.goneRightMargin);
          break;
        case 22:
          this.goneTopMargin = paramContext.getDimensionPixelSize(j, this.goneTopMargin);
          break;
        case 21:
          this.goneLeftMargin = paramContext.getDimensionPixelSize(j, this.goneLeftMargin);
          break;
        case 20:
          this.endToEnd = paramContext.getResourceId(j, this.endToEnd);
          if (this.endToEnd == -1)
            this.endToEnd = paramContext.getInt(j, -1);
          break;
        case 19:
          this.endToStart = paramContext.getResourceId(j, this.endToStart);
          if (this.endToStart == -1)
            this.endToStart = paramContext.getInt(j, -1);
          break;
        case 18:
          this.startToStart = paramContext.getResourceId(j, this.startToStart);
          if (this.startToStart == -1)
            this.startToStart = paramContext.getInt(j, -1);
          break;
        case 17:
          this.startToEnd = paramContext.getResourceId(j, this.startToEnd);
          if (this.startToEnd == -1)
            this.startToEnd = paramContext.getInt(j, -1);
          break;
        case 16:
          this.baselineToBaseline = paramContext.getResourceId(j, this.baselineToBaseline);
          if (this.baselineToBaseline == -1)
            this.baselineToBaseline = paramContext.getInt(j, -1);
          break;
        case 15:
          this.bottomToBottom = paramContext.getResourceId(j, this.bottomToBottom);
          if (this.bottomToBottom == -1)
            this.bottomToBottom = paramContext.getInt(j, -1);
          break;
        case 14:
          this.bottomToTop = paramContext.getResourceId(j, this.bottomToTop);
          if (this.bottomToTop == -1)
            this.bottomToTop = paramContext.getInt(j, -1);
          break;
        case 13:
          this.topToBottom = paramContext.getResourceId(j, this.topToBottom);
          if (this.topToBottom == -1)
            this.topToBottom = paramContext.getInt(j, -1);
          break;
        case 12:
          this.topToTop = paramContext.getResourceId(j, this.topToTop);
          if (this.topToTop == -1)
            this.topToTop = paramContext.getInt(j, -1);
          break;
        case 11:
          this.rightToRight = paramContext.getResourceId(j, this.rightToRight);
          if (this.rightToRight == -1)
            this.rightToRight = paramContext.getInt(j, -1);
          break;
        case 10:
          this.rightToLeft = paramContext.getResourceId(j, this.rightToLeft);
          if (this.rightToLeft == -1)
            this.rightToLeft = paramContext.getInt(j, -1);
          break;
        case 9:
          this.leftToRight = paramContext.getResourceId(j, this.leftToRight);
          if (this.leftToRight == -1)
            this.leftToRight = paramContext.getInt(j, -1);
          break;
        case 8:
          this.leftToLeft = paramContext.getResourceId(j, this.leftToLeft);
          if (this.leftToLeft == -1)
            this.leftToLeft = paramContext.getInt(j, -1);
          break;
        case 7:
          this.guidePercent = paramContext.getFloat(j, this.guidePercent);
          break;
        case 6:
          this.guideEnd = paramContext.getDimensionPixelOffset(j, this.guideEnd);
          break;
        case 5:
          this.guideBegin = paramContext.getDimensionPixelOffset(j, this.guideBegin);
          break;
        case 4:
          this.circleAngle = (paramContext.getFloat(j, this.circleAngle) % 360.0F);
          f1 = this.circleAngle;
          if (f1 < 0.0F)
            this.circleAngle = ((360.0F - f1) % 360.0F);
          break;
        case 3:
          this.circleRadius = paramContext.getDimensionPixelSize(j, this.circleRadius);
          break;
        case 2:
          this.circleConstraint = paramContext.getResourceId(j, this.circleConstraint);
          if (this.circleConstraint == -1)
            this.circleConstraint = paramContext.getInt(j, -1);
          break;
        case 1:
          this.orientation = paramContext.getInt(j, this.orientation);
          break;
        case 0:
        }
        i += 1;
      }
      paramContext.recycle();
      validate();
    }

    public LayoutParams(ViewGroup.LayoutParams paramLayoutParams)
    {
      super();
    }

    public LayoutParams(LayoutParams paramLayoutParams)
    {
      super();
      this.guideBegin = paramLayoutParams.guideBegin;
      this.guideEnd = paramLayoutParams.guideEnd;
      this.guidePercent = paramLayoutParams.guidePercent;
      this.leftToLeft = paramLayoutParams.leftToLeft;
      this.leftToRight = paramLayoutParams.leftToRight;
      this.rightToLeft = paramLayoutParams.rightToLeft;
      this.rightToRight = paramLayoutParams.rightToRight;
      this.topToTop = paramLayoutParams.topToTop;
      this.topToBottom = paramLayoutParams.topToBottom;
      this.bottomToTop = paramLayoutParams.bottomToTop;
      this.bottomToBottom = paramLayoutParams.bottomToBottom;
      this.baselineToBaseline = paramLayoutParams.baselineToBaseline;
      this.circleConstraint = paramLayoutParams.circleConstraint;
      this.circleRadius = paramLayoutParams.circleRadius;
      this.circleAngle = paramLayoutParams.circleAngle;
      this.startToEnd = paramLayoutParams.startToEnd;
      this.startToStart = paramLayoutParams.startToStart;
      this.endToStart = paramLayoutParams.endToStart;
      this.endToEnd = paramLayoutParams.endToEnd;
      this.goneLeftMargin = paramLayoutParams.goneLeftMargin;
      this.goneTopMargin = paramLayoutParams.goneTopMargin;
      this.goneRightMargin = paramLayoutParams.goneRightMargin;
      this.goneBottomMargin = paramLayoutParams.goneBottomMargin;
      this.goneStartMargin = paramLayoutParams.goneStartMargin;
      this.goneEndMargin = paramLayoutParams.goneEndMargin;
      this.horizontalBias = paramLayoutParams.horizontalBias;
      this.verticalBias = paramLayoutParams.verticalBias;
      this.dimensionRatio = paramLayoutParams.dimensionRatio;
      this.dimensionRatioValue = paramLayoutParams.dimensionRatioValue;
      this.dimensionRatioSide = paramLayoutParams.dimensionRatioSide;
      this.horizontalWeight = paramLayoutParams.horizontalWeight;
      this.verticalWeight = paramLayoutParams.verticalWeight;
      this.horizontalChainStyle = paramLayoutParams.horizontalChainStyle;
      this.verticalChainStyle = paramLayoutParams.verticalChainStyle;
      this.constrainedWidth = paramLayoutParams.constrainedWidth;
      this.constrainedHeight = paramLayoutParams.constrainedHeight;
      this.matchConstraintDefaultWidth = paramLayoutParams.matchConstraintDefaultWidth;
      this.matchConstraintDefaultHeight = paramLayoutParams.matchConstraintDefaultHeight;
      this.matchConstraintMinWidth = paramLayoutParams.matchConstraintMinWidth;
      this.matchConstraintMaxWidth = paramLayoutParams.matchConstraintMaxWidth;
      this.matchConstraintMinHeight = paramLayoutParams.matchConstraintMinHeight;
      this.matchConstraintMaxHeight = paramLayoutParams.matchConstraintMaxHeight;
      this.matchConstraintPercentWidth = paramLayoutParams.matchConstraintPercentWidth;
      this.matchConstraintPercentHeight = paramLayoutParams.matchConstraintPercentHeight;
      this.editorAbsoluteX = paramLayoutParams.editorAbsoluteX;
      this.editorAbsoluteY = paramLayoutParams.editorAbsoluteY;
      this.orientation = paramLayoutParams.orientation;
      this.horizontalDimensionFixed = paramLayoutParams.horizontalDimensionFixed;
      this.verticalDimensionFixed = paramLayoutParams.verticalDimensionFixed;
      this.needsBaseline = paramLayoutParams.needsBaseline;
      this.isGuideline = paramLayoutParams.isGuideline;
      this.resolvedLeftToLeft = paramLayoutParams.resolvedLeftToLeft;
      this.resolvedLeftToRight = paramLayoutParams.resolvedLeftToRight;
      this.resolvedRightToLeft = paramLayoutParams.resolvedRightToLeft;
      this.resolvedRightToRight = paramLayoutParams.resolvedRightToRight;
      this.resolveGoneLeftMargin = paramLayoutParams.resolveGoneLeftMargin;
      this.resolveGoneRightMargin = paramLayoutParams.resolveGoneRightMargin;
      this.resolvedHorizontalBias = paramLayoutParams.resolvedHorizontalBias;
      this.widget = paramLayoutParams.widget;
    }

    public void reset()
    {
      ConstraintWidget localConstraintWidget = this.widget;
      if (localConstraintWidget != null)
        localConstraintWidget.reset();
    }

    @TargetApi(17)
    public void resolveLayoutDirection(int paramInt)
    {
      int i = this.leftMargin;
      int j = this.rightMargin;
      super.resolveLayoutDirection(paramInt);
      this.resolvedRightToLeft = -1;
      this.resolvedRightToRight = -1;
      this.resolvedLeftToLeft = -1;
      this.resolvedLeftToRight = -1;
      this.resolveGoneLeftMargin = -1;
      this.resolveGoneRightMargin = -1;
      this.resolveGoneLeftMargin = this.goneLeftMargin;
      this.resolveGoneRightMargin = this.goneRightMargin;
      this.resolvedHorizontalBias = this.horizontalBias;
      this.resolvedGuideBegin = this.guideBegin;
      this.resolvedGuideEnd = this.guideEnd;
      this.resolvedGuidePercent = this.guidePercent;
      if (1 == getLayoutDirection())
        paramInt = 1;
      else
        paramInt = 0;
      if (paramInt != 0)
      {
        paramInt = 0;
        int k = this.startToEnd;
        if (k != -1)
        {
          this.resolvedRightToLeft = k;
          paramInt = 1;
        }
        else
        {
          k = this.startToStart;
          if (k != -1)
          {
            this.resolvedRightToRight = k;
            paramInt = 1;
          }
        }
        k = this.endToStart;
        if (k != -1)
        {
          this.resolvedLeftToRight = k;
          paramInt = 1;
        }
        k = this.endToEnd;
        if (k != -1)
        {
          this.resolvedLeftToLeft = k;
          paramInt = 1;
        }
        k = this.goneStartMargin;
        if (k != -1)
          this.resolveGoneRightMargin = k;
        k = this.goneEndMargin;
        if (k != -1)
          this.resolveGoneLeftMargin = k;
        if (paramInt != 0)
          this.resolvedHorizontalBias = (1.0F - this.horizontalBias);
        if ((this.isGuideline) && (this.orientation == 1))
        {
          float f = this.guidePercent;
          if (f != -1.0F)
          {
            this.resolvedGuidePercent = (1.0F - f);
            this.resolvedGuideBegin = -1;
            this.resolvedGuideEnd = -1;
          }
          else
          {
            paramInt = this.guideBegin;
            if (paramInt != -1)
            {
              this.resolvedGuideEnd = paramInt;
              this.resolvedGuideBegin = -1;
              this.resolvedGuidePercent = -1.0F;
            }
            else
            {
              paramInt = this.guideEnd;
              if (paramInt != -1)
              {
                this.resolvedGuideBegin = paramInt;
                this.resolvedGuideEnd = -1;
                this.resolvedGuidePercent = -1.0F;
              }
            }
          }
        }
      }
      else
      {
        paramInt = this.startToEnd;
        if (paramInt != -1)
          this.resolvedLeftToRight = paramInt;
        paramInt = this.startToStart;
        if (paramInt != -1)
          this.resolvedLeftToLeft = paramInt;
        paramInt = this.endToStart;
        if (paramInt != -1)
          this.resolvedRightToLeft = paramInt;
        paramInt = this.endToEnd;
        if (paramInt != -1)
          this.resolvedRightToRight = paramInt;
        paramInt = this.goneStartMargin;
        if (paramInt != -1)
          this.resolveGoneLeftMargin = paramInt;
        paramInt = this.goneEndMargin;
        if (paramInt != -1)
          this.resolveGoneRightMargin = paramInt;
      }
      if ((this.endToStart == -1) && (this.endToEnd == -1) && (this.startToStart == -1) && (this.startToEnd == -1))
      {
        paramInt = this.rightToLeft;
        if (paramInt != -1)
        {
          this.resolvedRightToLeft = paramInt;
          if ((this.rightMargin <= 0) && (j > 0))
            this.rightMargin = j;
        }
        else
        {
          paramInt = this.rightToRight;
          if (paramInt != -1)
          {
            this.resolvedRightToRight = paramInt;
            if ((this.rightMargin <= 0) && (j > 0))
              this.rightMargin = j;
          }
        }
        paramInt = this.leftToLeft;
        if (paramInt != -1)
        {
          this.resolvedLeftToLeft = paramInt;
          if ((this.leftMargin <= 0) && (i > 0))
            this.leftMargin = i;
        }
        else
        {
          paramInt = this.leftToRight;
          if (paramInt != -1)
          {
            this.resolvedLeftToRight = paramInt;
            if ((this.leftMargin <= 0) && (i > 0))
              this.leftMargin = i;
          }
        }
      }
    }

    public void validate()
    {
      this.isGuideline = false;
      this.horizontalDimensionFixed = true;
      this.verticalDimensionFixed = true;
      if ((this.width == -2) && (this.constrainedWidth))
      {
        this.horizontalDimensionFixed = false;
        this.matchConstraintDefaultWidth = 1;
      }
      if ((this.height == -2) && (this.constrainedHeight))
      {
        this.verticalDimensionFixed = false;
        this.matchConstraintDefaultHeight = 1;
      }
      if ((this.width == 0) || (this.width == -1))
      {
        this.horizontalDimensionFixed = false;
        if ((this.width == 0) && (this.matchConstraintDefaultWidth == 1))
        {
          this.width = -2;
          this.constrainedWidth = true;
        }
      }
      if ((this.height == 0) || (this.height == -1))
      {
        this.verticalDimensionFixed = false;
        if ((this.height == 0) && (this.matchConstraintDefaultHeight == 1))
        {
          this.height = -2;
          this.constrainedHeight = true;
        }
      }
      if ((this.guidePercent != -1.0F) || (this.guideBegin != -1) || (this.guideEnd != -1))
      {
        this.isGuideline = true;
        this.horizontalDimensionFixed = true;
        this.verticalDimensionFixed = true;
        if (!(this.widget instanceof androidx.constraintlayout.solver.widgets.Guideline))
          this.widget = new androidx.constraintlayout.solver.widgets.Guideline();
        ((androidx.constraintlayout.solver.widgets.Guideline)this.widget).setOrientation(this.orientation);
      }
    }

    private static class Table
    {
      public static final int ANDROID_ORIENTATION = 1;
      public static final int LAYOUT_CONSTRAINED_HEIGHT = 28;
      public static final int LAYOUT_CONSTRAINED_WIDTH = 27;
      public static final int LAYOUT_CONSTRAINT_BASELINE_CREATOR = 43;
      public static final int LAYOUT_CONSTRAINT_BASELINE_TO_BASELINE_OF = 16;
      public static final int LAYOUT_CONSTRAINT_BOTTOM_CREATOR = 42;
      public static final int LAYOUT_CONSTRAINT_BOTTOM_TO_BOTTOM_OF = 15;
      public static final int LAYOUT_CONSTRAINT_BOTTOM_TO_TOP_OF = 14;
      public static final int LAYOUT_CONSTRAINT_CIRCLE = 2;
      public static final int LAYOUT_CONSTRAINT_CIRCLE_ANGLE = 4;
      public static final int LAYOUT_CONSTRAINT_CIRCLE_RADIUS = 3;
      public static final int LAYOUT_CONSTRAINT_DIMENSION_RATIO = 44;
      public static final int LAYOUT_CONSTRAINT_END_TO_END_OF = 20;
      public static final int LAYOUT_CONSTRAINT_END_TO_START_OF = 19;
      public static final int LAYOUT_CONSTRAINT_GUIDE_BEGIN = 5;
      public static final int LAYOUT_CONSTRAINT_GUIDE_END = 6;
      public static final int LAYOUT_CONSTRAINT_GUIDE_PERCENT = 7;
      public static final int LAYOUT_CONSTRAINT_HEIGHT_DEFAULT = 32;
      public static final int LAYOUT_CONSTRAINT_HEIGHT_MAX = 37;
      public static final int LAYOUT_CONSTRAINT_HEIGHT_MIN = 36;
      public static final int LAYOUT_CONSTRAINT_HEIGHT_PERCENT = 38;
      public static final int LAYOUT_CONSTRAINT_HORIZONTAL_BIAS = 29;
      public static final int LAYOUT_CONSTRAINT_HORIZONTAL_CHAINSTYLE = 47;
      public static final int LAYOUT_CONSTRAINT_HORIZONTAL_WEIGHT = 45;
      public static final int LAYOUT_CONSTRAINT_LEFT_CREATOR = 39;
      public static final int LAYOUT_CONSTRAINT_LEFT_TO_LEFT_OF = 8;
      public static final int LAYOUT_CONSTRAINT_LEFT_TO_RIGHT_OF = 9;
      public static final int LAYOUT_CONSTRAINT_RIGHT_CREATOR = 41;
      public static final int LAYOUT_CONSTRAINT_RIGHT_TO_LEFT_OF = 10;
      public static final int LAYOUT_CONSTRAINT_RIGHT_TO_RIGHT_OF = 11;
      public static final int LAYOUT_CONSTRAINT_START_TO_END_OF = 17;
      public static final int LAYOUT_CONSTRAINT_START_TO_START_OF = 18;
      public static final int LAYOUT_CONSTRAINT_TOP_CREATOR = 40;
      public static final int LAYOUT_CONSTRAINT_TOP_TO_BOTTOM_OF = 13;
      public static final int LAYOUT_CONSTRAINT_TOP_TO_TOP_OF = 12;
      public static final int LAYOUT_CONSTRAINT_VERTICAL_BIAS = 30;
      public static final int LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE = 48;
      public static final int LAYOUT_CONSTRAINT_VERTICAL_WEIGHT = 46;
      public static final int LAYOUT_CONSTRAINT_WIDTH_DEFAULT = 31;
      public static final int LAYOUT_CONSTRAINT_WIDTH_MAX = 34;
      public static final int LAYOUT_CONSTRAINT_WIDTH_MIN = 33;
      public static final int LAYOUT_CONSTRAINT_WIDTH_PERCENT = 35;
      public static final int LAYOUT_EDITOR_ABSOLUTEX = 49;
      public static final int LAYOUT_EDITOR_ABSOLUTEY = 50;
      public static final int LAYOUT_GONE_MARGIN_BOTTOM = 24;
      public static final int LAYOUT_GONE_MARGIN_END = 26;
      public static final int LAYOUT_GONE_MARGIN_LEFT = 21;
      public static final int LAYOUT_GONE_MARGIN_RIGHT = 23;
      public static final int LAYOUT_GONE_MARGIN_START = 25;
      public static final int LAYOUT_GONE_MARGIN_TOP = 22;
      public static final int UNUSED = 0;
      public static final SparseIntArray map = new SparseIntArray();

      static
      {
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintLeft_toLeftOf, 8);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintLeft_toRightOf, 9);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintRight_toLeftOf, 10);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintRight_toRightOf, 11);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintTop_toTopOf, 12);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintTop_toBottomOf, 13);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintBottom_toTopOf, 14);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintBottom_toBottomOf, 15);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintBaseline_toBaselineOf, 16);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintCircle, 2);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintCircleRadius, 3);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintCircleAngle, 4);
        map.append(R.styleable.ConstraintLayout_Layout_layout_editor_absoluteX, 49);
        map.append(R.styleable.ConstraintLayout_Layout_layout_editor_absoluteY, 50);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintGuide_begin, 5);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintGuide_end, 6);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintGuide_percent, 7);
        map.append(R.styleable.ConstraintLayout_Layout_android_orientation, 1);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintStart_toEndOf, 17);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintStart_toStartOf, 18);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintEnd_toStartOf, 19);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintEnd_toEndOf, 20);
        map.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginLeft, 21);
        map.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginTop, 22);
        map.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginRight, 23);
        map.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginBottom, 24);
        map.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginStart, 25);
        map.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginEnd, 26);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHorizontal_bias, 29);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintVertical_bias, 30);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintDimensionRatio, 44);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHorizontal_weight, 45);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintVertical_weight, 46);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHorizontal_chainStyle, 47);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintVertical_chainStyle, 48);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constrainedWidth, 27);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constrainedHeight, 28);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintWidth_default, 31);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHeight_default, 32);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintWidth_min, 33);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintWidth_max, 34);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintWidth_percent, 35);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHeight_min, 36);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHeight_max, 37);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHeight_percent, 38);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintLeft_creator, 39);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintTop_creator, 40);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintRight_creator, 41);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintBottom_creator, 42);
        map.append(R.styleable.ConstraintLayout_Layout_layout_constraintBaseline_creator, 43);
      }
    }
  }
}

/* Location:           C:\Users\eunna\dex2jar-2.0\classes-dex2jar.jar
 * Qualified Name:     androidx.constraintlayout.widget.ConstraintLayout
 * JD-Core Version:    0.6.2
 */