package androidx.core.content.pm;

@Deprecated
public final class ActivityInfoCompat
{

  @Deprecated
  public static final int CONFIG_UI_MODE = 512;
}

/* Location:           C:\Users\eunna\dex2jar-2.0\classes-dex2jar.jar
 * Qualified Name:     androidx.core.content.pm.ActivityInfoCompat
 * JD-Core Version:    0.6.2
 */