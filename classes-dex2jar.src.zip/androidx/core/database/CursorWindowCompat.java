package androidx.core.database;

import android.database.CursorWindow;
import android.os.Build.VERSION;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public final class CursorWindowCompat
{
  @NonNull
  public static CursorWindow create(@Nullable String paramString, long paramLong)
  {
    if (Build.VERSION.SDK_INT >= 28)
      return new CursorWindow(paramString, paramLong);
    if (Build.VERSION.SDK_INT >= 15)
      return new CursorWindow(paramString);
    return new CursorWindow(false);
  }
}

/* Location:           C:\Users\eunna\dex2jar-2.0\classes-dex2jar.jar
 * Qualified Name:     androidx.core.database.CursorWindowCompat
 * JD-Core Version:    0.6.2
 */