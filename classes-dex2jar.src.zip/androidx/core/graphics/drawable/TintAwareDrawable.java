package androidx.core.graphics.drawable;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;
import androidx.annotation.ColorInt;
import androidx.annotation.RestrictTo;

@RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP_PREFIX})
public abstract interface TintAwareDrawable
{
  public abstract void setTint(@ColorInt int paramInt);

  public abstract void setTintList(ColorStateList paramColorStateList);

  public abstract void setTintMode(PorterDuff.Mode paramMode);
}

/* Location:           C:\Users\eunna\dex2jar-2.0\classes-dex2jar.jar
 * Qualified Name:     androidx.core.graphics.drawable.TintAwareDrawable
 * JD-Core Version:    0.6.2
 */