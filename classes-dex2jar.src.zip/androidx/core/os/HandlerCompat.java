package androidx.core.os;

import android.os.Build.VERSION;
import android.os.Handler;
import android.os.Handler.Callback;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

public final class HandlerCompat
{
  private static final String TAG = "HandlerCompat";

  @NonNull
  public static Handler createAsync(@NonNull Looper paramLooper)
  {
    if (Build.VERSION.SDK_INT >= 28)
      return Handler.createAsync(paramLooper);
    if (Build.VERSION.SDK_INT >= 16)
    {
      try
      {
        Handler localHandler = (Handler)Handler.class.getDeclaredConstructor(new Class[] { Looper.class, Handler.Callback.class, Boolean.TYPE }).newInstance(new Object[] { paramLooper, null, Boolean.valueOf(true) });
        return localHandler;
      }
      catch (InvocationTargetException paramLooper)
      {
        paramLooper = paramLooper.getCause();
        if (!(paramLooper instanceof RuntimeException))
        {
          if ((paramLooper instanceof Error))
            throw ((Error)paramLooper);
          throw new RuntimeException(paramLooper);
        }
        throw ((RuntimeException)paramLooper);
      }
      catch (NoSuchMethodException localNoSuchMethodException)
      {
      }
      catch (InstantiationException localInstantiationException)
      {
      }
      catch (IllegalAccessException localIllegalAccessException)
      {
      }
      Log.v("HandlerCompat", "Unable to invoke Handler(Looper, Callback, boolean) constructor");
    }
    return new Handler(paramLooper);
  }

  @NonNull
  public static Handler createAsync(@NonNull Looper paramLooper, @NonNull Handler.Callback paramCallback)
  {
    if (Build.VERSION.SDK_INT >= 28)
      return Handler.createAsync(paramLooper, paramCallback);
    if (Build.VERSION.SDK_INT >= 16)
    {
      try
      {
        Handler localHandler = (Handler)Handler.class.getDeclaredConstructor(new Class[] { Looper.class, Handler.Callback.class, Boolean.TYPE }).newInstance(new Object[] { paramLooper, paramCallback, Boolean.valueOf(true) });
        return localHandler;
      }
      catch (InvocationTargetException paramLooper)
      {
        paramLooper = paramLooper.getCause();
        if (!(paramLooper instanceof RuntimeException))
        {
          if ((paramLooper instanceof Error))
            throw ((Error)paramLooper);
          throw new RuntimeException(paramLooper);
        }
        throw ((RuntimeException)paramLooper);
      }
      catch (NoSuchMethodException localNoSuchMethodException)
      {
      }
      catch (InstantiationException localInstantiationException)
      {
      }
      catch (IllegalAccessException localIllegalAccessException)
      {
      }
      Log.v("HandlerCompat", "Unable to invoke Handler(Looper, Callback, boolean) constructor");
    }
    return new Handler(paramLooper, paramCallback);
  }

  public static boolean postDelayed(@NonNull Handler paramHandler, @NonNull Runnable paramRunnable, @Nullable Object paramObject, long paramLong)
  {
    if (Build.VERSION.SDK_INT >= 28)
      return paramHandler.postDelayed(paramRunnable, paramObject, paramLong);
    paramRunnable = Message.obtain(paramHandler, paramRunnable);
    paramRunnable.obj = paramObject;
    return paramHandler.sendMessageDelayed(paramRunnable, paramLong);
  }
}

/* Location:           C:\Users\eunna\dex2jar-2.0\classes-dex2jar.jar
 * Qualified Name:     androidx.core.os.HandlerCompat
 * JD-Core Version:    0.6.2
 */