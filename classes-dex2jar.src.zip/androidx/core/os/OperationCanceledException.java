package androidx.core.os;

import androidx.annotation.Nullable;

public class OperationCanceledException extends RuntimeException
{
  public OperationCanceledException()
  {
    this(null);
  }

  public OperationCanceledException(@Nullable String paramString)
  {
    super(paramString);
  }
}

/* Location:           C:\Users\eunna\dex2jar-2.0\classes-dex2jar.jar
 * Qualified Name:     androidx.core.os.OperationCanceledException
 * JD-Core Version:    0.6.2
 */