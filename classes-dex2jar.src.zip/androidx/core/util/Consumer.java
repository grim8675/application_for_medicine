package androidx.core.util;

public abstract interface Consumer<T>
{
  public abstract void accept(T paramT);
}

/* Location:           C:\Users\eunna\dex2jar-2.0\classes-dex2jar.jar
 * Qualified Name:     androidx.core.util.Consumer
 * JD-Core Version:    0.6.2
 */