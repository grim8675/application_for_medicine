package androidx.core.util;

public abstract interface Supplier<T>
{
  public abstract T get();
}

/* Location:           C:\Users\eunna\dex2jar-2.0\classes-dex2jar.jar
 * Qualified Name:     androidx.core.util.Supplier
 * JD-Core Version:    0.6.2
 */