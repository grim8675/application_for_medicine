package androidx.legacy.coreutils;

public final class R
{
  public static final class attr
  {
    public static final int alpha = 2130968615;
    public static final int font = 2130968809;
    public static final int fontProviderAuthority = 2130968811;
    public static final int fontProviderCerts = 2130968812;
    public static final int fontProviderFetchStrategy = 2130968813;
    public static final int fontProviderFetchTimeout = 2130968814;
    public static final int fontProviderPackage = 2130968815;
    public static final int fontProviderQuery = 2130968816;
    public static final int fontStyle = 2130968817;
    public static final int fontVariationSettings = 2130968818;
    public static final int fontWeight = 2130968819;
    public static final int ttcIndex = 2130969128;
  }

  public static final class color
  {
    public static final int notification_action_color_filter = 2131099756;
    public static final int notification_icon_bg_color = 2131099757;
    public static final int ripple_material_light = 2131099768;
    public static final int secondary_text_default_material_light = 2131099770;
  }

  public static final class dimen
  {
    public static final int compat_button_inset_horizontal_material = 2131165267;
    public static final int compat_button_inset_vertical_material = 2131165268;
    public static final int compat_button_padding_horizontal_material = 2131165269;
    public static final int compat_button_padding_vertical_material = 2131165270;
    public static final int compat_control_corner_material = 2131165271;
    public static final int compat_notification_large_icon_max_height = 2131165272;
    public static final int compat_notification_large_icon_max_width = 2131165273;
    public static final int notification_action_icon_size = 2131165385;
    public static final int notification_action_text_size = 2131165386;
    public static final int notification_big_circle_margin = 2131165387;
    public static final int notification_content_margin_start = 2131165388;
    public static final int notification_large_icon_height = 2131165389;
    public static final int notification_large_icon_width = 2131165390;
    public static final int notification_main_column_padding_top = 2131165391;
    public static final int notification_media_narrow_margin = 2131165392;
    public static final int notification_right_icon_size = 2131165393;
    public static final int notification_right_side_padding_top = 2131165394;
    public static final int notification_small_icon_background_padding = 2131165395;
    public static final int notification_small_icon_size_as_large = 2131165396;
    public static final int notification_subtext_size = 2131165397;
    public static final int notification_top_pad = 2131165398;
    public static final int notification_top_pad_large_text = 2131165399;
  }

  public static final class drawable
  {
    public static final int notification_action_background = 2131230931;
    public static final int notification_bg = 2131230932;
    public static final int notification_bg_low = 2131230933;
    public static final int notification_bg_low_normal = 2131230934;
    public static final int notification_bg_low_pressed = 2131230935;
    public static final int notification_bg_normal = 2131230936;
    public static final int notification_bg_normal_pressed = 2131230937;
    public static final int notification_icon_background = 2131230938;
    public static final int notification_template_icon_bg = 2131230939;
    public static final int notification_template_icon_low_bg = 2131230940;
    public static final int notification_tile_bg = 2131230941;
    public static final int notify_panel_notification_icon_bg = 2131230942;
  }

  public static final class id
  {
    public static final int action_container = 2131296303;
    public static final int action_divider = 2131296305;
    public static final int action_image = 2131296306;
    public static final int action_text = 2131296312;
    public static final int actions = 2131296313;
    public static final int async = 2131296320;
    public static final int blocking = 2131296325;
    public static final int chronometer = 2131296359;
    public static final int forever = 2131296406;
    public static final int icon = 2131296421;
    public static final int icon_group = 2131296422;
    public static final int info = 2131296431;
    public static final int italic = 2131296433;
    public static final int line1 = 2131296438;
    public static final int line3 = 2131296439;
    public static final int normal = 2131296487;
    public static final int notification_background = 2131296488;
    public static final int notification_main_column = 2131296489;
    public static final int notification_main_column_container = 2131296490;
    public static final int right_icon = 2131296506;
    public static final int right_side = 2131296507;
    public static final int tag_transition_group = 2131296571;
    public static final int tag_unhandled_key_event_manager = 2131296572;
    public static final int tag_unhandled_key_listeners = 2131296573;
    public static final int text = 2131296574;
    public static final int text2 = 2131296575;
    public static final int time = 2131296619;
    public static final int title = 2131296621;
  }

  public static final class integer
  {
    public static final int status_bar_notification_info_maxnum = 2131361806;
  }

  public static final class layout
  {
    public static final int notification_action = 2131492938;
    public static final int notification_action_tombstone = 2131492939;
    public static final int notification_template_custom_big = 2131492946;
    public static final int notification_template_icon_group = 2131492947;
    public static final int notification_template_part_chronometer = 2131492951;
    public static final int notification_template_part_time = 2131492952;
  }

  public static final class string
  {
    public static final int status_bar_notification_info_overflow = 2131689514;
  }

  public static final class style
  {
    public static final int TextAppearance_Compat_Notification = 2131755286;
    public static final int TextAppearance_Compat_Notification_Info = 2131755287;
    public static final int TextAppearance_Compat_Notification_Line2 = 2131755289;
    public static final int TextAppearance_Compat_Notification_Time = 2131755292;
    public static final int TextAppearance_Compat_Notification_Title = 2131755294;
    public static final int Widget_Compat_NotificationActionContainer = 2131755464;
    public static final int Widget_Compat_NotificationActionText = 2131755465;
  }

  public static final class styleable
  {
    public static final int[] ColorStateListItem = { 16843173, 16843551, 2130968615 };
    public static final int ColorStateListItem_alpha = 2;
    public static final int ColorStateListItem_android_alpha = 1;
    public static final int ColorStateListItem_android_color = 0;
    public static final int[] FontFamily = { 2130968811, 2130968812, 2130968813, 2130968814, 2130968815, 2130968816 };
    public static final int[] FontFamilyFont = { 16844082, 16844083, 16844095, 16844143, 16844144, 2130968809, 2130968817, 2130968818, 2130968819, 2130969128 };
    public static final int FontFamilyFont_android_font = 0;
    public static final int FontFamilyFont_android_fontStyle = 2;
    public static final int FontFamilyFont_android_fontVariationSettings = 4;
    public static final int FontFamilyFont_android_fontWeight = 1;
    public static final int FontFamilyFont_android_ttcIndex = 3;
    public static final int FontFamilyFont_font = 5;
    public static final int FontFamilyFont_fontStyle = 6;
    public static final int FontFamilyFont_fontVariationSettings = 7;
    public static final int FontFamilyFont_fontWeight = 8;
    public static final int FontFamilyFont_ttcIndex = 9;
    public static final int FontFamily_fontProviderAuthority = 0;
    public static final int FontFamily_fontProviderCerts = 1;
    public static final int FontFamily_fontProviderFetchStrategy = 2;
    public static final int FontFamily_fontProviderFetchTimeout = 3;
    public static final int FontFamily_fontProviderPackage = 4;
    public static final int FontFamily_fontProviderQuery = 5;
    public static final int[] GradientColor = { 16843165, 16843166, 16843169, 16843170, 16843171, 16843172, 16843265, 16843275, 16844048, 16844049, 16844050, 16844051 };
    public static final int[] GradientColorItem = { 16843173, 16844052 };
    public static final int GradientColorItem_android_color = 0;
    public static final int GradientColorItem_android_offset = 1;
    public static final int GradientColor_android_centerColor = 7;
    public static final int GradientColor_android_centerX = 3;
    public static final int GradientColor_android_centerY = 4;
    public static final int GradientColor_android_endColor = 1;
    public static final int GradientColor_android_endX = 10;
    public static final int GradientColor_android_endY = 11;
    public static final int GradientColor_android_gradientRadius = 5;
    public static final int GradientColor_android_startColor = 0;
    public static final int GradientColor_android_startX = 8;
    public static final int GradientColor_android_startY = 9;
    public static final int GradientColor_android_tileMode = 6;
    public static final int GradientColor_android_type = 2;
  }
}

/* Location:           C:\Users\eunna\dex2jar-2.0\classes-dex2jar.jar
 * Qualified Name:     androidx.legacy.coreutils.R
 * JD-Core Version:    0.6.2
 */