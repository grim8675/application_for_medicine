package androidx.lifecycle;

import androidx.annotation.MainThread;
import androidx.annotation.NonNull;
import androidx.annotation.RestrictTo;
import androidx.annotation.VisibleForTesting;
import androidx.annotation.WorkerThread;
import androidx.arch.core.executor.ArchTaskExecutor;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicBoolean;

@RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP})
public abstract class ComputableLiveData<T>
{
  final AtomicBoolean mComputing = new AtomicBoolean(false);
  final Executor mExecutor;
  final AtomicBoolean mInvalid = new AtomicBoolean(true);

  @VisibleForTesting
  final Runnable mInvalidationRunnable = new Runnable()
  {
    @MainThread
    public void run()
    {
      boolean bool = ComputableLiveData.this.mLiveData.hasActiveObservers();
      if ((ComputableLiveData.this.mInvalid.compareAndSet(false, true)) && (bool))
        ComputableLiveData.this.mExecutor.execute(ComputableLiveData.this.mRefreshRunnable);
    }
  };
  final LiveData<T> mLiveData;

  @VisibleForTesting
  final Runnable mRefreshRunnable = new Runnable()
  {
    @WorkerThread
    public void run()
    {
      int i;
      do
      {
        i = 0;
        int j = 0;
        if (ComputableLiveData.this.mComputing.compareAndSet(false, true))
        {
          Object localObject1 = null;
          i = j;
          try
          {
            while (ComputableLiveData.this.mInvalid.compareAndSet(true, false))
            {
              i = 1;
              localObject1 = ComputableLiveData.this.compute();
            }
            if (i != 0)
              ComputableLiveData.this.mLiveData.postValue(localObject1);
          }
          finally
          {
            ComputableLiveData.this.mComputing.set(false);
          }
        }
      }
      while ((i != 0) && (ComputableLiveData.this.mInvalid.get()));
    }
  };

  public ComputableLiveData()
  {
    this(ArchTaskExecutor.getIOThreadExecutor());
  }

  public ComputableLiveData(@NonNull Executor paramExecutor)
  {
    this.mExecutor = paramExecutor;
    this.mLiveData = new LiveData()
    {
      protected void onActive()
      {
        ComputableLiveData.this.mExecutor.execute(ComputableLiveData.this.mRefreshRunnable);
      }
    };
  }

  @WorkerThread
  protected abstract T compute();

  @NonNull
  public LiveData<T> getLiveData()
  {
    return this.mLiveData;
  }

  public void invalidate()
  {
    ArchTaskExecutor.getInstance().executeOnMainThread(this.mInvalidationRunnable);
  }
}

/* Location:           C:\Users\eunna\dex2jar-2.0\classes-dex2jar.jar
 * Qualified Name:     androidx.lifecycle.ComputableLiveData
 * JD-Core Version:    0.6.2
 */