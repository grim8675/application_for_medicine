package androidx.lifecycle;

public abstract interface LifecycleObserver
{
}

/* Location:           C:\Users\eunna\dex2jar-2.0\classes-dex2jar.jar
 * Qualified Name:     androidx.lifecycle.LifecycleObserver
 * JD-Core Version:    0.6.2
 */