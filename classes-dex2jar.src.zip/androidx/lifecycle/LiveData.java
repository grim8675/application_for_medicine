package androidx.lifecycle;

import androidx.annotation.MainThread;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.arch.core.executor.ArchTaskExecutor;
import androidx.arch.core.internal.SafeIterableMap;
import androidx.arch.core.internal.SafeIterableMap.IteratorWithAdditions;
import java.util.Iterator;
import java.util.Map.Entry;

public abstract class LiveData<T>
{
  static final Object NOT_SET = new Object();
  static final int START_VERSION = -1;
  int mActiveCount = 0;
  private volatile Object mData;
  final Object mDataLock = new Object();
  private boolean mDispatchInvalidated;
  private boolean mDispatchingValue;
  private SafeIterableMap<Observer<? super T>, LiveData<T>.ObserverWrapper> mObservers = new SafeIterableMap();
  volatile Object mPendingData;
  private final Runnable mPostValueRunnable;
  private int mVersion;

  public LiveData()
  {
    Object localObject = NOT_SET;
    this.mData = localObject;
    this.mPendingData = localObject;
    this.mVersion = -1;
    this.mPostValueRunnable = new Runnable()
    {
      public void run()
      {
        Object localObject1;
        synchronized (LiveData.this.mDataLock)
        {
          localObject1 = LiveData.this.mPendingData;
        }
        try
        {
          LiveData.this.mPendingData = LiveData.NOT_SET;
          LiveData.this.setValue(localObject1);
          return;
          localObject2 = finally;
          label40: throw localObject2;
        }
        finally
        {
          break label40;
        }
      }
    };
  }

  private static void assertMainThread(String paramString)
  {
    if (ArchTaskExecutor.getInstance().isMainThread())
      return;
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append("Cannot invoke ");
    localStringBuilder.append(paramString);
    localStringBuilder.append(" on a background");
    localStringBuilder.append(" thread");
    throw new IllegalStateException(localStringBuilder.toString());
  }

  private void considerNotify(LiveData<T>.ObserverWrapper paramLiveData)
  {
    if (!paramLiveData.mActive)
      return;
    if (!paramLiveData.shouldBeActive())
    {
      paramLiveData.activeStateChanged(false);
      return;
    }
    int i = paramLiveData.mLastVersion;
    int j = this.mVersion;
    if (i >= j)
      return;
    paramLiveData.mLastVersion = j;
    paramLiveData.mObserver.onChanged(this.mData);
  }

  void dispatchingValue(@Nullable LiveData<T>.ObserverWrapper paramLiveData)
  {
    if (this.mDispatchingValue)
    {
      this.mDispatchInvalidated = true;
      return;
    }
    this.mDispatchingValue = true;
    while (true)
    {
      this.mDispatchInvalidated = false;
      LiveData<T>.ObserverWrapper localLiveData;
      if (paramLiveData != null)
      {
        considerNotify(paramLiveData);
        localLiveData = null;
      }
      else
      {
        SafeIterableMap.IteratorWithAdditions localIteratorWithAdditions = this.mObservers.iteratorWithAdditions();
        do
        {
          localLiveData = paramLiveData;
          if (!localIteratorWithAdditions.hasNext())
            break;
          considerNotify((ObserverWrapper)((Map.Entry)localIteratorWithAdditions.next()).getValue());
        }
        while (!this.mDispatchInvalidated);
        localLiveData = paramLiveData;
      }
      if (!this.mDispatchInvalidated)
      {
        this.mDispatchingValue = false;
        return;
      }
      paramLiveData = localLiveData;
    }
  }

  @Nullable
  public T getValue()
  {
    Object localObject = this.mData;
    if (localObject != NOT_SET)
      return localObject;
    return null;
  }

  int getVersion()
  {
    return this.mVersion;
  }

  public boolean hasActiveObservers()
  {
    return this.mActiveCount > 0;
  }

  public boolean hasObservers()
  {
    return this.mObservers.size() > 0;
  }

  @MainThread
  public void observe(@NonNull LifecycleOwner paramLifecycleOwner, @NonNull Observer<? super T> paramObserver)
  {
    assertMainThread("observe");
    if (paramLifecycleOwner.getLifecycle().getCurrentState() == Lifecycle.State.DESTROYED)
      return;
    LifecycleBoundObserver localLifecycleBoundObserver = new LifecycleBoundObserver(paramLifecycleOwner, paramObserver);
    paramObserver = (ObserverWrapper)this.mObservers.putIfAbsent(paramObserver, localLifecycleBoundObserver);
    if ((paramObserver != null) && (!paramObserver.isAttachedTo(paramLifecycleOwner)))
      throw new IllegalArgumentException("Cannot add the same observer with different lifecycles");
    if (paramObserver != null)
      return;
    paramLifecycleOwner.getLifecycle().addObserver(localLifecycleBoundObserver);
  }

  @MainThread
  public void observeForever(@NonNull Observer<? super T> paramObserver)
  {
    assertMainThread("observeForever");
    AlwaysActiveObserver localAlwaysActiveObserver = new AlwaysActiveObserver(paramObserver);
    paramObserver = (ObserverWrapper)this.mObservers.putIfAbsent(paramObserver, localAlwaysActiveObserver);
    if ((paramObserver != null) && ((paramObserver instanceof LifecycleBoundObserver)))
      throw new IllegalArgumentException("Cannot add the same observer with different lifecycles");
    if (paramObserver != null)
      return;
    localAlwaysActiveObserver.activeStateChanged(true);
  }

  protected void onActive()
  {
  }

  protected void onInactive()
  {
  }

  // ERROR //
  protected void postValue(T paramT)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 44	androidx/lifecycle/LiveData:mDataLock	Ljava/lang/Object;
    //   4: astore_3
    //   5: aload_3
    //   6: monitorenter
    //   7: iconst_0
    //   8: istore_2
    //   9: aload_0
    //   10: getfield 55	androidx/lifecycle/LiveData:mPendingData	Ljava/lang/Object;
    //   13: astore 4
    //   15: getstatic 41	androidx/lifecycle/LiveData:NOT_SET	Ljava/lang/Object;
    //   18: astore 5
    //   20: aload 4
    //   22: aload 5
    //   24: if_acmpne +5 -> 29
    //   27: iconst_1
    //   28: istore_2
    //   29: aload_0
    //   30: aload_1
    //   31: putfield 55	androidx/lifecycle/LiveData:mPendingData	Ljava/lang/Object;
    //   34: aload_3
    //   35: monitorexit
    //   36: iload_2
    //   37: ifne +4 -> 41
    //   40: return
    //   41: invokestatic 70	androidx/arch/core/executor/ArchTaskExecutor:getInstance	()Landroidx/arch/core/executor/ArchTaskExecutor;
    //   44: aload_0
    //   45: getfield 62	androidx/lifecycle/LiveData:mPostValueRunnable	Ljava/lang/Runnable;
    //   48: invokevirtual 219	androidx/arch/core/executor/ArchTaskExecutor:postToMainThread	(Ljava/lang/Runnable;)V
    //   51: return
    //   52: astore_1
    //   53: aload_3
    //   54: monitorexit
    //   55: aload_1
    //   56: athrow
    //   57: astore_1
    //   58: goto -5 -> 53
    //
    // Exception table:
    //   from	to	target	type
    //   9	20	52	finally
    //   29	36	57	finally
    //   53	55	57	finally
  }

  @MainThread
  public void removeObserver(@NonNull Observer<? super T> paramObserver)
  {
    assertMainThread("removeObserver");
    paramObserver = (ObserverWrapper)this.mObservers.remove(paramObserver);
    if (paramObserver == null)
      return;
    paramObserver.detachObserver();
    paramObserver.activeStateChanged(false);
  }

  @MainThread
  public void removeObservers(@NonNull LifecycleOwner paramLifecycleOwner)
  {
    assertMainThread("removeObservers");
    Iterator localIterator = this.mObservers.iterator();
    while (localIterator.hasNext())
    {
      Map.Entry localEntry = (Map.Entry)localIterator.next();
      if (((ObserverWrapper)localEntry.getValue()).isAttachedTo(paramLifecycleOwner))
        removeObserver((Observer)localEntry.getKey());
    }
  }

  @MainThread
  protected void setValue(T paramT)
  {
    assertMainThread("setValue");
    this.mVersion += 1;
    this.mData = paramT;
    dispatchingValue(null);
  }

  private class AlwaysActiveObserver extends LiveData<T>.ObserverWrapper
  {
    AlwaysActiveObserver()
    {
      super(localObserver);
    }

    boolean shouldBeActive()
    {
      return true;
    }
  }

  class LifecycleBoundObserver extends LiveData<T>.ObserverWrapper
    implements GenericLifecycleObserver
  {

    @NonNull
    final LifecycleOwner mOwner;

    LifecycleBoundObserver(Observer<? super T> arg2)
    {
      super(localObserver);
      Object localObject;
      this.mOwner = localObject;
    }

    void detachObserver()
    {
      this.mOwner.getLifecycle().removeObserver(this);
    }

    boolean isAttachedTo(LifecycleOwner paramLifecycleOwner)
    {
      return this.mOwner == paramLifecycleOwner;
    }

    public void onStateChanged(LifecycleOwner paramLifecycleOwner, Lifecycle.Event paramEvent)
    {
      if (this.mOwner.getLifecycle().getCurrentState() == Lifecycle.State.DESTROYED)
      {
        LiveData.this.removeObserver(this.mObserver);
        return;
      }
      activeStateChanged(shouldBeActive());
    }

    boolean shouldBeActive()
    {
      return this.mOwner.getLifecycle().getCurrentState().isAtLeast(Lifecycle.State.STARTED);
    }
  }

  private abstract class ObserverWrapper
  {
    boolean mActive;
    int mLastVersion = -1;
    final Observer<? super T> mObserver;

    ObserverWrapper()
    {
      Object localObject;
      this.mObserver = localObject;
    }

    void activeStateChanged(boolean paramBoolean)
    {
      if (paramBoolean == this.mActive)
        return;
      this.mActive = paramBoolean;
      int i = LiveData.this.mActiveCount;
      int j = 1;
      if (i == 0)
        i = 1;
      else
        i = 0;
      LiveData localLiveData = LiveData.this;
      int k = localLiveData.mActiveCount;
      if (!this.mActive)
        j = -1;
      localLiveData.mActiveCount = (k + j);
      if ((i != 0) && (this.mActive))
        LiveData.this.onActive();
      if ((LiveData.this.mActiveCount == 0) && (!this.mActive))
        LiveData.this.onInactive();
      if (this.mActive)
        LiveData.this.dispatchingValue(this);
    }

    void detachObserver()
    {
    }

    boolean isAttachedTo(LifecycleOwner paramLifecycleOwner)
    {
      return false;
    }

    abstract boolean shouldBeActive();
  }
}

/* Location:           C:\Users\eunna\dex2jar-2.0\classes-dex2jar.jar
 * Qualified Name:     androidx.lifecycle.LiveData
 * JD-Core Version:    0.6.2
 */