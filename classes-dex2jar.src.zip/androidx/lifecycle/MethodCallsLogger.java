package androidx.lifecycle;

import androidx.annotation.RestrictTo;
import java.util.HashMap;
import java.util.Map;

@RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP_PREFIX})
public class MethodCallsLogger
{
  private Map<String, Integer> mCalledMethods = new HashMap();

  @RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP_PREFIX})
  public boolean approveCall(String paramString, int paramInt)
  {
    Integer localInteger = (Integer)this.mCalledMethods.get(paramString);
    boolean bool = false;
    int i;
    if (localInteger != null)
      i = localInteger.intValue();
    else
      i = 0;
    int j;
    if ((i & paramInt) != 0)
      j = 1;
    else
      j = 0;
    this.mCalledMethods.put(paramString, Integer.valueOf(i | paramInt));
    if (j == 0)
      bool = true;
    return bool;
  }
}

/* Location:           C:\Users\eunna\dex2jar-2.0\classes-dex2jar.jar
 * Qualified Name:     androidx.lifecycle.MethodCallsLogger
 * JD-Core Version:    0.6.2
 */