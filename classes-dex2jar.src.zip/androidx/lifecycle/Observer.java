package androidx.lifecycle;

public abstract interface Observer<T>
{
  public abstract void onChanged(T paramT);
}

/* Location:           C:\Users\eunna\dex2jar-2.0\classes-dex2jar.jar
 * Qualified Name:     androidx.lifecycle.Observer
 * JD-Core Version:    0.6.2
 */