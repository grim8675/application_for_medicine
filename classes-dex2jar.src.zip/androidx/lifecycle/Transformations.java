package androidx.lifecycle;

import androidx.annotation.MainThread;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.arch.core.util.Function;

public class Transformations
{
  @MainThread
  public static <X, Y> LiveData<Y> map(@NonNull LiveData<X> paramLiveData, @NonNull final Function<X, Y> paramFunction)
  {
    MediatorLiveData localMediatorLiveData = new MediatorLiveData();
    localMediatorLiveData.addSource(paramLiveData, new Observer()
    {
      public void onChanged(@Nullable X paramAnonymousX)
      {
        this.val$result.setValue(paramFunction.apply(paramAnonymousX));
      }
    });
    return localMediatorLiveData;
  }

  @MainThread
  public static <X, Y> LiveData<Y> switchMap(@NonNull LiveData<X> paramLiveData, @NonNull Function<X, LiveData<Y>> paramFunction)
  {
    final MediatorLiveData localMediatorLiveData = new MediatorLiveData();
    localMediatorLiveData.addSource(paramLiveData, new Observer()
    {
      LiveData<Y> mSource;

      public void onChanged(@Nullable X paramAnonymousX)
      {
        paramAnonymousX = (LiveData)this.val$switchMapFunction.apply(paramAnonymousX);
        LiveData localLiveData = this.mSource;
        if (localLiveData == paramAnonymousX)
          return;
        if (localLiveData != null)
          localMediatorLiveData.removeSource(localLiveData);
        this.mSource = paramAnonymousX;
        paramAnonymousX = this.mSource;
        if (paramAnonymousX != null)
          localMediatorLiveData.addSource(paramAnonymousX, new Observer()
          {
            public void onChanged(@Nullable Y paramAnonymous2Y)
            {
              Transformations.2.this.val$result.setValue(paramAnonymous2Y);
            }
          });
      }
    });
    return localMediatorLiveData;
  }
}

/* Location:           C:\Users\eunna\dex2jar-2.0\classes-dex2jar.jar
 * Qualified Name:     androidx.lifecycle.Transformations
 * JD-Core Version:    0.6.2
 */