package androidx.lifecycle;

import androidx.annotation.MainThread;
import androidx.annotation.Nullable;
import java.io.Closeable;
import java.io.IOException;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public abstract class ViewModel
{

  @Nullable
  private final Map<String, Object> mBagOfTags = new HashMap();
  private volatile boolean mCleared = false;

  private static void closeWithRuntimeException(Object paramObject)
  {
    if ((paramObject instanceof Closeable))
      try
      {
        ((Closeable)paramObject).close();
        return;
      }
      catch (IOException paramObject)
      {
        throw new RuntimeException(paramObject);
      }
  }

  @MainThread
  final void clear()
  {
    this.mCleared = true;
    Map localMap = this.mBagOfTags;
    if (localMap != null)
      try
      {
        Iterator localIterator = this.mBagOfTags.values().iterator();
        while (localIterator.hasNext())
          closeWithRuntimeException(localIterator.next());
      }
      finally
      {
      }
    onCleared();
  }

  <T> T getTag(String paramString)
  {
    synchronized (this.mBagOfTags)
    {
      paramString = this.mBagOfTags.get(paramString);
      return paramString;
    }
  }

  protected void onCleared()
  {
  }

  <T> T setTagIfAbsent(String paramString, T paramT)
  {
    synchronized (this.mBagOfTags)
    {
      Object localObject = this.mBagOfTags.get(paramString);
      if (localObject == null)
        this.mBagOfTags.put(paramString, paramT);
      if (localObject == null)
        paramString = paramT;
      else
        paramString = localObject;
      if (this.mCleared)
        closeWithRuntimeException(paramString);
      return paramString;
    }
  }
}

/* Location:           C:\Users\eunna\dex2jar-2.0\classes-dex2jar.jar
 * Qualified Name:     androidx.lifecycle.ViewModel
 * JD-Core Version:    0.6.2
 */