package androidx.localbroadcastmanager;

public final class R
{
}

/* Location:           C:\Users\eunna\dex2jar-2.0\classes-dex2jar.jar
 * Qualified Name:     androidx.localbroadcastmanager.R
 * JD-Core Version:    0.6.2
 */