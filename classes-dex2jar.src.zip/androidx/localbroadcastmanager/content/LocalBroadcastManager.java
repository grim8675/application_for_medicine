package androidx.localbroadcastmanager.content;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import androidx.annotation.NonNull;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;

public final class LocalBroadcastManager
{
  private static final boolean DEBUG = false;
  static final int MSG_EXEC_PENDING_BROADCASTS = 1;
  private static final String TAG = "LocalBroadcastManager";
  private static LocalBroadcastManager mInstance;
  private static final Object mLock = new Object();
  private final HashMap<String, ArrayList<ReceiverRecord>> mActions = new HashMap();
  private final Context mAppContext;
  private final Handler mHandler;
  private final ArrayList<BroadcastRecord> mPendingBroadcasts = new ArrayList();
  private final HashMap<BroadcastReceiver, ArrayList<ReceiverRecord>> mReceivers = new HashMap();

  private LocalBroadcastManager(Context paramContext)
  {
    this.mAppContext = paramContext;
    this.mHandler = new Handler(paramContext.getMainLooper())
    {
      public void handleMessage(Message paramAnonymousMessage)
      {
        if (paramAnonymousMessage.what != 1)
        {
          super.handleMessage(paramAnonymousMessage);
          return;
        }
        LocalBroadcastManager.this.executePendingBroadcasts();
      }
    };
  }

  @NonNull
  public static LocalBroadcastManager getInstance(@NonNull Context paramContext)
  {
    synchronized (mLock)
    {
      if (mInstance == null)
        mInstance = new LocalBroadcastManager(paramContext.getApplicationContext());
      paramContext = mInstance;
      return paramContext;
    }
  }

  void executePendingBroadcasts()
  {
    while (true)
    {
      int i;
      BroadcastRecord[] arrayOfBroadcastRecord;
      synchronized (this.mReceivers)
      {
        i = this.mPendingBroadcasts.size();
        if (i <= 0)
          return;
        arrayOfBroadcastRecord = new BroadcastRecord[i];
      }
      try
      {
        this.mPendingBroadcasts.toArray(arrayOfBroadcastRecord);
        this.mPendingBroadcasts.clear();
        i = 0;
        while (i < arrayOfBroadcastRecord.length)
        {
          ??? = arrayOfBroadcastRecord[i];
          int k = ???.receivers.size();
          int j = 0;
          while (j < k)
          {
            ReceiverRecord localReceiverRecord = (ReceiverRecord)???.receivers.get(j);
            if (!localReceiverRecord.dead)
              localReceiverRecord.receiver.onReceive(this.mAppContext, ???.intent);
            j += 1;
          }
          i += 1;
        }
        continue;
        localObject1 = finally;
        label140: throw localObject1;
      }
      finally
      {
        break label140;
      }
    }
  }

  public void registerReceiver(@NonNull BroadcastReceiver paramBroadcastReceiver, @NonNull IntentFilter paramIntentFilter)
  {
    synchronized (this.mReceivers)
    {
      ReceiverRecord localReceiverRecord = new ReceiverRecord(paramIntentFilter, paramBroadcastReceiver);
      Object localObject2 = (ArrayList)this.mReceivers.get(paramBroadcastReceiver);
      Object localObject1 = localObject2;
      if (localObject2 == null)
      {
        localObject1 = new ArrayList(1);
        this.mReceivers.put(paramBroadcastReceiver, localObject1);
      }
      ((ArrayList)localObject1).add(localReceiverRecord);
      int i = 0;
      while (i < paramIntentFilter.countActions())
      {
        localObject2 = paramIntentFilter.getAction(i);
        localObject1 = (ArrayList)this.mActions.get(localObject2);
        paramBroadcastReceiver = (BroadcastReceiver)localObject1;
        if (localObject1 == null)
        {
          paramBroadcastReceiver = new ArrayList(1);
          this.mActions.put(localObject2, paramBroadcastReceiver);
        }
        paramBroadcastReceiver.add(localReceiverRecord);
        i += 1;
      }
      return;
    }
    while (true)
      throw paramBroadcastReceiver;
  }

  public boolean sendBroadcast(@NonNull Intent paramIntent)
  {
    int i;
    Object localObject1;
    int j;
    Object localObject2;
    int k;
    label532: label540: label543: label609: label616: label626: synchronized (this.mReceivers)
    {
      String str2 = paramIntent.getAction();
      String str1 = paramIntent.resolveTypeIfNeeded(this.mAppContext.getContentResolver());
      Uri localUri = paramIntent.getData();
      String str3 = paramIntent.getScheme();
      Set localSet = paramIntent.getCategories();
      if ((paramIntent.getFlags() & 0x8) != 0)
      {
        i = 1;
        if (i != 0)
        {
          localObject1 = new StringBuilder();
          ((StringBuilder)localObject1).append("Resolving type ");
          ((StringBuilder)localObject1).append(str1);
          ((StringBuilder)localObject1).append(" scheme ");
          ((StringBuilder)localObject1).append(str3);
          ((StringBuilder)localObject1).append(" of intent ");
          ((StringBuilder)localObject1).append(paramIntent);
          Log.v("LocalBroadcastManager", ((StringBuilder)localObject1).toString());
        }
        ArrayList localArrayList = (ArrayList)this.mActions.get(paramIntent.getAction());
        if (localArrayList == null)
          break label626;
        if (i == 0)
          break label532;
        localObject1 = new StringBuilder();
        ((StringBuilder)localObject1).append("Action list: ");
        ((StringBuilder)localObject1).append(localArrayList);
        Log.v("LocalBroadcastManager", ((StringBuilder)localObject1).toString());
        break label532;
        if (j >= localArrayList.size())
          break label616;
        ReceiverRecord localReceiverRecord = (ReceiverRecord)localArrayList.get(j);
        if (i != 0)
        {
          localObject1 = new StringBuilder();
          ((StringBuilder)localObject1).append("Matching against filter ");
          ((StringBuilder)localObject1).append(localReceiverRecord.filter);
          Log.v("LocalBroadcastManager", ((StringBuilder)localObject1).toString());
        }
        if (localReceiverRecord.broadcasting)
        {
          if (i == 0)
            break label540;
          Log.v("LocalBroadcastManager", "  Filter's target already added");
          break label609;
        }
        localObject1 = localReceiverRecord.filter;
        Object localObject3 = localObject2;
        k = ((IntentFilter)localObject1).match(str2, str1, str3, localUri, localSet, "LocalBroadcastManager");
        if (k < 0)
          break label543;
        if (i != 0)
        {
          localObject1 = new StringBuilder();
          ((StringBuilder)localObject1).append("  Filter matched!  match=0x");
          ((StringBuilder)localObject1).append(Integer.toHexString(k));
          Log.v("LocalBroadcastManager", ((StringBuilder)localObject1).toString());
        }
        localObject1 = localObject3;
        if (localObject3 == null)
          localObject1 = new ArrayList();
        ((ArrayList)localObject1).add(localReceiverRecord);
        localReceiverRecord.broadcasting = true;
        localObject2 = localObject1;
        break label609;
        localObject3 = new StringBuilder();
        ((StringBuilder)localObject3).append("  Filter did not match: ");
        ((StringBuilder)localObject3).append((String)localObject1);
        Log.v("LocalBroadcastManager", ((StringBuilder)localObject3).toString());
        break label609;
        while (i < localObject2.size())
        {
          ((ReceiverRecord)localObject2.get(i)).broadcasting = false;
          i += 1;
        }
        this.mPendingBroadcasts.add(new BroadcastRecord(paramIntent, localObject2));
        if (!this.mHandler.hasMessages(1))
          this.mHandler.sendEmptyMessage(1);
        return true;
        return false;
      }
    }
  }

  public void sendBroadcastSync(@NonNull Intent paramIntent)
  {
    if (sendBroadcast(paramIntent))
      executePendingBroadcasts();
  }

  public void unregisterReceiver(@NonNull BroadcastReceiver paramBroadcastReceiver)
  {
    int i;
    int j;
    int k;
    label202: label209: synchronized (this.mReceivers)
    {
      ArrayList localArrayList1 = (ArrayList)this.mReceivers.remove(paramBroadcastReceiver);
      if (localArrayList1 == null)
        return;
      i = localArrayList1.size() - 1;
      if (i >= 0)
      {
        ReceiverRecord localReceiverRecord1 = (ReceiverRecord)localArrayList1.get(i);
        localReceiverRecord1.dead = true;
        j = 0;
        if (j >= localReceiverRecord1.filter.countActions())
          break label209;
        String str = localReceiverRecord1.filter.getAction(j);
        ArrayList localArrayList2 = (ArrayList)this.mActions.get(str);
        if (localArrayList2 == null)
          break label202;
        k = localArrayList2.size() - 1;
        if (k >= 0)
        {
          ReceiverRecord localReceiverRecord2 = (ReceiverRecord)localArrayList2.get(k);
          if (localReceiverRecord2.receiver == paramBroadcastReceiver)
          {
            localReceiverRecord2.dead = true;
            localArrayList2.remove(k);
          }
        }
        else
        {
          if (localArrayList2.size() > 0)
            break label202;
          this.mActions.remove(str);
          break label202;
        }
      }
      else
      {
        return;
      }
    }
  }

  private static final class BroadcastRecord
  {
    final Intent intent;
    final ArrayList<LocalBroadcastManager.ReceiverRecord> receivers;

    BroadcastRecord(Intent paramIntent, ArrayList<LocalBroadcastManager.ReceiverRecord> paramArrayList)
    {
      this.intent = paramIntent;
      this.receivers = paramArrayList;
    }
  }

  private static final class ReceiverRecord
  {
    boolean broadcasting;
    boolean dead;
    final IntentFilter filter;
    final BroadcastReceiver receiver;

    ReceiverRecord(IntentFilter paramIntentFilter, BroadcastReceiver paramBroadcastReceiver)
    {
      this.filter = paramIntentFilter;
      this.receiver = paramBroadcastReceiver;
    }

    public String toString()
    {
      StringBuilder localStringBuilder = new StringBuilder(128);
      localStringBuilder.append("Receiver{");
      localStringBuilder.append(this.receiver);
      localStringBuilder.append(" filter=");
      localStringBuilder.append(this.filter);
      if (this.dead)
        localStringBuilder.append(" DEAD");
      localStringBuilder.append("}");
      return localStringBuilder.toString();
    }
  }
}

/* Location:           C:\Users\eunna\dex2jar-2.0\classes-dex2jar.jar
 * Qualified Name:     androidx.localbroadcastmanager.content.LocalBroadcastManager
 * JD-Core Version:    0.6.2
 */