package androidx.media;

import androidx.annotation.RestrictTo;
import androidx.versionedparcelable.VersionedParcel;

@RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY})
public final class AudioAttributesImplBaseParcelizer
{
  public static AudioAttributesImplBase read(VersionedParcel paramVersionedParcel)
  {
    AudioAttributesImplBase localAudioAttributesImplBase = new AudioAttributesImplBase();
    localAudioAttributesImplBase.mUsage = paramVersionedParcel.readInt(localAudioAttributesImplBase.mUsage, 1);
    localAudioAttributesImplBase.mContentType = paramVersionedParcel.readInt(localAudioAttributesImplBase.mContentType, 2);
    localAudioAttributesImplBase.mFlags = paramVersionedParcel.readInt(localAudioAttributesImplBase.mFlags, 3);
    localAudioAttributesImplBase.mLegacyStream = paramVersionedParcel.readInt(localAudioAttributesImplBase.mLegacyStream, 4);
    return localAudioAttributesImplBase;
  }

  public static void write(AudioAttributesImplBase paramAudioAttributesImplBase, VersionedParcel paramVersionedParcel)
  {
    paramVersionedParcel.setSerializationFlags(false, false);
    paramVersionedParcel.writeInt(paramAudioAttributesImplBase.mUsage, 1);
    paramVersionedParcel.writeInt(paramAudioAttributesImplBase.mContentType, 2);
    paramVersionedParcel.writeInt(paramAudioAttributesImplBase.mFlags, 3);
    paramVersionedParcel.writeInt(paramAudioAttributesImplBase.mLegacyStream, 4);
  }
}

/* Location:           C:\Users\eunna\dex2jar-2.0\classes-dex2jar.jar
 * Qualified Name:     androidx.media.AudioAttributesImplBaseParcelizer
 * JD-Core Version:    0.6.2
 */