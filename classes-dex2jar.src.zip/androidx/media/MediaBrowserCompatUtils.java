package androidx.media;

import android.os.Bundle;
import androidx.annotation.RestrictTo;

@RestrictTo({androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP})
public class MediaBrowserCompatUtils
{
  public static boolean areSameOptions(Bundle paramBundle1, Bundle paramBundle2)
  {
    if (paramBundle1 == paramBundle2)
      return true;
    if (paramBundle1 == null)
      return (paramBundle2.getInt("android.media.browse.extra.PAGE", -1) == -1) && (paramBundle2.getInt("android.media.browse.extra.PAGE_SIZE", -1) == -1);
    if (paramBundle2 == null)
      return (paramBundle1.getInt("android.media.browse.extra.PAGE", -1) == -1) && (paramBundle1.getInt("android.media.browse.extra.PAGE_SIZE", -1) == -1);
    return (paramBundle1.getInt("android.media.browse.extra.PAGE", -1) == paramBundle2.getInt("android.media.browse.extra.PAGE", -1)) && (paramBundle1.getInt("android.media.browse.extra.PAGE_SIZE", -1) == paramBundle2.getInt("android.media.browse.extra.PAGE_SIZE", -1));
  }

  public static boolean hasDuplicatedItems(Bundle paramBundle1, Bundle paramBundle2)
  {
    int k;
    if (paramBundle1 == null)
      k = -1;
    else
      k = paramBundle1.getInt("android.media.browse.extra.PAGE", -1);
    int i;
    if (paramBundle2 == null)
      i = -1;
    else
      i = paramBundle2.getInt("android.media.browse.extra.PAGE", -1);
    int m;
    if (paramBundle1 == null)
      m = -1;
    else
      m = paramBundle1.getInt("android.media.browse.extra.PAGE_SIZE", -1);
    int j;
    if (paramBundle2 == null)
      j = -1;
    else
      j = paramBundle2.getInt("android.media.browse.extra.PAGE_SIZE", -1);
    if ((k != -1) && (m != -1))
    {
      k = m * k;
      m = k + m - 1;
    }
    else
    {
      k = 0;
      m = 2147483647;
    }
    if ((i != -1) && (j != -1))
    {
      i = j * i;
      j = i + j - 1;
    }
    else
    {
      i = 0;
      j = 2147483647;
    }
    return (m >= i) && (j >= k);
  }
}

/* Location:           C:\Users\eunna\dex2jar-2.0\classes-dex2jar.jar
 * Qualified Name:     androidx.media.MediaBrowserCompatUtils
 * JD-Core Version:    0.6.2
 */