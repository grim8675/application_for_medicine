package androidx.print;

import android.annotation.SuppressLint;
import android.content.ContentResolver;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.pdf.PdfDocument.Page;
import android.graphics.pdf.PdfDocument.PageInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.CancellationSignal.OnCancelListener;
import android.os.ParcelFileDescriptor;
import android.print.PageRange;
import android.print.PrintAttributes;
import android.print.PrintAttributes.Builder;
import android.print.PrintAttributes.Margins;
import android.print.PrintAttributes.MediaSize;
import android.print.PrintDocumentAdapter;
import android.print.PrintDocumentAdapter.LayoutResultCallback;
import android.print.PrintDocumentAdapter.WriteResultCallback;
import android.print.PrintDocumentInfo.Builder;
import android.print.PrintManager;
import android.print.pdf.PrintedPdfDocument;
import android.util.Log;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

public final class PrintHelper
{

  @SuppressLint({"InlinedApi"})
  public static final int COLOR_MODE_COLOR = 2;

  @SuppressLint({"InlinedApi"})
  public static final int COLOR_MODE_MONOCHROME = 1;
  static final boolean IS_MIN_MARGINS_HANDLING_CORRECT = bool1;
  private static final String LOG_TAG = "PrintHelper";
  private static final int MAX_PRINT_SIZE = 3500;
  public static final int ORIENTATION_LANDSCAPE = 1;
  public static final int ORIENTATION_PORTRAIT = 2;
  static final boolean PRINT_ACTIVITY_RESPECTS_ORIENTATION;
  public static final int SCALE_MODE_FILL = 2;
  public static final int SCALE_MODE_FIT = 1;
  int mColorMode = 2;
  final Context mContext;
  BitmapFactory.Options mDecodeOptions = null;
  final Object mLock = new Object();
  int mOrientation = 1;
  int mScaleMode = 2;

  static
  {
    int i = Build.VERSION.SDK_INT;
    boolean bool2 = false;
    if ((i >= 20) && (Build.VERSION.SDK_INT <= 23))
      bool1 = false;
    else
      bool1 = true;
    PRINT_ACTIVITY_RESPECTS_ORIENTATION = bool1;
    boolean bool1 = bool2;
    if (Build.VERSION.SDK_INT != 23)
      bool1 = true;
  }

  public PrintHelper(@NonNull Context paramContext)
  {
    this.mContext = paramContext;
  }

  static Bitmap convertBitmapForColorMode(Bitmap paramBitmap, int paramInt)
  {
    if (paramInt != 1)
      return paramBitmap;
    Bitmap localBitmap = Bitmap.createBitmap(paramBitmap.getWidth(), paramBitmap.getHeight(), Bitmap.Config.ARGB_8888);
    Canvas localCanvas = new Canvas(localBitmap);
    Paint localPaint = new Paint();
    ColorMatrix localColorMatrix = new ColorMatrix();
    localColorMatrix.setSaturation(0.0F);
    localPaint.setColorFilter(new ColorMatrixColorFilter(localColorMatrix));
    localCanvas.drawBitmap(paramBitmap, 0.0F, 0.0F, localPaint);
    localCanvas.setBitmap(null);
    return localBitmap;
  }

  @RequiresApi(19)
  private static PrintAttributes.Builder copyAttributes(PrintAttributes paramPrintAttributes)
  {
    PrintAttributes.Builder localBuilder = new PrintAttributes.Builder().setMediaSize(paramPrintAttributes.getMediaSize()).setResolution(paramPrintAttributes.getResolution()).setMinMargins(paramPrintAttributes.getMinMargins());
    if (paramPrintAttributes.getColorMode() != 0)
      localBuilder.setColorMode(paramPrintAttributes.getColorMode());
    if ((Build.VERSION.SDK_INT >= 23) && (paramPrintAttributes.getDuplexMode() != 0))
      localBuilder.setDuplexMode(paramPrintAttributes.getDuplexMode());
    return localBuilder;
  }

  static Matrix getMatrix(int paramInt1, int paramInt2, RectF paramRectF, int paramInt3)
  {
    Matrix localMatrix = new Matrix();
    float f = paramRectF.width() / paramInt1;
    if (paramInt3 == 2)
      f = Math.max(f, paramRectF.height() / paramInt2);
    else
      f = Math.min(f, paramRectF.height() / paramInt2);
    localMatrix.postScale(f, f);
    localMatrix.postTranslate((paramRectF.width() - paramInt1 * f) / 2.0F, (paramRectF.height() - paramInt2 * f) / 2.0F);
    return localMatrix;
  }

  static boolean isPortrait(Bitmap paramBitmap)
  {
    return paramBitmap.getWidth() <= paramBitmap.getHeight();
  }

  private Bitmap loadBitmap(Uri paramUri, BitmapFactory.Options paramOptions)
    throws FileNotFoundException
  {
    if (paramUri != null)
    {
      Context localContext = this.mContext;
      if (localContext != null)
      {
        Uri localUri = null;
        try
        {
          paramUri = localContext.getContentResolver().openInputStream(paramUri);
          localUri = paramUri;
          paramOptions = BitmapFactory.decodeStream(paramUri, null, paramOptions);
          if (paramUri != null)
            try
            {
              paramUri.close();
              return paramOptions;
            }
            catch (IOException paramUri)
            {
              Log.w("PrintHelper", "close fail ", paramUri);
            }
          return paramOptions;
        }
        finally
        {
          if (localUri != null)
            try
            {
              localUri.close();
            }
            catch (IOException paramOptions)
            {
              Log.w("PrintHelper", "close fail ", paramOptions);
            }
        }
      }
    }
    throw new IllegalArgumentException("bad argument to loadBitmap");
  }

  public static boolean systemSupportsPrint()
  {
    return Build.VERSION.SDK_INT >= 19;
  }

  public int getColorMode()
  {
    return this.mColorMode;
  }

  public int getOrientation()
  {
    if ((Build.VERSION.SDK_INT >= 19) && (this.mOrientation == 0))
      return 1;
    return this.mOrientation;
  }

  public int getScaleMode()
  {
    return this.mScaleMode;
  }

  // ERROR //
  Bitmap loadConstrainedBitmap(Uri arg1)
    throws FileNotFoundException
  {
    // Byte code:
    //   0: aload_1
    //   1: ifnull +227 -> 228
    //   4: aload_0
    //   5: getfield 78	androidx/print/PrintHelper:mContext	Landroid/content/Context;
    //   8: ifnull +220 -> 228
    //   11: new 263	android/graphics/BitmapFactory$Options
    //   14: dup
    //   15: invokespecial 264	android/graphics/BitmapFactory$Options:<init>	()V
    //   18: astore 6
    //   20: aload 6
    //   22: iconst_1
    //   23: putfield 267	android/graphics/BitmapFactory$Options:inJustDecodeBounds	Z
    //   26: aload_0
    //   27: aload_1
    //   28: aload 6
    //   30: invokespecial 269	androidx/print/PrintHelper:loadBitmap	(Landroid/net/Uri;Landroid/graphics/BitmapFactory$Options;)Landroid/graphics/Bitmap;
    //   33: pop
    //   34: aload 6
    //   36: getfield 272	android/graphics/BitmapFactory$Options:outWidth	I
    //   39: istore 4
    //   41: aload 6
    //   43: getfield 275	android/graphics/BitmapFactory$Options:outHeight	I
    //   46: istore 5
    //   48: iload 4
    //   50: ifle +176 -> 226
    //   53: iload 5
    //   55: ifgt +5 -> 60
    //   58: aconst_null
    //   59: areturn
    //   60: iload 4
    //   62: iload 5
    //   64: invokestatic 278	java/lang/Math:max	(II)I
    //   67: istore_3
    //   68: iconst_1
    //   69: istore_2
    //   70: iload_3
    //   71: sipush 3500
    //   74: if_icmple +14 -> 88
    //   77: iload_3
    //   78: iconst_1
    //   79: iushr
    //   80: istore_3
    //   81: iload_2
    //   82: iconst_1
    //   83: ishl
    //   84: istore_2
    //   85: goto -15 -> 70
    //   88: iload_2
    //   89: ifle +135 -> 224
    //   92: iload 4
    //   94: iload 5
    //   96: invokestatic 280	java/lang/Math:min	(II)I
    //   99: iload_2
    //   100: idiv
    //   101: ifgt +5 -> 106
    //   104: aconst_null
    //   105: areturn
    //   106: aload_0
    //   107: getfield 70	androidx/print/PrintHelper:mLock	Ljava/lang/Object;
    //   110: astore 6
    //   112: aload 6
    //   114: monitorenter
    //   115: aload_0
    //   116: new 263	android/graphics/BitmapFactory$Options
    //   119: dup
    //   120: invokespecial 264	android/graphics/BitmapFactory$Options:<init>	()V
    //   123: putfield 68	androidx/print/PrintHelper:mDecodeOptions	Landroid/graphics/BitmapFactory$Options;
    //   126: aload_0
    //   127: getfield 68	androidx/print/PrintHelper:mDecodeOptions	Landroid/graphics/BitmapFactory$Options;
    //   130: iconst_1
    //   131: putfield 283	android/graphics/BitmapFactory$Options:inMutable	Z
    //   134: aload_0
    //   135: getfield 68	androidx/print/PrintHelper:mDecodeOptions	Landroid/graphics/BitmapFactory$Options;
    //   138: iload_2
    //   139: putfield 286	android/graphics/BitmapFactory$Options:inSampleSize	I
    //   142: aload_0
    //   143: getfield 68	androidx/print/PrintHelper:mDecodeOptions	Landroid/graphics/BitmapFactory$Options;
    //   146: astore 7
    //   148: aload 6
    //   150: monitorexit
    //   151: aload_0
    //   152: aload_1
    //   153: aload 7
    //   155: invokespecial 269	androidx/print/PrintHelper:loadBitmap	(Landroid/net/Uri;Landroid/graphics/BitmapFactory$Options;)Landroid/graphics/Bitmap;
    //   158: astore 6
    //   160: aload_0
    //   161: getfield 70	androidx/print/PrintHelper:mLock	Ljava/lang/Object;
    //   164: astore_1
    //   165: aload_1
    //   166: monitorenter
    //   167: aload_0
    //   168: aconst_null
    //   169: putfield 68	androidx/print/PrintHelper:mDecodeOptions	Landroid/graphics/BitmapFactory$Options;
    //   172: aload_1
    //   173: monitorexit
    //   174: aload 6
    //   176: areturn
    //   177: astore 6
    //   179: aload_1
    //   180: monitorexit
    //   181: aload 6
    //   183: athrow
    //   184: astore 6
    //   186: aload_0
    //   187: getfield 70	androidx/print/PrintHelper:mLock	Ljava/lang/Object;
    //   190: astore_1
    //   191: aload_1
    //   192: monitorenter
    //   193: aload_0
    //   194: aconst_null
    //   195: putfield 68	androidx/print/PrintHelper:mDecodeOptions	Landroid/graphics/BitmapFactory$Options;
    //   198: aload_1
    //   199: monitorexit
    //   200: aload 6
    //   202: athrow
    //   203: astore 6
    //   205: aload_1
    //   206: monitorexit
    //   207: aload 6
    //   209: athrow
    //   210: astore_1
    //   211: goto +4 -> 215
    //   214: astore_1
    //   215: aload 6
    //   217: monitorexit
    //   218: aload_1
    //   219: athrow
    //   220: astore_1
    //   221: goto -6 -> 215
    //   224: aconst_null
    //   225: areturn
    //   226: aconst_null
    //   227: areturn
    //   228: new 249	java/lang/IllegalArgumentException
    //   231: dup
    //   232: ldc_w 288
    //   235: invokespecial 254	java/lang/IllegalArgumentException:<init>	(Ljava/lang/String;)V
    //   238: astore_1
    //   239: goto +5 -> 244
    //   242: aload_1
    //   243: athrow
    //   244: goto -2 -> 242
    //
    // Exception table:
    //   from	to	target	type
    //   167	174	177	finally
    //   179	181	177	finally
    //   151	160	184	finally
    //   193	200	203	finally
    //   205	207	203	finally
    //   148	151	210	finally
    //   115	148	214	finally
    //   215	218	220	finally
  }

  public void printBitmap(@NonNull String paramString, @NonNull Bitmap paramBitmap)
  {
    printBitmap(paramString, paramBitmap, null);
  }

  public void printBitmap(@NonNull String paramString, @NonNull Bitmap paramBitmap, @Nullable OnPrintFinishCallback paramOnPrintFinishCallback)
  {
    if (Build.VERSION.SDK_INT >= 19)
    {
      if (paramBitmap == null)
        return;
      PrintManager localPrintManager = (PrintManager)this.mContext.getSystemService("print");
      if (isPortrait(paramBitmap))
        localObject = PrintAttributes.MediaSize.UNKNOWN_PORTRAIT;
      else
        localObject = PrintAttributes.MediaSize.UNKNOWN_LANDSCAPE;
      Object localObject = new PrintAttributes.Builder().setMediaSize((PrintAttributes.MediaSize)localObject).setColorMode(this.mColorMode).build();
      localPrintManager.print(paramString, new PrintBitmapAdapter(paramString, this.mScaleMode, paramBitmap, paramOnPrintFinishCallback), (PrintAttributes)localObject);
      return;
    }
  }

  public void printBitmap(@NonNull String paramString, @NonNull Uri paramUri)
    throws FileNotFoundException
  {
    printBitmap(paramString, paramUri, null);
  }

  public void printBitmap(@NonNull String paramString, @NonNull Uri paramUri, @Nullable OnPrintFinishCallback paramOnPrintFinishCallback)
    throws FileNotFoundException
  {
    if (Build.VERSION.SDK_INT < 19)
      return;
    paramUri = new PrintUriAdapter(paramString, paramUri, paramOnPrintFinishCallback, this.mScaleMode);
    paramOnPrintFinishCallback = (PrintManager)this.mContext.getSystemService("print");
    PrintAttributes.Builder localBuilder = new PrintAttributes.Builder();
    localBuilder.setColorMode(this.mColorMode);
    int i = this.mOrientation;
    if ((i != 1) && (i != 0))
    {
      if (i == 2)
        localBuilder.setMediaSize(PrintAttributes.MediaSize.UNKNOWN_PORTRAIT);
    }
    else
      localBuilder.setMediaSize(PrintAttributes.MediaSize.UNKNOWN_LANDSCAPE);
    paramOnPrintFinishCallback.print(paramString, paramUri, localBuilder.build());
  }

  public void setColorMode(int paramInt)
  {
    this.mColorMode = paramInt;
  }

  public void setOrientation(int paramInt)
  {
    this.mOrientation = paramInt;
  }

  public void setScaleMode(int paramInt)
  {
    this.mScaleMode = paramInt;
  }

  @RequiresApi(19)
  void writeBitmap(final PrintAttributes paramPrintAttributes, final int paramInt, final Bitmap paramBitmap, final ParcelFileDescriptor paramParcelFileDescriptor, final CancellationSignal paramCancellationSignal, final PrintDocumentAdapter.WriteResultCallback paramWriteResultCallback)
  {
    final PrintAttributes localPrintAttributes;
    if (IS_MIN_MARGINS_HANDLING_CORRECT)
      localPrintAttributes = paramPrintAttributes;
    else
      localPrintAttributes = copyAttributes(paramPrintAttributes).setMinMargins(new PrintAttributes.Margins(0, 0, 0, 0)).build();
    new AsyncTask()
    {
      protected Throwable doInBackground(Void[] paramAnonymousArrayOfVoid)
      {
        try
        {
          if (paramCancellationSignal.isCanceled())
            return null;
          Object localObject1 = new PrintedPdfDocument(PrintHelper.this.mContext, localPrintAttributes);
          Bitmap localBitmap = PrintHelper.convertBitmapForColorMode(paramBitmap, localPrintAttributes.getColorMode());
          boolean bool = paramCancellationSignal.isCanceled();
          if (bool)
            return null;
          try
          {
            PdfDocument.Page localPage1 = ((PrintedPdfDocument)localObject1).startPage(1);
            if (PrintHelper.IS_MIN_MARGINS_HANDLING_CORRECT)
            {
              paramAnonymousArrayOfVoid = new RectF(localPage1.getInfo().getContentRect());
            }
            else
            {
              localObject2 = new PrintedPdfDocument(PrintHelper.this.mContext, paramPrintAttributes);
              PdfDocument.Page localPage2 = ((PrintedPdfDocument)localObject2).startPage(1);
              paramAnonymousArrayOfVoid = new RectF(localPage2.getInfo().getContentRect());
              ((PrintedPdfDocument)localObject2).finishPage(localPage2);
              ((PrintedPdfDocument)localObject2).close();
            }
            Object localObject2 = PrintHelper.getMatrix(localBitmap.getWidth(), localBitmap.getHeight(), paramAnonymousArrayOfVoid, paramInt);
            if (!PrintHelper.IS_MIN_MARGINS_HANDLING_CORRECT)
            {
              ((Matrix)localObject2).postTranslate(paramAnonymousArrayOfVoid.left, paramAnonymousArrayOfVoid.top);
              localPage1.getCanvas().clipRect(paramAnonymousArrayOfVoid);
            }
            localPage1.getCanvas().drawBitmap(localBitmap, (Matrix)localObject2, null);
            ((PrintedPdfDocument)localObject1).finishPage(localPage1);
            bool = paramCancellationSignal.isCanceled();
            if (bool)
              return null;
            ((PrintedPdfDocument)localObject1).writeTo(new FileOutputStream(paramParcelFileDescriptor.getFileDescriptor()));
            ((PrintedPdfDocument)localObject1).close();
            paramAnonymousArrayOfVoid = paramParcelFileDescriptor;
            if (paramAnonymousArrayOfVoid != null)
              try
              {
                paramParcelFileDescriptor.close();
              }
              catch (IOException paramAnonymousArrayOfVoid)
              {
              }
            if (localBitmap != paramBitmap)
            {
              localBitmap.recycle();
              return null;
            }
          }
          finally
          {
            ((PrintedPdfDocument)localObject1).close();
            localObject1 = paramParcelFileDescriptor;
            if (localObject1 != null)
              try
              {
                paramParcelFileDescriptor.close();
              }
              catch (IOException localIOException)
              {
              }
            if (localBitmap != paramBitmap)
              localBitmap.recycle();
          }
        }
        catch (Throwable paramAnonymousArrayOfVoid)
        {
          return paramAnonymousArrayOfVoid;
        }
        return null;
      }

      protected void onPostExecute(Throwable paramAnonymousThrowable)
      {
        if (paramCancellationSignal.isCanceled())
        {
          paramWriteResultCallback.onWriteCancelled();
          return;
        }
        if (paramAnonymousThrowable == null)
        {
          paramWriteResultCallback.onWriteFinished(new PageRange[] { PageRange.ALL_PAGES });
          return;
        }
        Log.e("PrintHelper", "Error writing printed content", paramAnonymousThrowable);
        paramWriteResultCallback.onWriteFailed(null);
      }
    }
    .execute(new Void[0]);
  }

  public static abstract interface OnPrintFinishCallback
  {
    public abstract void onFinish();
  }

  @RequiresApi(19)
  private class PrintBitmapAdapter extends PrintDocumentAdapter
  {
    private PrintAttributes mAttributes;
    private final Bitmap mBitmap;
    private final PrintHelper.OnPrintFinishCallback mCallback;
    private final int mFittingMode;
    private final String mJobName;

    PrintBitmapAdapter(String paramInt, int paramBitmap, Bitmap paramOnPrintFinishCallback, PrintHelper.OnPrintFinishCallback arg5)
    {
      this.mJobName = paramInt;
      this.mFittingMode = paramBitmap;
      this.mBitmap = paramOnPrintFinishCallback;
      Object localObject;
      this.mCallback = localObject;
    }

    public void onFinish()
    {
      PrintHelper.OnPrintFinishCallback localOnPrintFinishCallback = this.mCallback;
      if (localOnPrintFinishCallback != null)
        localOnPrintFinishCallback.onFinish();
    }

    public void onLayout(PrintAttributes paramPrintAttributes1, PrintAttributes paramPrintAttributes2, CancellationSignal paramCancellationSignal, PrintDocumentAdapter.LayoutResultCallback paramLayoutResultCallback, Bundle paramBundle)
    {
      this.mAttributes = paramPrintAttributes2;
      paramLayoutResultCallback.onLayoutFinished(new PrintDocumentInfo.Builder(this.mJobName).setContentType(1).setPageCount(1).build(), true ^ paramPrintAttributes2.equals(paramPrintAttributes1));
    }

    public void onWrite(PageRange[] paramArrayOfPageRange, ParcelFileDescriptor paramParcelFileDescriptor, CancellationSignal paramCancellationSignal, PrintDocumentAdapter.WriteResultCallback paramWriteResultCallback)
    {
      PrintHelper.this.writeBitmap(this.mAttributes, this.mFittingMode, this.mBitmap, paramParcelFileDescriptor, paramCancellationSignal, paramWriteResultCallback);
    }
  }

  @RequiresApi(19)
  private class PrintUriAdapter extends PrintDocumentAdapter
  {
    PrintAttributes mAttributes;
    Bitmap mBitmap;
    final PrintHelper.OnPrintFinishCallback mCallback;
    final int mFittingMode;
    final Uri mImageFile;
    final String mJobName;
    AsyncTask<Uri, Boolean, Bitmap> mLoadBitmap;

    PrintUriAdapter(String paramUri, Uri paramOnPrintFinishCallback, PrintHelper.OnPrintFinishCallback paramInt, int arg5)
    {
      this.mJobName = paramUri;
      this.mImageFile = paramOnPrintFinishCallback;
      this.mCallback = paramInt;
      int i;
      this.mFittingMode = i;
      this.mBitmap = null;
    }

    void cancelLoad()
    {
      synchronized (PrintHelper.this.mLock)
      {
        if (PrintHelper.this.mDecodeOptions != null)
        {
          if (Build.VERSION.SDK_INT < 24)
            PrintHelper.this.mDecodeOptions.requestCancelDecode();
          PrintHelper.this.mDecodeOptions = null;
        }
        return;
      }
    }

    public void onFinish()
    {
      super.onFinish();
      cancelLoad();
      Object localObject = this.mLoadBitmap;
      if (localObject != null)
        ((AsyncTask)localObject).cancel(true);
      localObject = this.mCallback;
      if (localObject != null)
        ((PrintHelper.OnPrintFinishCallback)localObject).onFinish();
      localObject = this.mBitmap;
      if (localObject != null)
      {
        ((Bitmap)localObject).recycle();
        this.mBitmap = null;
      }
    }

    public void onLayout(final PrintAttributes paramPrintAttributes1, final PrintAttributes paramPrintAttributes2, final CancellationSignal paramCancellationSignal, final PrintDocumentAdapter.LayoutResultCallback paramLayoutResultCallback, Bundle paramBundle)
    {
      try
      {
        this.mAttributes = paramPrintAttributes2;
        if (paramCancellationSignal.isCanceled())
        {
          paramLayoutResultCallback.onLayoutCancelled();
          return;
        }
        if (this.mBitmap != null)
        {
          paramLayoutResultCallback.onLayoutFinished(new PrintDocumentInfo.Builder(this.mJobName).setContentType(1).setPageCount(1).build(), true ^ paramPrintAttributes2.equals(paramPrintAttributes1));
          return;
        }
        this.mLoadBitmap = new AsyncTask()
        {
          protected Bitmap doInBackground(Uri[] paramAnonymousArrayOfUri)
          {
            try
            {
              paramAnonymousArrayOfUri = PrintHelper.this.loadConstrainedBitmap(PrintHelper.PrintUriAdapter.this.mImageFile);
              return paramAnonymousArrayOfUri;
            }
            catch (FileNotFoundException paramAnonymousArrayOfUri)
            {
            }
            return null;
          }

          protected void onCancelled(Bitmap paramAnonymousBitmap)
          {
            paramLayoutResultCallback.onLayoutCancelled();
            PrintHelper.PrintUriAdapter.this.mLoadBitmap = null;
          }

          // ERROR //
          protected void onPostExecute(Bitmap arg1)
          {
            // Byte code:
            //   0: aload_0
            //   1: aload_1
            //   2: invokespecial 80	android/os/AsyncTask:onPostExecute	(Ljava/lang/Object;)V
            //   5: aload_1
            //   6: astore_3
            //   7: aload_1
            //   8: ifnull +109 -> 117
            //   11: getstatic 84	androidx/print/PrintHelper:PRINT_ACTIVITY_RESPECTS_ORIENTATION	Z
            //   14: ifeq +18 -> 32
            //   17: aload_1
            //   18: astore_3
            //   19: aload_0
            //   20: getfield 28	androidx/print/PrintHelper$PrintUriAdapter$1:this$1	Landroidx/print/PrintHelper$PrintUriAdapter;
            //   23: getfield 48	androidx/print/PrintHelper$PrintUriAdapter:this$0	Landroidx/print/PrintHelper;
            //   26: getfield 88	androidx/print/PrintHelper:mOrientation	I
            //   29: ifne +88 -> 117
            //   32: aload_0
            //   33: monitorenter
            //   34: aload_0
            //   35: getfield 28	androidx/print/PrintHelper$PrintUriAdapter$1:this$1	Landroidx/print/PrintHelper$PrintUriAdapter;
            //   38: getfield 91	androidx/print/PrintHelper$PrintUriAdapter:mAttributes	Landroid/print/PrintAttributes;
            //   41: invokevirtual 97	android/print/PrintAttributes:getMediaSize	()Landroid/print/PrintAttributes$MediaSize;
            //   44: astore 4
            //   46: aload_0
            //   47: monitorexit
            //   48: aload_1
            //   49: astore_3
            //   50: aload 4
            //   52: ifnull +65 -> 117
            //   55: aload_1
            //   56: astore_3
            //   57: aload 4
            //   59: invokevirtual 103	android/print/PrintAttributes$MediaSize:isPortrait	()Z
            //   62: aload_1
            //   63: invokestatic 106	androidx/print/PrintHelper:isPortrait	(Landroid/graphics/Bitmap;)Z
            //   66: if_icmpeq +51 -> 117
            //   69: new 108	android/graphics/Matrix
            //   72: dup
            //   73: invokespecial 109	android/graphics/Matrix:<init>	()V
            //   76: astore_3
            //   77: aload_3
            //   78: ldc 110
            //   80: invokevirtual 114	android/graphics/Matrix:postRotate	(F)Z
            //   83: pop
            //   84: aload_1
            //   85: iconst_0
            //   86: iconst_0
            //   87: aload_1
            //   88: invokevirtual 118	android/graphics/Bitmap:getWidth	()I
            //   91: aload_1
            //   92: invokevirtual 121	android/graphics/Bitmap:getHeight	()I
            //   95: aload_3
            //   96: iconst_1
            //   97: invokestatic 125	android/graphics/Bitmap:createBitmap	(Landroid/graphics/Bitmap;IIIILandroid/graphics/Matrix;Z)Landroid/graphics/Bitmap;
            //   100: astore_3
            //   101: goto +16 -> 117
            //   104: astore_1
            //   105: goto +4 -> 109
            //   108: astore_1
            //   109: aload_0
            //   110: monitorexit
            //   111: aload_1
            //   112: athrow
            //   113: astore_1
            //   114: goto -5 -> 109
            //   117: aload_0
            //   118: getfield 28	androidx/print/PrintHelper$PrintUriAdapter$1:this$1	Landroidx/print/PrintHelper$PrintUriAdapter;
            //   121: astore_1
            //   122: aload_1
            //   123: aload_3
            //   124: putfield 129	androidx/print/PrintHelper$PrintUriAdapter:mBitmap	Landroid/graphics/Bitmap;
            //   127: aload_3
            //   128: ifnull +52 -> 180
            //   131: new 131	android/print/PrintDocumentInfo$Builder
            //   134: dup
            //   135: aload_1
            //   136: getfield 135	androidx/print/PrintHelper$PrintUriAdapter:mJobName	Ljava/lang/String;
            //   139: invokespecial 138	android/print/PrintDocumentInfo$Builder:<init>	(Ljava/lang/String;)V
            //   142: iconst_1
            //   143: invokevirtual 142	android/print/PrintDocumentInfo$Builder:setContentType	(I)Landroid/print/PrintDocumentInfo$Builder;
            //   146: iconst_1
            //   147: invokevirtual 145	android/print/PrintDocumentInfo$Builder:setPageCount	(I)Landroid/print/PrintDocumentInfo$Builder;
            //   150: invokevirtual 149	android/print/PrintDocumentInfo$Builder:build	()Landroid/print/PrintDocumentInfo;
            //   153: astore_1
            //   154: aload_0
            //   155: getfield 32	androidx/print/PrintHelper$PrintUriAdapter$1:val$newPrintAttributes	Landroid/print/PrintAttributes;
            //   158: aload_0
            //   159: getfield 34	androidx/print/PrintHelper$PrintUriAdapter$1:val$oldPrintAttributes	Landroid/print/PrintAttributes;
            //   162: invokevirtual 153	android/print/PrintAttributes:equals	(Ljava/lang/Object;)Z
            //   165: istore_2
            //   166: aload_0
            //   167: getfield 36	androidx/print/PrintHelper$PrintUriAdapter$1:val$layoutResultCallback	Landroid/print/PrintDocumentAdapter$LayoutResultCallback;
            //   170: aload_1
            //   171: iconst_1
            //   172: iload_2
            //   173: ixor
            //   174: invokevirtual 157	android/print/PrintDocumentAdapter$LayoutResultCallback:onLayoutFinished	(Landroid/print/PrintDocumentInfo;Z)V
            //   177: goto +11 -> 188
            //   180: aload_0
            //   181: getfield 36	androidx/print/PrintHelper$PrintUriAdapter$1:val$layoutResultCallback	Landroid/print/PrintDocumentAdapter$LayoutResultCallback;
            //   184: aconst_null
            //   185: invokevirtual 161	android/print/PrintDocumentAdapter$LayoutResultCallback:onLayoutFailed	(Ljava/lang/CharSequence;)V
            //   188: aload_0
            //   189: getfield 28	androidx/print/PrintHelper$PrintUriAdapter$1:this$1	Landroidx/print/PrintHelper$PrintUriAdapter;
            //   192: aconst_null
            //   193: putfield 72	androidx/print/PrintHelper$PrintUriAdapter:mLoadBitmap	Landroid/os/AsyncTask;
            //   196: return
            //
            // Exception table:
            //   from	to	target	type
            //   46	48	104	finally
            //   34	46	108	finally
            //   109	111	113	finally
          }

          protected void onPreExecute()
          {
            paramCancellationSignal.setOnCancelListener(new CancellationSignal.OnCancelListener()
            {
              public void onCancel()
              {
                PrintHelper.PrintUriAdapter.this.cancelLoad();
                PrintHelper.PrintUriAdapter.1.this.cancel(false);
              }
            });
          }
        }
        .execute(new Uri[0]);
        return;
      }
      finally
      {
      }
      throw paramPrintAttributes1;
    }

    public void onWrite(PageRange[] paramArrayOfPageRange, ParcelFileDescriptor paramParcelFileDescriptor, CancellationSignal paramCancellationSignal, PrintDocumentAdapter.WriteResultCallback paramWriteResultCallback)
    {
      PrintHelper.this.writeBitmap(this.mAttributes, this.mFittingMode, this.mBitmap, paramParcelFileDescriptor, paramCancellationSignal, paramWriteResultCallback);
    }
  }
}

/* Location:           C:\Users\eunna\dex2jar-2.0\classes-dex2jar.jar
 * Qualified Name:     androidx.print.PrintHelper
 * JD-Core Version:    0.6.2
 */