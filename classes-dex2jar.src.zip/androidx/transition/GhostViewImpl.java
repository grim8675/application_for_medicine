package androidx.transition;

import android.view.View;
import android.view.ViewGroup;

abstract interface GhostViewImpl
{
  public abstract void reserveEndViewTransition(ViewGroup paramViewGroup, View paramView);

  public abstract void setVisibility(int paramInt);
}

/* Location:           C:\Users\eunna\dex2jar-2.0\classes-dex2jar.jar
 * Qualified Name:     androidx.transition.GhostViewImpl
 * JD-Core Version:    0.6.2
 */